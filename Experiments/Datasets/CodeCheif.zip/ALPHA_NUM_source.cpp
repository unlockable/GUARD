#pragma GCC optimize("Ofast")
#pragma GCC target("sse,sse2,sse3,ssse3,sse4,popcnt,abm,mmx,avx,avx2,fma")
#pragma GCC optimize("unroll-loops")
#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef long double ld;
ll MOD = 1e9 + 7;
double eps = 1e-12;
#define forn(i, e) for (ll i = 0; i < e; i++)
#define forsn(i, s, e) for (ll i = s; i < e; i++)
#define rforn(i, s) for (ll i = s; i >= 0; i--)
#define rforsn(i, s, e) for (ll i = s; i >= e; i--)
#define ln "\n"
#define dbg(x) cout << #x << " = " << x << ln
#define pb push_back
#define fi first
#define se second
#define INF 2e18
#define fast_cin()                    \
    ios_base::sync_with_stdio(false); \
    cin.tie(NULL);                    \
    cout.tie(NULL)
#define all(x) (x).begin(), (x).end()
#define sz(x) ((ll)(x).size())
map<char,int>m;
class Ashutosh
{
public:
    void preCal()
    {
        int i=1;
        for(char c='A';c<='Z';c++)
        {
            if(i==10)i=1;
            m[c]=i;
            i++;
        }
    }
    void chalBata()
    {
        string s;
        cin>>s;
        ll ans=0;
        for(char c:s)
        {
            ans+=m[c];
        }
        cout<<ans<<ln;
    }
};
int main()
{
#ifndef ONLINE_JUDGE
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);
#endif
    fast_cin();
    ll t;
    cin >> t;
    Ashutosh ashu;
    ashu.preCal();
    for (int it = 1; it <= t; it++)
    {
        //cout << "Case #" << it << ": ";
        ashu.chalBata();
    }
    return 0;
}