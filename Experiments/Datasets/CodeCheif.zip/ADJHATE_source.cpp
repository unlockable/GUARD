#include <iostream>
#include <vector>
using namespace std;
int main()
{
    int t;
    cin >> t;
    while (t--)
    {
        int n;
        cin >> n;
        int arr[n];
        vector<int> v1, v2;
        int e =0;
        int o = 0;
        for (int i = 0; i < n; i++)
        {
            cin >> arr[i];
            if(arr[i]%2==0)
            { 
                 e++;
                 v1.push_back(arr[i]);
            }
            else{
                o++;
                v2.push_back(arr[i]);
            }
        }
        if(o==0||e==0)
        {
             cout<<-1<<endl;
        }
        else{
            for (int i = 0; i < v1.size(); i++)
            {
               cout<<v1[i]<<" ";
            }
            for (int i = 0; i < v2.size(); i++)
            {
                cout<<v2[i]<<" ";
            }
            cout<<endl;
        }
    }
    return 0;
}