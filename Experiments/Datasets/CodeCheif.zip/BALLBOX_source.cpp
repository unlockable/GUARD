#include <iostream>
using namespace std;
int main() {
    int t,n,k;
    cin>>t;
    for(int i=0; i<t; i++)
    {
       cin>>n>>k;
       if(k>=n)
       {
           if(n==1 && k==1)
           {
               cout<<"yes"<<endl;
           }
           else
           {
               cout<<"no"<<endl;
           }
       }
              else
       {
           int balls=0;
           for(int i=1; i<=k; i++)
           {
               balls=balls+i;
           }
           if(n>=balls)
           {
               cout<<"yes"<<endl;
           }
           else
           {
               cout<<"no"<<endl;
           }
       }
           }
        return 0;
}