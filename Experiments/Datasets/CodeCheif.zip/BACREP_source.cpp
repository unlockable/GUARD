#include <bits/stdc++.h>
using namespace std;
template<typename T>
struct fenwick_tree {
    int tree_n = 0;
    T tree_sum = 0;
    vector<T> tree;
     fenwick_tree(int n = -1) {
        if (n >= 0)
            init(n);
    }
     static int highest_bit(int x) {
        return x == 0 ? -1 : 31 - __builtin_clz(x);
    }
     void init(int n) {
        tree_n = n;
        tree_sum = 0;
        tree.assign(tree_n + 1, 0);
    }
     // O(n) initialization of the Fenwick tree.
    template<typename T_array>
    void build(const T_array &initial) {
        assert(int(initial.size()) == tree_n);
        tree_sum = 0;
         for (int i = 1; i <= tree_n; i++) {
            tree[i] = initial[i - 1];
            tree_sum += initial[i - 1];
             for (int k = (i & -i) >> 1; k > 0; k >>= 1)
                tree[i] += tree[i - k];
        }
    }
     // index is in [0, tree_n).
    void update(int index, const T &change) {
        assert(0 <= index && index < tree_n);
        tree_sum += change;
         for (int i = index + 1; i <= tree_n; i += i & -i)
            tree[i] += change;
    }
     // Returns the sum of the range [0, count).
    T query(int count) const {
        count = min(count, tree_n);
        T sum = 0;
         for (int i = count; i > 0; i -= i & -i)
            sum += tree[i];
         return sum;
    }
     // Returns the sum of the range [start, tree_n).
    T query_suffix(int start) const {
        return tree_sum - query(start);
    }
     // Returns the sum of the range [a, b).
    T query(int a, int b) const {
        return query(b) - query(a);
    }
     // Returns the element at index a in O(1) amortized across every index. Equivalent to query(a, a + 1).
    T get(int a) const {
        assert(0 <= a && a < tree_n);
        int above = a + 1;
        T sum = tree[above];
        above -= above & -above;
         while (a != above) {
            sum -= tree[a];
            a -= a & -a;
        }
         return sum;
    }
};
int main() {
    int N, Q;
    cin >> N >> Q;
    vector<vector<int>> adj(N);
    for (int i = 1; i < N; i++) {
        int x, y;
        cin >> x >> y;
        --x, --y;
        adj[x].push_back(y);
        adj[y].push_back(x);
    }
    vector<int> in(N), out(N), depth(N);
    int timer = 0;
    function<void(int, int)> dfs = [&](int node, int par) -> void {
        in[node] = timer++;
        for (int child: adj[node]) {
            if (child != par) {
                depth[child] = depth[node] + 1;
                dfs(child, node);
            }
        }
        out[node] = timer;
    };
    dfs(0, -1);
    fenwick_tree<int64_t> tree_without_leaf(N), tree_with_leaf(N);
    vector<int64_t> A(N);
    vector<array<int64_t, 5>> queries;
    for(auto &u: A)
        cin >> u;
    for (int i = 0; i < N; i++) {
        queries.push_back({0 - depth[i], 0, i, A[i], -1});
    }
    for (int i = 1; i <= Q; i++) {
        char ch;
        cin >> ch;
        if (ch == '+') {
            int v, k;
            cin >> v >> k;
            --v;
            queries.push_back({i - depth[v], 0, v, k, i});
        } else {
            int v;
            cin >> v;
            --v;
            queries.push_back({i - depth[v], 1, v, 0, i});
        }
    }
    sort(queries.begin(), queries.end());
    vector<array<int64_t, 5>> queries_to_revert;
    vector<pair<int, int64_t>> answers;
    int last = -(N + 100);
    for (int i = 0; i < queries.size(); i++) {
        int current = queries[i][0];
        int type = queries[i][1];
        int node = queries[i][2];
        int64_t value = queries[i][3];
        if (current > last) {
            last = current;
            for (array<int64_t, 5> &query : queries_to_revert) {
                int type = query[1];
                if (type == 0) {
                    int node = query[2];
                    int l = in[node];
                    int r = out[node];
                    tree_without_leaf.update(l, -query[3]);
                    if (r < N)
                        tree_without_leaf.update(r, query[3]);
                }
            }
            queries_to_revert.clear();
        }
                queries_to_revert.push_back(queries[i]);
        int l = in[node];
        int r = out[node];
        if (type == 0) {
            tree_without_leaf.update(l, value);
            if (r < N)
                tree_without_leaf.update(r, -value);
            tree_with_leaf.update(l, value);
            if (r < N)
                tree_with_leaf.update(r, -value);
        } else {
            if (adj[node].size() == 1 && node != 0) {
                answers.emplace_back(queries[i][4], tree_with_leaf.query(l + 1));
            } else {
                answers.emplace_back(queries[i][4], tree_without_leaf.query(l + 1));
            }
        }
    }
    sort(answers.begin(), answers.end());
    for (auto [_, answer] : answers) {
        cout << answer << '\n';
    }
}