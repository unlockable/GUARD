#include <bits/stdc++.h>
using namespace std;
#define ll long long int
#define mii map<int,int>
#define vi vector<int>
#define vl vector<ll>
#define vll vector<vector<ll>>
const ll M= 1e9 + 7;
ll mod_sub(ll a, ll b, ll m) {a = a % m; b = b % m; return (((a - b) % m) + m) % m;}
ll mod_add(ll a, ll b, ll m) {a = a % m; b = b % m; return (((a + b) % m) + m) % m;}
ll mul(ll a, ll b) {return (a * 1ll * b) % M;}
ll inv(ll i) {if (i == 1) return 1; return (M - ((M / i) * inv (M % i)) % M) % M;}
ll mod_expo(ll a, ll b, ll m){
    if(b==0)return 1LL%m;
    ll c= mod_expo(a, b/2, m);
    c= (c*c)%m;
    if(b%2)c= (c*a)%m;
    return c;
}
void solve();
int  main(){
    solve();
    return 0;
}
void solve(){
    ll t; cin>>t;
    while(t--){
        ll n; cin>>n;
        ll l=((ll)log2(n));
        if(n==1)cout<<1;
        else if(n==(1<<l))cout<<((1<<l)-(1<<(l-1)));
        else{
            ll g= ((1<<l)-(1<<(l-1)));
            ll h= (n-(1<<l)+1);
           if(g>h)cout<<g;else cout<<h;
        }
        cout<<endl;
    }
}