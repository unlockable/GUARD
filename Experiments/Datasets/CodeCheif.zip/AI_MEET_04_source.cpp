#include <bits/stdc++.h>
using namespace std;
 #define pb push_back
#define loop(i,a,b) for(auto i=a;i<=b;++i)
#define ll long long int
#define endl "\n"
#define mod 1000000007
#define all(v) v.begin(),v.end()
#define ss second
#define ff first
#define sz size()
#define vi vector<ll>
#define print(a) for(auto x:a){cout<<x<<" ";} cout<<endl;
int32_t main()
{
    ios::sync_with_stdio(0);   
    cin.tie(0);     
    #ifndef ONLINE_JUDGE
    freopen("input.txt","r",stdin);
    freopen("output.txt","w",stdout);
    #endif
        int n;cin>>n;
    int x1,y1,x2,y2;
    cin>>x1>>y1>>x2>>y2;
    int ans=abs(x2-x1)+abs(y2-y1);
    if(ans<=n){
        cout<<"YES"<<endl;
    }
    else{
        cout<<"NO"<<endl;
    }
   return 0;
}        