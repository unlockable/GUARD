#include <bits/stdc++.h>
using namespace std;
int main() {
    int t;
    cin>>t;
    while (t--){
        int n,count=0;
        cin>>n;
        string str;
        cin>>str;
        for(int i=0;i<n;i++){
            if(str[i]=='1'){
                count+=1;
            }
        }
        int m = count+(120-n);
        float p = (m*100)/120;
        if(p>=75){
            cout << "YES" <<endl;
        }
        else if(p<75){
       cout << "NO" <<endl;
        }
    }
    return 0;
}