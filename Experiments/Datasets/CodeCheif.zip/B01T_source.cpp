#include <bits/stdc++.h>
using namespace std;
int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    int t; cin >> t;
    while (t--) {
        int n; cin >> n;
        vector<int> a(n);
        vector<vector<int>> adj(n);
        for (int i = 0; i < n; i++) {
            cin >> a[i];
        }
        for (int i = 1; i < n; i++) {
            int u, v; cin >> u >> v; u--; v--;
            adj[u].push_back(v);
            adj[v].push_back(u);
        }
        // return order, parent
        auto BFS = [&](int src) {
            vector<int> par(n, -1), ord;
            // src is never chosen as a subtree, so we are safe to set par[src] = src
            par[src] = src; ord.push_back(src);
            for (int i = 0; i < n; i++) {
                int u = ord[i];
                for (int v : adj[u]) {
                    if (par[v] == -1) {
                        par[v] = u;
                        ord.push_back(v);
                    }
                }
            }
            return make_pair(ord, par);
        };
        auto [ord, par] = BFS(0);
        vector<int> prf(n);
        for (int i = 0; i < n; i++) {
            int a1=0;
            if(i==0)
            {
                if(a[ord[i]]==0)
                a1=1;
                else
                a1=-1;
            }
            else
            {
                if(a[ord[i]]==0)
                a1=1;
                else
                a1=-1;
                a1+=prf[i-1];
            }
            // prf[i] = (i == 0 ? (a[ord[i]]==0?1:-1) : prf[i - 1]) + (a[ord[i]] == 0 ? 1 : -1);
            prf[i]=a1;
            //cout<<prf[i];
        }
        for (int i = 0; i < n; i++) {
            if (prf[i] == prf[n - 1] / 2) {
                vector<bool> mrk(n);
                for (int j = i + 1; j < n; j++) {
                    mrk[ord[j]] = true;
                }
                vector<int> ans;
                for (int u = 0; u < n; u++) {
                    if (mrk[u] && !mrk[par[u]]) {
                        ans.push_back(u + 1);
                    }
                }
                cout << ans.size() << '\n';
                for (int v : ans) {
                    cout << v << " ";
                }
                cout << '\n';
                break;
            }
        }
    }
}