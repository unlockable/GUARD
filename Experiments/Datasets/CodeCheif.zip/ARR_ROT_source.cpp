#include <iostream>
#include <vector>
using namespace std;
void solve()
{
    int size, pass;
    cin >> size >> pass;
    vector<int> list;
    int i = size;
    while (i--)
    {
        int k;
        cin >> k;
        list.push_back(k);
    }
    while (pass--)
    {
        list.insert(list.begin(), list[size - 1]);
        list.pop_back();
    }
    for (auto i : list)
    {
        cout << i << ' ';
    }
}
int main()
{
    int t;
    cin >> t;
    while (t--)
    {
        solve();
    }
    return 0;
}