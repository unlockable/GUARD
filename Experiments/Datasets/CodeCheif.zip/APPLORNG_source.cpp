#include <iostream>
using namespace std;
int main() {
    // your code goes here
    int x;
    int a,b;
    cin>>x;
    cin>>a>>b;
    if(x>=a+b)
    cout<<"yes"<<endl;
    else cout<<"no"<<endl;
    return 0;
}