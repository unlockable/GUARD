// We have populated the solutions for the 10 easiest problems for your support.
// Click on the SUBMIT button to make a submission to this problem.
#include <bits/stdc++.h>
#include <boost/multiprecision/cpp_int.hpp>
#include <iostream>
using namespace std;
using namespace boost::multiprecision;
int main() {
    // your code goes here
    int t;
    cin>>t;
    while(t--)
    {
        int x;
        cin>>x;
        int total=x*3;
        cout<<"1"<<" ";
        cout<<"3"<<" ";
        cout<<total-4<<" ";
        cout<<endl;
    }
        return 0;
}