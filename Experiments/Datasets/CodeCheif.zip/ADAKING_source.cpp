#include <iostream>
using namespace std;
#define int long long 
signed main() {
    int t;
    cin>>t;
    while(t--){
    int k;cin>>k;
    int x=k%8;
    for(int i=1;i<=8;i++){
        for(int j=1;j<=8;j++){
            if(i==1&&j==1){
                cout<<"O";
                k--;
                continue;
            }
            if(k>0){
                cout<<".";
                k--;
            }
            else
                cout<<"X";
        }
     cout<<"\n";   
    }
    cout<<"\n";
    }
    return 0;
}