///----------------------///
///---Code Written by----///
///-----Al-Shahreyaj-----///
///----------------------///
 ///PRAGMA
//#pragma comment(linker, "/stack:200000000")
//#pragma GCC optimize("Ofast")
//#pragma GCC target("sse,sse2,sse3,ssse3,sse4,popcnt,abm,mmx,avx,tune=native")
//#pragma GCC optimize("unroll-loops")
 #include<bits/stdc++.h>
 ///PBDS
//#include<ext/pb_ds/assoc_container.hpp>
//#include<ext/pb_ds/tree_policy.hpp>
//using namespace __gnu_pbds;
using namespace std;
 //PBDS_SET
//Index of Value - .order_of_key()
//Value at Index - .find_by_order()
//typedef tree<int, null_type, less<int>, rb_tree_tag,tree_order_statistics_node_update> pbds_set; 
//typedef tree<int, null_type, lessorequal<int>, rb_tree_tag,tree_order_statistics_node_update> pbds_multiset; 
 #define mem(a, x) memset(a, x, sizeof(a))
#define MP make_pair
#define inf 1e8
#define INF 1e18
#define CP(x) printf("Case %d: ", x);
#define unq(v) v.erase(unique(all(v)),v.end())
#define one(x) __builtin_popcount(x)
#define onel(x) __builtin_popcountll(x)
#define ll long long
#define ull unsigned long long
#define ld long double
#define LMX LLONG_MAX
#define fixpre(x) cout << fixed << setprecision(x)
#define endl "\n"
#define vi vector<int>
#define vll vector<long long>
#define pii pair<int,int>
#define pil pair<int,ll>
#define pll pair<ll,ll>
#define matrix vector<vector<int> >
#define matrixll vector<vector<ll> >
#define F first
#define S second
#define pb push_back
#define pq priority_queue
#define all(x) x.begin(),x.end()
#define rev(x) reverse(all(x))
#define sz(x) (int)x.size()
#define INT ini()
#define LONG inl()
#define M 1000000007
#define N 3005
#ifndef ONLINE_JUDGE
#define debug(x) cerr << #x <<" "; _print(x); cerr << endl;
#else
#define debug(x)
#endif
void _print(ll t) {cerr << t;}
void _print(int t) {cerr << t;}
void _print(string t) {cerr << t;}
void _print(char t) {cerr << t;}
void _print(ld t) {cerr << t;}
void _print(double t) {cerr << t;}
void _print(ull t) {cerr << t;}
template <class T, class V> void _print(pair <T, V> p);
template <class T> void _print(vector <T> v);
template <class T> void _print(set <T> v);
template <class T, class V> void _print(map <T, V> v);
template <class T> void _print(multiset <T> v);
template <class T, class V> void _print(pair <T, V> p) {cerr << "{"; _print(p.ff); cerr << ","; _print(p.ss); cerr << "}";}
template <class T> void _print(vector <T> v) {cerr << "[ "; for (T i : v) {_print(i); cerr << " ";} cerr << "]";}
template <class T> void _print(set <T> v) {cerr << "[ "; for (T i : v) {_print(i); cerr << " ";} cerr << "]";}
template <class T> void _print(multiset <T> v) {cerr << "[ "; for (T i : v) {_print(i); cerr << " ";} cerr << "]";}
template <class T, class V> void _print(map <T, V> v) {cerr << "[ "; for (auto i : v) {_print(i); cerr << " ";} cerr << "]";}
 int ini(){int x;scanf("%d",&x);return x;}
ll inl(){ll x;scanf("%lld",&x);return x;}
 void file_mamager()
{
    #ifndef ONLINE_JUDGE
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);
    #endif
}
  ll  c, len[N], dp[N][N];
 vi col[N];
 ll cal(int n, int val)
 {
    if(n > c) return 0;
    if(dp[n][val] != -1) return dp[n][val];
    ll tot = 0;
    for(int x : col[n]) tot += x;
    // debug(tot);
    ll sum = 0, tmp = 0, ans = INF, cn = 0;
    for(int i = 0; i < sz(col[n]); i++)
    {
        // debug(col[n][i]);
        for(int j = 0; j <= col[n][i]; j++)
        {
            ll res = INF;
            if(1LL * (tot - sum - j) * len[n] <= val) res = 1LL * j * tmp + cn + cal(n + 1, val - ((tot - sum - j) * len[n]));
            ans = min(ans, res);
        }
        cn += 1LL * col[n][i] * tmp;
        tmp += sum * col[n][i];
        sum += col[n][i];
        // debug(n);
        // debug(val);
        // debug(tmp);
    }
    return dp[n][val] = ans;
 }
 int main()
{
    int t = INT;
    while(t--)
    {
        int n = INT;
        c = INT;
        int  k = INT;
        for(int i = 1; i <= c; i++) col[i].clear();
        for(int i = 1; i <= n; i++)
        {
            int a = INT;
            int b = INT;
            int color = INT;
            col[color].pb(a);
        }
        for(int i = 1; i <= c; i++) len[i] = INT;
        for(int i = 1; i <= c; i++)
        {
            sort(all(col[i]));
            int cn = 1;
            vi lst;
            for(int j = 1; j < col[i].size(); j++)
            {
                if(col[i][j] == col[i][j - 1]) cn++;
                else
                {
                    lst.pb(cn);
                    cn = 1;
                }
            }
            if(cn) lst.pb(cn);
            sort(all(lst));
            rev(lst);
            col[i] = lst;
        }
        // for(int i = 1; i <= c; i++) {
        //  vi lst = col[i];
        //  // debug(lst);
        // }
        mem(dp, -1);
        cout << cal(1, k) << endl;
    }
}