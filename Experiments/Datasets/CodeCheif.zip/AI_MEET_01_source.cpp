#include <bits/stdc++.h>
using namespace std;
 #define pb push_back
#define loop(i,a,b) for(auto i=a;i<=b;++i)
#define ll long long int
#define endl "\n"
#define mod 1000000007
#define all(v) v.begin(),v.end()
#define ss second
#define ff first
#define sz size()
#define vi vector<ll>
#define print(a) for(auto x:a){cout<<x<<" ";} cout<<endl;
int32_t main()
{
    ios::sync_with_stdio(0);   
    cin.tie(0);     
    #ifndef ONLINE_JUDGE
    freopen("input.txt","r",stdin);
    freopen("output.txt","w",stdout);
    #endif
       int n,d,h;
   cin>>n>>d>>h;
   int sum=d+h;
   string s;
   cin>>s;
   int c=0;
   for(int i=0;i<n;){
    if(s[i]=='.'){
        while(s[i]=='.'){
            c++;
            i++;
        }
    }
    else{
        c=0;
        i++;
    }
   // cout<<c<<endl;
    if(c>0){
        if(c%2==0){
        d-=(c/2);
        h-=(c/2);
        }
        else{
            d-=(c/2);
            h-=(c/2);
            if(d>=h and d>0){
                d-=1;
            }
            else{
                if(h>0){
                    h-=1;
                }
              //  h-=1;
        }
       // cout<<d<<" "<<h<<endl;
    }
    }
   }
   if(d<0){
    d=0;
   }
   if(h<0){
    h=0;
   }
  // cout<<d<<h<<endl;
   cout<<sum-(d+h)<<endl;
   return 0;
}        