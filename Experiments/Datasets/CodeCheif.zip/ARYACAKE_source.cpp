#include <bits/stdc++.h>
using namespace std;
/*  <--------- Shortcuts --------->  */
#define int long long 
#define fr(i,a,b) for(int i=a;i<b;i++)
#define f2(i,a,b,c) for(int i=a;i<b;i+=c)
#define fb(j,a,b) for(int j=a;j>=b;j--)
#define vsort(a) sort(a.begin(),a.end())
#define vrsort(a) sort(a.begin(),a.end(),greater<int>())
#define vprsort(a) sort(a.rbegin(),a.rend())
#define vi vector <int>
#define vb vector <bool>
#define vs vector <string>
#define vc vector <char>
#define vvi vector<vector<int>>
#define vvb vector<vector<bool>>
#define vvs vector<vector<string>>
#define vvc vector<vector<char>>
#define pii pair <int,int>
#define pci pair <char,int>
#define psi pair <string,int>
#define vpii vector< pii >
#define vpci vector< pci >
#define vpsi vector< psi >
#define vvpii vector<vector< pii >>
#define vvpci vector<vector< pci >>
#define vvpsi vector<vector< psi >>
#define si set <int>
#define spi set <pi >
#define spint set <pint >
#define sint set <int>
#define wl while
#define endl "\n"
#define spc " "
#define uint unsigned long long int
#define pb push_back
#define ins insert
#define F first
#define S second
#define all(a) a.begin(),a.end()
#define sz(a) a.size()
#define mset(a,x) memset(a,x,sizeof(a))
#define tc() int t;cin>>t;wl(t--)
#define mci map<char,int> 
#define msi map<string,int> 
#define mii map<int,int> 
#define fast ios:: sync_with_stdio(false); cin.tie(NUint); cout.tie(NUint);
/* <--------- IO ---------> */
#define st(arr,n) sort(arr,arr+n);
#define stg(arr,n) sort(arr,arr+n,greater<int> ());
#define get(a,n) vi a(n); f(i,0,n) cin>>a[i]
#define puta(a,n) fr(i,0,n) cout<<a[i]<<spc; cout<<endl
#define puts(a,n) fr(i,0,n) cout<<a[i]<<spc; cout<<endl
#define putv(a) fr(i,0,a.size()) cout<<a[i]<<spc; cout<<endl
#define pr(a) cout<<a<<endl;
#define prd(a,n) cout<<setprecision(n)<<a<<endl;
#define p(a) cout<<a;
#define prs(a) cout<<a<<" ";
#define prpair(a) for(auto i : a) cout<<i.first<<" "<<i.second<<endl;
#define re(a) int a;cin>>a;
#define res(a) string a;cin>>a;
#define rec(a) char a;cin>>a;
#define rea(arr,n) int arr[n]; fr(i,0,n) cin>>arr[i];
#define reas(arr,n) string arr[n]; fr(i,0,n) cin>>arr[i];
#define reac(arr,n) char arr[n]; fr(i,0,n) cin>>arr[i];
#define rev(v,n) vector<int> v; fr(i,0,n){int x; cin>>x; v.push_back(x)};
#define reas(arr,n) string arr[n]; fr(i,0,n) cin>>arr[i];
#define reac(arr,n) char arr[n]; fr(i,0,n) cin>>arr[i];
#define sm(sum,arr,n) int sum = 0; fr(i,0,n) sum += arr[i];
#define yes pr("YES");
#define no pr("NO");
#define ret return;
const int mod = 1000*1000*1000+7;
int floor1(int n,int k){if(n%k == 0 || n >= 0)return n/k;return (n/k)-1;}
int ceil1(int n,int k){return floor1(n+k-1,k);}
int powm(int a, int b, int mod){int res=1;while(b){if(b&1)res=(res*a)%mod;a=(a*a)%mod;b>>=1;}return res;}
void solve()
{
    re(n);rea(arr,n);rea(brr,n);
    st(arr,n);stg(brr,n);
    int cnt = 0;
    fr(i,0,n and (arr[i]<brr[i]))
    {
        cnt += brr[i] - arr[i];
    }
    pr(cnt);
}
    signed main()
{
    int t = 1;
    // cin>>t;
    while(t--)
    {
        solve();
    }
    return 0;
}  