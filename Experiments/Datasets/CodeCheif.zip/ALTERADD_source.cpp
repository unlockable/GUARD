#include <iostream>
#include <cmath>
using namespace std;
int main() {
    int t;
    cin>>t;
    while(t--)
    {
        int a,b;
        cin>>a>>b;
        int c=b-a;
        if(c%3==0) cout<<"YES"<<endl;
        else if(c%3==1) cout<<"YES"<<endl;
        else cout<<"NO"<<endl;
    }
}