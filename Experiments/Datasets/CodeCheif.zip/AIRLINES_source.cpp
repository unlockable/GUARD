#include <iostream>
using namespace std;
int main() {
    // your code goes here
    int s;
    cin>>s;
    while(s--){
        int a,b,c;
        cin>>a>>b>>c;
        int x=a*10;
        if(b<=x)
            cout<<b*c<<endl;
        else
            cout<<x*c<<endl;
    }
    return 0;
}