#include <iostream>
using namespace std;
void solve(){
   long long n, k;
   cin>>n>>k;
   long long max = 1<<n;
   cout<<(max-1)*(max-2)<<endl;
}
signed main(){
   int t=1;
   cin>>t;
   while(t--) solve();
   return 0;
}