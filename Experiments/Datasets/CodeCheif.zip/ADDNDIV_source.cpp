#include <bits/stdc++.h>
using namespace std;
void solve(){
    int a, b;
    cin>>a>>b;
    int g = __gcd(a, b);
    while(g!=1 && a > 1) {
        a /= g;
        g = __gcd(a, b);
        if(g == 1) break;
    }
    if(a == 1) cout<<"YES"<<endl;
    else cout<<"NO"<<endl;
}
int main() {
    int t;
    cin>>t;
    while(t--) solve();
    return 0;
}