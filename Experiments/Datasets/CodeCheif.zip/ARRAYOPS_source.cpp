#include <bits/stdc++.h>
#define mp make_pair
#define pb push_back
#define f first
#define s second
#define ll long long
#define forn(i, a, b) for(int i = (a); i <= (b); i++)
#define forev(i, b, a) for(int i = (b); i>=a;--i)
#define all(x) (x).begin(), (x).end()
#define sz(x) ((int)(x).size())
#define file(s) freopen(s".in", "r", stdin); freopen(s".out","w",stdout);
using namespace std;
const int maxn = (int)2e5 + 100;
const int mod = (int)1e9 + 7;
const int P = (int) 1e6 + 7;
const double pi = acos(-1.0);
#define inf (int)2e9
#define INF (ll)1e18
typedef long double ld;
typedef pair<int, int> pii;
typedef vector<int> vi;
typedef array<int, 3> triple;
int n, a[maxn], g;
vector<triple> oper;
inline void add(int type, int x, int y){
    oper.pb({type, x, y});
}
inline void normalize(int pos){
    while(a[pos] % 2 == 0) a[pos]/=2, add(1, pos, -1);
}
void solve(){
    oper.clear();
    cin>>n;
    g = 0;
    forn(i, 1, n){
        cin>>a[i];
        normalize(i);
        g = __gcd(g, a[i]);
    }
        if(g>1){
        cout<<"-1\n";
        return;
    }
        g = 0;
    vi good; //set of numbers with gcd = 1
    forn(i, 1, n){
        int base = 1, x = a[i];
        for(int p = 2; p*p <= x;p++){
            if(x % p == 0){
                while(x % p == 0) x/=p;
                base *= p;
            }
        }
        if(x > 1) base *= x;
                if(!g){
            g = base;
            good.pb(i);
        }
        if(__gcd(g, base) < g){
            g = __gcd(g, base);
            good.pb(i);
        }
        if(g==1)break;
            }
    assert(g == 1);
    assert(sz(good) <= 7);
    while(1){
        int mx = -1, mn = -1;
        for(auto pos: good){
            if(mx == -1 || a[mx] < a[pos])
                mx = pos;
            if(mn == -1 || a[mn] > a[pos])
                mn = pos;
        }
                if(a[mx] == 1) break;
        while(a[mn] != a[mx]){
            if(a[mx] < a[mn]) swap(mx, mn);
            a[mx] += a[mn];
            add(2, mx, mn);
            normalize(mx);
        }
    }
    forn(i, 1, n){
        if(a[i] == 1)continue;
        while(a[i]>1){
            add(2, i, good[0]);
            a[i]++;
            normalize(i);
        }
    }
    cout<<sz(oper)<<"\n";
    reverse(all(oper));
    for(auto x: oper){
        cout<<x[0]<<" "<<x[1];
        if(x[2] != -1) cout<<" "<<x[2];
        cout<<"\n";
    }
}
int main() {
    // your code goes here
    int t = 1;
    while(t--) solve();
    return 0;
}