#include <bits/stdc++.h>
#define endl '\n'
#define SZ(x) ((int)x.size())
#define ALL(V) V.begin(), V.end()
#define L_B lower_bound
#define U_B upper_bound
#define pb push_back
using namespace std;
template<class T, class T1> int chkmin(T &x, const T1 &y) { return x > y ? x = y, 1 : 0; }
template<class T, class T1> int chkmax(T &x, const T1 &y) { return x < y ? x = y, 1 : 0; }
const int MAXN = (1 << 20);
// Main observation is that {minimum(a[l..r]), maximum(a[l..r])} = {a[l], a[r]}   
// i.e. the minimum and maximum will be at the corners of the array 
template <class T>
struct fenwick {
    int sz;
    T tr[MAXN];
    void init(int n) {
        sz = n + 2;
        memset(tr, 0, sizeof(tr));
    }
    T query(int idx) {
        idx += 1;
        T ans = 0;
        for(; idx >= 1; idx -= (idx & -idx))
            ans += tr[idx];
        return ans;
    }
    void update(int idx, T val) {
        idx += 1;
        if(idx <= 0) return;
        for(; idx <= sz; idx += (idx & -idx))
            tr[idx] += val;
    }
    T query(int l, int r) { return query(r) - query(l - 1); }
};
int n;
int a[MAXN];
void read() {
    cin >> n;
    for(int i = 0; i < n; i++) {
        cin >> a[i];
    }
}
int nxt[MAXN];     // nxt[i] = min j such that i < j and a[i] > a[j]
fenwick<int> t;
vector<int> li[MAXN];
int64_t solve_() {
    for(int i = 0; i < n; i++) {
        li[i].clear();
    }
    t.init(n + 2);
    vector<int> st;
    for(int i = 0; i < n; i++) {
        while(!st.empty() && a[st.back()] <= a[i]) {
            st.pop_back();
        }
        if(st.empty()) {
            t.update(i, 1);
        } else {
            li[st.back()].pb(i);
        }
        st.pb(i);
    }
    st.clear();
    for(int i = n - 1; i >= 0; i--) {
        while(!st.empty() && a[st.back()] >= a[i]) {
            st.pop_back();
        }
        if(st.empty()) {
            nxt[i] = n;
        } else {
            nxt[i] = st.back();
        }
        st.pb(i);
    }
    int64_t ret = 0;
    for(int i = 0; i < n; i++) {
            ret += t.query(i, nxt[i] - 1);
        for(int j: li[i]) {
            t.update(j, 1);
        }
    }   
    return ret;
}
void solve() {
    // A neat way to implement it is to count the number of segments, where a[l] <= a[r]. Then reverse the array and find this count again.
    // However, there will be a problem that we count the subarrays with a[l] = a[r] twice, but those should have all of their values same, so 
    // we can find this count easily and then subtract it from the answer.
    int64_t answer = 0;
    answer += solve_();
    reverse(a, a + n);
    answer += solve_();
    // Subtrack overcounted subarrays.
    int cnt = 1;
    for(int i = 1; i < n; i++) {
        if(a[i] != a[i - 1]) {
            answer -= cnt * 1ll * (cnt + 1) / 2ll;
            cnt = 1;
        } else cnt++;
    }
    answer -= cnt * 1ll * (cnt + 1) / 2ll;
    cout << answer << endl;
}
int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    int T;
    cin >> T;
    while(T--) {
        read();
        solve();
    }
    return 0;
}