#include<iostream>
#include<algorithm>
#include<cstring>
#include<cstdio>
#include<bitset>
#include<cmath>
#include<ctime>
#include<queue>
#include<map>
#include<set>
#define int long long
#define fi first
#define se second
#define max Max
#define min Min
#define abs Abs
#define lc (x<<1)
#define rc (x<<1|1)
#define mid ((l+r)>>1)
#define pb(x) push_back(x)
#define lowbit(x) ((x)&(-(x)))
#define fan(x) ((((x)-1)^1)+1)
#define mp(x,y) make_pair(x,y)
#define clr(f,n) memset(f,0,sizeof(int)*(n))
#define cpy(f,g,n) memcpy(f,g,sizeof(int)*(n))
#define INF 0x3f3f3f3f
using namespace std;
inline int read()
{
    int ans=0,f=1;
    char c=getchar();
    while(c>'9'||c<'0'){if(c=='-')f=-1;c=getchar();}
    while(c>='0'&&c<='9'){ans=(ans<<1)+(ans<<3)+c-'0';c=getchar();}
    return ans*f;
}
inline void write(int x)
{
    if(x<0) putchar('-'),x=-x;
    if(x/10) write(x/10);
    putchar((char)(x%10)+'0');
}
template<typename T>inline T Abs(T a){return a>0?a:-a;};
template<typename T,typename TT>inline T Min(T a,TT b){return a<b?a:b;}
template<typename T,typename TT> inline T Max(T a,TT b){return a<b?b:a;}
const int N=1e6+5;
int t,n,a[N],b[N],all,k1,k2,tg[N];
struct Node
{
    int x,w;
    bool operator < (const Node &p)const
    {
        return w<p.w;
    }
};
signed main()
{
    t=read();
    while(t--)
    {
        n=read();all=0;
        for(int i=1;i<=n;++i)
            a[i]=read();
        for(int i=1;i<=n;++i)
            b[i]=read();
        for(int i=1;i<=n;++i)
        {
            int c=read();
            all+=c;a[i]-=c;b[i]-=c;
        }
        k1=read();k2=read();
        priority_queue<Node> q1,q2,q3;
        for(int i=1;i<=n;++i)
            if(a[i]>0) q1.push((Node){i,a[i]});
        while(k1&&!q1.empty())
        {
            all+=q1.top().w;--k1;
            tg[q1.top().x]=1;q1.pop();
        }
        for(int i=1;i<=n;++i)
            if(tg[i]) q2.push((Node){i,b[i]-a[i]});
            else if(!tg[i]) q3.push((Node){i,b[i]});
        while(k2&&(!q2.empty()||!q3.empty()))
        {
            while(!q1.empty()&&tg[q1.top().x]) q1.pop();
            while(!q3.empty()&&tg[q3.top().x]) q3.pop();
            if(q2.empty()&&q3.empty())
                break;
            if(q3.empty())
            {
                int s1=q2.top().w;
                if(!q1.empty()) s1+=q1.top().w;
                if(s1<=0)
                {
                    q2.pop();
                                        continue;
                }
                all+=s1;--k2;
                tg[q2.top().x]=2;
                q2.pop();
                if(!q1.empty())
                {
                    int tt=q1.top().x;
                    tg[tt]=1;q1.pop();
                    q2.push((Node){tt,b[tt]-a[tt]});
                }
                continue;
            }
            if(q2.empty())
            {
                int s2=q3.top().w;
                if(s2<=0)
                {
                    q3.pop();
                    continue;
                }
                all+=s2;--k2;
                tg[q3.top().x]=2;
                q3.pop();
                continue;
            }
            int s1=q2.top().w,s2=q3.top().w;
            if(!q1.empty()) s1+=q1.top().w;
            if(s1>=s2)
            {
                if(s1<=0)
                {
                    q2.pop();
                    continue;
                }
                all+=s1;--k2;
                tg[q2.top().x]=2;
                q2.pop();
                if(!q1.empty())
                {
                    int tt=q1.top().x;
                    tg[tt]=1;q1.pop();
                    q2.push((Node){tt,b[tt]-a[tt]});
                }
            }
            else
            {
                if(s2<=0)
                {
                    q3.pop();
                    continue;
                }
                all+=s2;--k2;
                tg[q3.top().x]=2;
                q3.pop();
            }
        }
        write(all);puts("");
        for(int i=1;i<=n;++i)
            tg[i]=0;
    }
    return 0;
}