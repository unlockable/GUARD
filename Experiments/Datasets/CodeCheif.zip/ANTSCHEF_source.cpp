#include <bits/stdc++.h>
using namespace std;
#define m_p make_pair
#define all(x) (x).begin(),(x).end()
#define sz(x) ((int)(x).size())
#define fi first
#define se second
typedef long long ll;
mt19937 rnd(chrono::steady_clock::now().time_since_epoch().count());
mt19937 rnf(2106);
const int N = 500005;
int n;
vector<int> d[N], b[N];
void solv()
{
    cin >> n;
    for (int i = 1; i <= n; ++i)
    {
        d[i].clear();
        b[i].clear();
    }
    map<int, int> mp;
    for (int i = 1; i <= n; ++i)
    {
        int q;
        cin >> q;
        while (q--)
        {
            int x;
            cin >> x;
            if (x > 0)
                d[i].push_back(x);
            else
                b[i].push_back(-x);
            ++mp[abs(x)];
        }
        reverse(all(d[i]));
    }
    ll ans = 0;
    for (int i = 1; i <= n; ++i)
    {
        while (1)
        {
            if (d[i].empty() && b[i].empty())
                break;
            if (!d[i].empty() && !b[i].empty() && d[i].back() == b[i].back())
            {
                ans += (sz(d[i]) - 1);
                ans += (sz(b[i]) - 1);
                d[i].pop_back();
                b[i].pop_back();
            }
            else if (b[i].empty() || (!d[i].empty() && d[i].back() < b[i].back()))
            {
                if (mp[d[i].back()] == 1)
                    ans += sz(b[i]);
                else
                    ans += (sz(d[i]) - 1);
                d[i].pop_back();
            }
            else
            {
                if (mp[b[i].back()] == 1)
                    ans += sz(d[i]);
                else
                    ans += (sz(b[i]) - 1);
                b[i].pop_back();
            }
        }
    }
    for (auto it = mp.begin(); it != mp.end(); ++it)
    {
        if (it->se >= 2)
            ++ans;
    }
    cout << ans << "\n";
}
int main()
{
    #ifdef SOMETHING
    freopen("input.txt", "r", stdin);
    //freopen("output.txt", "w", stdout);
    #endif // SOMETHING
    ios_base::sync_with_stdio(false), cin.tie(0);
    int tt = 1;
    cin >> tt;
    while (tt--)
    {
        solv();
    }
    return 0;
}