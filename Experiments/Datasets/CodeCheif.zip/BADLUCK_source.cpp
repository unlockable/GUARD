#include<bits/stdc++.h>
using namespace std;
#define ll long long int 
int main(){
    ios_base::sync_with_stdio(0);
    cin.tie(NULL);
    cout.tie(NULL);
    ll t;
    cin>>t;
    while(t--){
        ll n,l,u;
        cin>>n>>l>>u;
        vector<ll> v;
        for(ll i=0ll;i<n;i++){
            ll x;
            cin>>x;
            v.push_back(x);
        }
        // min
        sort(v.begin(),v.end());
        reverse(v.begin(),v.end());
        ll ans=0;
        ll ptrr=v[0];ll ptrl=0;
        for(ll i=0;i<n;i++){
            ll cur=i*l;
            if(cur>ptrr){
                ans+=ptrr-ptrl;
                ptrl=cur;
            }
            ptrr=max(ptrr,cur+v[i]);
        }
        ans+=ptrr-ptrl;
        cout<<ans<<" ";
        // max
        ans=v[0];
        ll sum=0;
        vector<ll> extra;
        for(ll i=1ll;i<n;i++){
            sum+=(v[i]/u)*u;
            extra.push_back(v[i]%u);
        }
        sum=min(sum,(n-1ll)*u);
        ans+=sum;
        if(sum<(n-1ll)*u){
            sort(extra.begin(),extra.end());
            reverse(extra.begin(),extra.end());
            for(ll i=0;i<n-1ll-(sum/u);i++){
                ans+=extra[i];
            }
        }
        cout<<ans<<"\n";
    }
}