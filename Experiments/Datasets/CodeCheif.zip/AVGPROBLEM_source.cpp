#include <iostream>
using namespace std;
int main() {
    // your code goes here
    int t;
    cin>>t;
    while(t--){
        float a,b,c;
        cin>>a>>b>>c;
        float s=(a+b)/2;
        if(s>c)
            cout<<"yes"<<endl;
        else
            cout<<"no"<<endl;
    }
        return 0;
}