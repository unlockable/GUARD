#include <bits/stdc++.h>
using namespace std;
#define int long long 
void solve(){
    int n,x;
    cin>>n>>x;
    int mini=1e11;
    int maxi=-1e11;
    for(int i=0;i<n;i++){
        int a;
        cin>>a;
        mini=min(a,mini);
        maxi=max(a,maxi);
    }
    if(mini<=x && maxi>=x){
        cout<<"YES"<<endl;
    }else{
        cout<<"NO"<<endl;
    }
        }
signed main() {
    // your code goes here
    int t;
    cin>>t;
    while(t--){
        solve();
    }
}