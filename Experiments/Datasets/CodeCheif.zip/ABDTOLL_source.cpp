#include<bits/stdc++.h>
#define ll long long int
#define mod 1000000007
#define fast ios_base::sync_with_stdio(false); cin.tie(NULL);cout.tie(NULL);
#define test ll t; cin>>t; while(t--)
#define pb push_back
#define all(x) (x).begin(),(x).end()
#pragma GCC optimize("Ofast")
#pragma GCC target("avx,avx2,fma")
using namespace std;
ll n,c=0,x;
vector<ll>v[10005];
bool vis[10005];
ll s[10005],tax[10005];
ll dfs(ll i)
{
    vis[i]=1;
    if(i!=x&&v[i].size()==1)
    return s[i]=tax[i];
        s[i]=tax[i];
        ll m=0;
    for(ll j:v[i])
    {
        if(!vis[j])
        m=max(m,dfs(j));
    }
    s[i]+=m;
    return s[i];
}
void dfs2(ll i,ll k)
{
    vis[i]=1;
    if(s[i]<=k)
    return;
    ll d=min(s[i]-k,tax[i]);
    c+=2*d;
    for(ll j:v[i])
    {
        if(!vis[j])
        {
            dfs2(j,k);
        }
    }
}
int main()
{fast;
test
{
    ll k,i,a,b;
cin>>n>>x>>k;
for(i=1;i<=n;i++)
v[i].clear();
c=0;
memset(vis,0,sizeof vis);
for(i=1;i<=n;i++)
cin>>tax[i];
for(i=0;i<n-1;i++)
{
    cin>>a>>b;
    v[a].pb(b);
    v[b].pb(a);
}
dfs(x);
memset(vis,0,sizeof vis);
dfs2(x,k);
cout<<c;
cout<<'\n';
}
    return 0;
}