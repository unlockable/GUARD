// templates.txt
// go to the end to view the (correct)soln
#include<bits/stdc++.h>
using namespace std;
#include "ext/pb_ds/assoc_container.hpp"
#include "ext/pb_ds/tree_policy.hpp"
using namespace __gnu_pbds;  // refer pbds.cpp for details
#define ordered_set tree<int, null_type,less<int>, rb_tree_tag,tree_order_statistics_node_update>
#define deb(x) cout << #x << " " << x << endl;
// cout << #x << " " << x << endl;
#define deb1(x) cout << #x << " ";
// cout << #x << " " << x << endl;
#define int long long 
#define pi pair<int, int>
#define pd pair<double, double>
#define TxtIO freopen("input.txt","r",stdin); freopen("output.txt","w",stdout);  
#define vpi vector<pi>
#define vs vector<string>
#define vvs vector<vs>
#define vc vector<char>
#define vvc vector<vc>
#define vb vector<bool>
#define vvb vector<vb>
#define vi vector<int>
#define vvi vector<vi>
#define vvvi vector<vvi>
#define vd vector<double>
#define vvd vector<vd>
#define umap unordered_map
#define uset unordered_set
#define chash custom_hash 
#define pq priority_queue
#define lb lower_bound
#define ub upper_bound
#define ins insert
#define pb push_back
#define eb emplace_back
#define all(a)                          ::begin(a),::end(a)
#define sz(X) (int)((X).size())
#define EACH(x, a) for(auto &x:a)
#define nl '\n'
#define Fo(i, n) for(int i=0; i<n; i++)
#define fo(i, a, b) for(int i=a; i<b; i++)  
int MOD=1000000007;
// int MOD=21945;
// int MOD=998244353;
char A=65, Z=90, lowerA=97, lowerZ=122;
string YES="YES\n", NO="NO\n";
const double PI=3.14159265358979323846;
const double epsilon=1e-9;
struct custom_hash {
    // use it like this : umap<int, int, chash> mapp;
    static uint64_t splitmix64(uint64_t x) {
        x+=0x9e3779b97f4a7c15;
        x=(x^(x>>30))*0xbf58476d1ce4e5b9;
        x=(x^(x>>27))*0x94d049bb133111eb;
        return x^(x>>31); \
    }
    size_t operator()(uint64_t x) const {
        static const uint64_t FIXED_RANDOM = chrono::steady_clock::now().time_since_epoch().count();
        return splitmix64(x+FIXED_RANDOM);
    }
};
template<class T> bool ckmin(T& a, const T& b) { return b<a ? a=b, 1 : 0; }
template<class T> bool ckmax(T& a, const T& b) { return a<b ? a=b, 1 : 0; }
template<class A> void read(vector<A>& v);
template<class A, size_t S> void read(array<A, S>& a);
template<class T> void read(T& x) { cin >> x; }
void read(double& d) {
    string t;  
    read(t);
    d=stod(t);
}
void read(long double& d) {
    string t;
    read(t);
    d=stold(t);
}
template<class H, class... T> void read(H& h, T&... t) {
    read(h);
    read(t...);
}
template<class A> void read(vector<A>& x) { EACH(a, x) read(a); }
template<class A, size_t S> void read(array<A, S>& x) { EACH(a, x) read(a); }
// template<typename... T>
// void write(T&&... args) {
//     ((cout << args << " "), ...);
// }  // eg : write(x, y, z, "im a good boi", 4.5, 6);
template<typename T>
bool f(T x, T y) { return x>y; }  // sort a vector in reverse manner : sort(all(vec), f<int>);
template<typename A, typename B>
int count(A vec, B ele, bool isSorted) {
    if(isSorted) {
        auto it1=upper_bound(vec.begin(), vec.end(), ele);
        auto it2=lower_bound(vec.begin(), vec.end(), ele); // kamala
        return it1-it2;
    }
    return count(vec.begin(), vec.end(), ele);
}
template <typename A> 
A myMax(A a,A b) {
    if(a>b) return a;
    return b;   
}
template <typename A, typename ... Args>
A myMax(A a, A b, Args ...args) { return myMax(myMax(a,b), args...); }
template <typename A> 
A myMin(A a, A b) {  
    if(a<b) return a;
    return b;
}
template <typename A, typename ... Args>
A myMin(A a, A b, Args ...args) { return myMin(myMin(a, b), args...); }
template<typename A, typename B>
void printMap(map<A, B> mapp) { for(auto ele : mapp) cout << ele.first << " : " << ele.second << '\n'; }
template<typename A, typename B>
void printUmap(umap<A, B> mapp) { for(auto ele : mapp) cout << ele.first << " : " << ele.second << '\n'; }
string to_string(char c) { return string(1, c); }
string to_string(bool b) { return b ? "true" : "false"; }
// -4
string strMap(int i, int j) { return to_string(i)+":"+to_string(j); }
// -3
int modExp(int b, int p) {
    // o(logp)
    int res=1;
    b=b%MOD;
    if(b==0) return 0;
    while(p>0) {
        if(p&1) res=(res*b)%MOD;
        p=p>>1;
        b=(b*b)%MOD;
    }
    return res;
}
// -2
int createPalindrome(int input, int b, bool isOdd) {
    int n=input;
    int palin=input;
    if(isOdd) n/=b;
    while(n>0) {
        palin=palin*b+(n%b);
        n/=b;
    }
    return palin;
}
// -1
void generatePalindromes(int n) {
    int number;
    // Run two times for odd and even length palindromes
    for(int j=0; j<2; j++) {
        int i=1;
        while((number=createPalindrome(i, 10, j%2))<n) {
            cout << number << " ";
            i++;
        }
    }
}
// 0
// int MAXN=1e6+1;
int MAXN1=1;
vi SPF(MAXN1);
void spf() { 
    // shortest prime factor
    // o(log n) time 
    SPF[1]=1;
    fo(i, 2, MAXN1) SPF[i]=i;
    for(int i=4; i<MAXN1; i+=2) SPF[i]=2;
    for(int i=3; i*i<MAXN1; i++) if(SPF[i]==i) for(int j=i*i; j<MAXN1; j+=i) if(SPF[j]==j) SPF[j]=i;
}
// 1
bool isPowerofTwo(int n) {
    if(n==0) return 0;
    if((n&(~(n-1)))==n) return 1;
    return 0;
}
// 2
int modDiv(int x) { 
    // if u want to find (n/x)%MOD, do n*modDiv(x);   o(log(MOD))
    int res=1, y=MOD-2; 
    x=x%MOD;
    while(y>0) {
        if(y&1) res=(res*x)%MOD;
        y=y>>1; 
        x=(x*x)%MOD;
    }
    return res;
}
// 3
int fact(int n) {
    if(n==0) return 1;
    int ans=n;
    for(int i=n-1; i>=1; --i) ans=ans*i;
    return ans;
}
// 4
int nc2(int n) { return (n*(n-1))/2; }
// 5
int nc3(int n) { return (n*(n-1)*(n-2))/6; } 
// 7
int bin_search(vi &vec, int no) {
    // finds the lower bound of "no" which is stored in "ele". make sure array is sorted!
    int n=vec.size();
    if(n==1) return -1;
    int i=0, j=vec.size()-1;  // changed j=vec.size() to j=vec.size()-1
    int ele, ele2;
    if(vec[0]>=no) return vec[0];
    if(vec.back()<no) return -1;
    while(i<=j) {
        int mid=(i+j)/2;
        int el=vec[mid];
        if(mid-1<n&&el>=no&&vec[mid-1]<no) {
            ele=vec[mid];
            ele2=vec[mid-1];
            break;
        } else if(el<no) i=mid+1;
        else j=mid-1;
    }
    return ele;
}
// 8
int bin_search(int l, int r) {
    // find the smallest value between l and r that satisfies a given condition
    while(l<=r) {
        int mid=(l+r)/2;
        // check whether 'mid' satisfies the given condition
        bool condition;
        // condition doesnt satisfy
        if(condition) l=mid+1; 
        else r=mid-1;    
    }
    return l;
}
// 9
vi primeFactors(int n) {
    // this returns primes in this fashion : if 4 is a factor of n, then the returned vector contains 2 twos
    // o(sqrt(x)/logx)
    // if n is 1e9, then this TLEs. use colin's number theory template
    vi ans;
    while(!(n&1)) {        
        ans.pb(2);
        n=n/2;
    }
    for(int i=3; i<=(int)round(sqrt(n)); i=i+2) {            
        while(n%i==0) {
            ans.pb(i);
            n=n/i;
        }
    }        
    if(n>2) ans.pb(n);
    return ans;
}
// 10
vi factors(int n) {
    // o(sqrtn)  // includes 1 and n too
    vi ans;
    for(int i=1; i<=(int)round(sqrt(n)); i++) {
        if(n%i==0) {
            if(n/i==i) ans.pb(i);
            else {
                ans.pb(i); 
                ans.pb(n/i);
            }
        }
    }
    return ans;
}
// 11
int lcm(int a, int b) { return (a*b)/__gcd(a, b); }
// 12
template<typename A>
A prefixSums(A vec) {
    // modify this function to get prefix sums. this version of prefixSums is used to find the no of 
    // occurences upto a certain position
    int n=sz(vec);
    A ans(n+1);
    ans[0]=0;
    ans[1]=vec[0];
    fo(i, 2, n+1) ans[i]=ans[i-1]+vec[i-1];
    return ans;
}
// 13
// kth bit from right(lsb) 1st bit, 2nd bit and so on
bool kthbit(int n, int k) { return (n>>(k-1))&1; }
// 14
bool isPrime(int n) {
    // sqrt(n)/log(n)
    vi primes=primeFactors(n);
    if(sz(primes)==1) return true;
    return false;
}
// 15
bool isSubSequence(string s1, string s2) {  
    // O(n)
    int j=0;
    int m=sz(s1), n=sz(s2);
    for(int i=0; i<n&&j<m; i++) if(s1[j]==s2[i]) j++;
    return j==m;
}
// 16
int nearestPowerOf2(int n) { return (1<<(63-__builtin_clzll(n))); }
// 17
void toUpper(string &s) { transform(all(s), s.begin(), ::toupper); }
// 18
void toLower(string &s) { transform(all(s), s.begin(), ::tolower); }
// 19
vi sieveOfEratosthenes(int n) {
    // o(nlog(logn))
    bool prime[n+1];
    memset(prime, true, sizeof(prime));
    for(int p=2; p*p<=n; p++) if(prime[p]==true) for(int i=p*p; i<=n; i+=p) prime[i]=false;
    vi ans;
    for(int p=2; p<=n; p++) if(prime[p]) ans.pb(p);
    return ans;
}
// 20
vb segmentedSieve(int L, int R) {
    // O((R-L)loglogR)
    // returns a vector denoting which aint nos in the range [L, R] is prime
    int lim = sqrt(R);
    vb mark(lim+1, false);
    vi primes;
    fo(i, 2, lim+1) {
        if(!mark[i]) {
            primes.emplace_back(i);
            for(int j=i*i; j<=lim; j+=i) mark[j]=true;
        }
    }
    vb isPrime(R-L+1, true);
    EACH(i, primes) for(int j=max(i*i, (L+i-1)/i*i); j<=R; j+=i) isPrime[j-L]=false;
    if(L==1) isPrime[0]=false;
    return isPrime;
}
// 21
template <typename A>
pair<A, int> maxIntersectingPt(vector<A> start, vector<A> end) {
    // returns the point where most intervals intersect followed by the no of intervals that intersect that point
    // o(nlogn)
    int n=sz(start);
    sort(all(start));
    sort(all(end));
    int guests_in=1, max_guests=1;
    A time=start[0];
    int i=1, j=0;
    while(i<n&&j<n) {
        if(start[i]<=end[j]) {
            guests_in++;
            if(guests_in>max_guests) {
                max_guests=guests_in;
                time=start[i];
            }
            i++;  
        }
        else {
            guests_in--;
            j++;
        }
    }
    return {time, max_guests};
}
// 22
int LongestNonDecreasingSubsequenceLength(vi v) {
    // o(nlogn)
    if(sz(v)==0) return 0;
    vi tail(sz(v), 0);
    int length=1;
    tail[0]=v[0];
    for(int i=1; i<sz(v); i++) {
        auto b=tail.begin(), e=tail.begin()+length;
        // for longestIncreasingSubsequence, change upper_bound to lower_bound
        auto it=upper_bound(b, e, v[i]);
        if(it==tail.begin()+length) tail[length++]=v[i];
        else *it=v[i];
    }
    return length;
}
// 23
int minSwapsToSort(vi arr) {
    // nlogn
    int ans=0;
    vi temp=arr;    
    map<int, int> h;
    sort(all(temp));
    int n=sz(arr);
    fo(i, 0, n) h[arr[i]]=i;
    fo(i, 0, n) {
        if(arr[i]!=temp[i]) {
            ans++;
            int init=arr[i];
            swap(arr[i], arr[h[temp[i]]]);
            h[init]=h[temp[i]];
            h[temp[i]]=i;
        }
    }
    return ans;
}
// 24
template <typename T>
bool isPal(T &s) {
    int n=sz(s);
    bool ok=true;
    fo(i, 0, sz(s)/2) if(s[i]!=s[n-i-1]) ok=false;
    return ok;
}
// 25
int minimizeMaxSubarraySum(vi& arr, int K) {
    // split the subarray into k subarrays and minimize the maximum subarray sum and return that sum
    // O(nlog(sum))
    int n=sz(arr);
    int start=*max_element(all(arr));
    int end=0;
    fo(i, 0, n) end+=arr[i];   
    int answer=0;
    while(start<=end) {
        int mid=(start+end)/2;
        bool flag;
        int count=0;
        int sum=0;
        fo(i, 0, n) {
            if(arr[i]>mid) flag=false;
            sum+=arr[i];
            if(sum>mid) {
                count++;
                sum=arr[i];
            }
        }
        count++;
        if(flag) {
            if(count<=K) flag=true;
            else flag=false;
        }
        if(flag) {
            answer=mid;
            end=mid-1;
        }
        else start=mid+1;
    }
    return answer;
}
// 26
int kadane(vi v) {
    // O(n)
    int n=sz(v);
    int maxSoFar=LLONG_MIN, maxEndingHere=0;
    fo(i, 0, n) {
        maxEndingHere=maxEndingHere+v[i];
        if(maxSoFar<maxEndingHere) maxSoFar=maxEndingHere;
        if(maxEndingHere<0) maxEndingHere=0;
    }
    return maxSoFar;
}
// 27
vi unsortedRange(vi arr) {
    // o(n)
    int n=sz(arr), s=0, e=n-1, i, max, min;    
    for(s=0; s<n-1; s++) if(arr[s]>arr[s+1]) break;
    for(e=n-1; e>0; e--) if(arr[e]<arr[e-1]) break;
    max=arr[s]; min=arr[s];
    for(i=s+1; i<=e; i++) {
        if(arr[i]>max) max=arr[i];
        if(arr[i]<min) min=arr[i];
    }
    for(i=0; i<s; i++) {
        if(arr[i]>min) {
            s=i;
            break;
        }    
    }
    for(i=n-1; i>=e+1; i--) {
        if(arr[i]<max) {
            e=i;
            break;
        }
    }
    return {s, e};
}
// 28
template <typename A>
vector<vector<A>> getDiagonals(vector<vector<A>> arr) {
    int n=sz(arr);
    int m=sz(arr[0]);
    // o(n, m)
    int C=sz(arr[0]);
    int R=sz(arr);
    vector<vector<A>> v;
    for(int k=0; k<R; k++) {
        vector<A> temp;
        temp.pb(arr[k][0]);
        int i=k-1;
        int j=1;
        while(!(i<0||i>=R||j>=C||j<0)) {
            temp.pb(arr[i][j]);
            i--;           
            j++;
        }
        v.pb(temp);
    }
    for(int k=1; k<C; k++) {
        vector<A> temp;
        temp.pb(arr[R-1][k]);
        int i=R-2;
        int j=k+1;
        while(!(i<0||i>=R||j>=C||j<0)) {
            temp.pb(arr[i][j]);
            i--;
            j++;
        }
        v.pb(temp);
    }
    return v;
}
// 29
int knapsack(int W, vi wt, vi val) {
    // o(nW)
    int n=sz(wt);
    int dp[W+1];
    memset(dp, 0, sizeof(dp));
    for(int i=1; i<n+1; i++) for(int w=W; w>=0; w--) if(wt[i-1]<=w) dp[w]=max(dp[w], dp[w-wt[i-1]]+val[i-1]);
    return dp[W]; 
}
template <typename A>
void printArray(A v) {
    for(auto ele : v) cout << ele << ' ';
    cout << nl;
}
// 30
int coinChange(vi S, int n) {        
    // o(mn)       
    int m=sz(S);    
    vi table(n+1);
    table[0]=1;         
    for(int i=0; i<m; i++)         
    for(int j=S[i]; j<=n; j++)         
    table[j]=table[j-S[i]]+table[j];        
    return table[n];         
}
// 31
bool areBracketsBalanced(string expr) { 
    // o(n)
    stack<char> temp;
    fo(i, 0, expr.length()) {
        if(temp.empty()) temp.push(expr[i]);
        else if((temp.top()=='('&& expr[i]==')')||(temp.top()=='{'&&expr[i]=='}')||  (temp.top()=='['&&expr[i]==']')) temp.pop();
        else temp.push(expr[i]);
    }
    if(temp.empty()) return true;
    return false;
}
// 32
int nCrMod(int n, int r) {
    // o(n)
    if (n<r) return 0;
    if(r==0) return 1;
    vi fac(n+1, 1);
    fo(i, 1, n+1) fac[i]=(fac[i-1]*i)%MOD;    
    return (fac[n]*modDiv(fac[r])%MOD*modDiv(fac[n-r])%MOD)%MOD; // take MOD of divisor
}
// 33
void bfs(int s, vvi &adj) { //can be used without adj too like this prblem:codeforces.com/contest/1681/problem/D
    // o(v+e). can return int too
    deque<int> q;  // can be of any DS other than int like pairs
    map<int, bool> vis;  // can be a vector too
    q.push_back(s);  
    vis[s]=true;
    while(sz(q)) {
        s=q.front();
        q.pop_front();
        for(auto adjacent : adj[s]) {
            if(!vis[adjacent]) {
                vis[adjacent]=true;
                q.pb(adjacent);
            }
        }
    }
}
// 34
vi printNGE(vi &arr) {
    // o(n)
    int n=sz(arr);
    stack<int> s;
    vi res(n);
    for(int i=n-1; i>=0; i--) {
        while(!s.empty()&&s.top()<=arr[i]) s.pop();
        res[i]=s.empty() ? -1 : s.top();
        s.push(arr[i]);
    }
    return res;
}
// 35
int lcm(vi arr) {
    // o(nlog(min(v[i]))). overflow resistive(not true). u cant use modular arithmetic here(WA)
    int ans=arr[0];
    int n=sz(arr);
    fo(i, 1, n) ans=(arr[i]*ans)/__gcd(arr[i], ans);
    return ans;
}
// 37
int gcd_of_lcm(vi& arr) {
    // o(nlog(max(arr[i])))
    int n=sz(arr);
    vi suff(n, 1);
    suff[n-1]=arr[n-1];
    for(int i=n-2; i>=0; i--) suff[i]=__gcd(arr[i], suff[i+1]);
    vi LCM;
    fo(i, 0, n-1) {
       int y=lcm(arr[i], suff[i+1]);
       LCM.push_back(y);
    }
    int ans=LCM[0];
    fo(i, 1, n-1) ans=__gcd(ans, LCM[i]);
    return ans;
}
// complexities recorded till this point
int sumArray(vi& v) {
    int sum=0;
    for(auto ele : v) sum+=ele;
    return sum;
}
int power(int a, int b) {
    int ele=1;
    fo(i, 1, b+1) ele=((a*ele));
    return ele;
}
int floorSqrt(int a) {
    int b=a, x=0, y=0;
    for(int e=(63-__builtin_clzll(a))&~1; e>=0; e-=2) {
        x<<=1;
        y<<=1;
        if(b>=(y|1)<<e) {
            b-=(y|1)<<e;
            x|=1;
            y+=2;
        }
    }
    return x;
}
int ceilSqrt(int n) {
    int res=floorSqrt(n);
    if(res*res!=n) return res+1;
    return res;
}
int floorDiv(int a, int b) {
    if(b==0) {
        cerr << "Dont divide by 0";
        exit(1);
    }
    return (int)floor((double)a/b);
}
bool hasLeadingZeros(string& s) {
    if(s=="0") return false;
    else if(s[0]=='0') return true;
    return false;
}
void solve() {}
int query(int l) { 
    cout << "? " << l << endl;
    return 0;
}   
void print_ans() {
    cout << "! ";
}   
int32_t main() {
    // TxtIO;
    ios::sync_with_stdio(false);
    cin.tie(NULL);
    cout << setprecision(15) << fixed;
    int TT=1; 
    read(TT);
    while(TT--) {
        // 1600
        // sh run(as admin)
        // 522
        int n; read(n);
        vs v(n); read(v);
        vi a(n), b(n);
        fo(i, 0, n) {
            string s1, s2;
            fo(j, 0, sz(v[i])) {
                char ch=v[i][j];
                if(ch!='/') {
                    s1.pb(ch);
                } else {
                    fo(k, j+1, sz(v[i])) {
                        s2.pb(v[i][k]);
                    }
                    break;
                }
            }
            a[i]=stoll(s1);
            b[i]=stoll(s2);
        }
        int nxt[n+1];
        nxt[n]=n;
        // 231
        for(int i=n-1; i>=0; --i) {
            int j=i+1;
            while(j<n&&1.0*(a[i]+a[j])/(b[i]+b[j])>1.0*a[i]/b[i]) {
                a[i]+=a[j];
                b[i]+=b[j];
                j=nxt[j];
            }
            nxt[i]=j;
        }
        fo(i, 0, n) {
            int g=__gcd(a[i], b[i]);
            a[i]/=g; b[i]/=g;
            cout << a[i] << '/' << b[i] << nl;
        }
    } 
}
// miscellaneous funs found in templates.cpp