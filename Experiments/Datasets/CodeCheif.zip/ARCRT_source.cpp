#include <bits/stdc++.h>
using namespace std;
#define sz(x) (int)x.size()
#define fi first
#define se second
typedef long long lli;
typedef pair<int, int> pii;
struct splayNode {
    array<int, 2> child{};
    int parent = 0;
    bool flip = 0;
    int sub = 0, vir = 0, self = 0;
};
struct splayTree {
    vector<splayNode> T;
    splayTree() {}
    splayTree(int n) : T(n + 1) {}
    void pull(int x) {
        int l = T[x].child[0], r = T[x].child[1];
        push(l); push(r);
        T[x].sub = T[l].sub + T[r].sub + T[x].vir + T[x].self;
    }
    void push(int x) {
        if(!x || !T[x].flip) return;
        int l = T[x].child[0], r = T[x].child[1];
        T[l].flip ^= 1; T[r].flip ^= 1;
        swap(T[x].child[0], T[x].child[1]);
        T[x].flip = 0;
    }
    int side(int x) {
        int p = T[x].parent;
        if(!p) return -1;
        return T[p].child[0] == x ? 0 : T[p].child[1] == x ? 1 : -1;
    }
    void attach(int x, int d, int y) {
        T[x].child[d] = y; T[y].parent = x;
        pull(x);
    }
    void rotate(int x) {
        int y = T[x].parent, z = T[y].parent;
        int dx = side(x), dy = side(y);
        attach(y, dx, T[x].child[!dx]);
        attach(x, !dx, y);
        if(~dy) {
            attach(z, dy, x);
        }
        else {
            T[x].parent = z;
        }
    }
    void splay(int x) {
        push(x);
        for(; ~side(x); ) {
            int y = T[x].parent, z = T[y].parent;
            int dx = side(x), dy = side(y);
            push(z); push(y); push(x);
            if(~dy) {
                rotate(dx == dy ? y : x);
            }
            rotate(x);
        }
    }
};
struct linkCut : splayTree {
    linkCut() {}
    linkCut(int n) : splayTree(n) {}
    int access(int x) {
        int u = x, v = 0;
        for(; u; v = u, u = T[u].parent) {
            splay(u);
            int&ov = T[u].child[1];
            T[u].vir += T[ov].sub;
            T[u].vir -= T[v].sub;
            ov = v;
            pull(u);
        }
        splay(x);
        return v;
    }
    void reroot(int x) {
        access(x); T[x].flip ^= 1; push(x);
    }
    int root(int u) {
        access(u);
        push(u);
        for(; T[u].child[0]; u = T[u].child[0], push(u));
        return u;
    }
    int component_size(int u) {
        access(u);
        return T[u].sub;
    }
    void Link(int u, int v) {
        reroot(u); access(v);
        T[u].parent = v;
        T[v].vir += T[u].sub;
        pull(v);
    }
    void Cut(int u, int v) {
        reroot(u); access(v);
        T[u].parent = T[v].child[0] = 0;
        pull(v);
    }
    int LCA(int u, int v) {
        reroot(u); int ret = access(v);
        return T[u].parent ? ret : 0;
    }
    void Update(int u, int x) {
        access(u);
        T[u].self = x;
        pull(u);
    }
};
const int maxn = 2e5 + 5;
const int mod = 1e9 + 7;
int powmod(int x, int k) {
    if(k == 0) return 1;
    int t = powmod(x, k / 2);
    if(k % 2 == 0) return t * 1LL * t % mod;
    else return t * 1LL * t % mod * x % mod;
}
int inv(int x) {
    return powmod(x, mod - 2);
}
int n, a[maxn], b[maxn];
vector<int> vals;
void read_input() {
    cin >> n;
    vals.clear();
    for(int i = 1; i <= n; ++i) {
        cin >> a[i];
        vals.push_back(a[i]);
    }
    for(int i = 1; i <= n; ++i) {
        cin >> b[i];
        vals.push_back(b[i]);
    }
}
int ans;
linkCut LCT;
int cycle_edge[maxn];
int cnt_cycle;
bool match(int i) {
    int x = LCT.root(a[i]), y = LCT.root(b[i]);
    if(cycle_edge[x] != -1 && cycle_edge[y] != -1) {
        return false;
    }
    if(x == y) {
        cycle_edge[x] = i;
        ++cnt_cycle;
        ans = ans * 1LL * inv(LCT.component_size(x)) % mod;
    }
    else {
        int add_e = cycle_edge[x] != -1 ? cycle_edge[x] : cycle_edge[y];
        if(cycle_edge[x] == -1) ans = ans * 1LL * inv(LCT.component_size(x)) % mod;
        if(cycle_edge[y] == -1) ans = ans * 1LL * inv(LCT.component_size(y)) % mod;
        cycle_edge[x] = cycle_edge[y] = -1;
        LCT.Link(a[i], b[i]);
        if(add_e == -1) {
            ans = ans * 1LL * LCT.component_size(a[i]) % mod;
        }
        cycle_edge[LCT.root(a[i])] = add_e;
    }
    return true;
}
void solve() {
    sort(vals.begin(), vals.end());
    vals.erase(unique(vals.begin(), vals.end()), vals.end());
    int m = sz(vals);
    for(int i = 1; i <= n; ++i) {
        a[i] = lower_bound(vals.begin(), vals.end(), a[i]) - vals.begin() + 1;
        b[i] = lower_bound(vals.begin(), vals.end(), b[i]) - vals.begin() + 1;
    }
    fill(cycle_edge + 1, cycle_edge + m + 1, -1);
    LCT = linkCut(m);
    ans = 1;
    cnt_cycle = 0;
    for(int i = 1; i <= m; ++i) LCT.Update(i, 1);
    int cnt_self = 0;
    for(int i = 1, j = 1; i <= n; ++i) {
        while(j <= n && match(j)) {
            if(a[j] == b[j]) ++cnt_self;
            ++j;
        }
        cout << ans * 1LL * powmod(2, cnt_cycle - cnt_self) % mod << ' ';
        if(a[i] == b[i]) --cnt_self;
        int r = LCT.root(a[i]);
        if(cycle_edge[r] == i) {
            --cnt_cycle;
            cycle_edge[r] = -1;
            ans = ans * 1LL * LCT.component_size(r) % mod;
        }
        else {
            int add_e = cycle_edge[r];
            cycle_edge[r] = -1;
            if(add_e != -1) {
                --cnt_cycle;
                ans = ans * 1LL * LCT.component_size(r) % mod;
            }
            ans = ans * 1LL * inv(LCT.component_size(r)) % mod;
            LCT.Cut(a[i], b[i]);
            ans = ans * 1LL * LCT.component_size(a[i]) % mod;
            ans = ans * 1LL * LCT.component_size(b[i]) % mod;
            if(add_e != -1) match(add_e);
        }
    }
    cout << '\n';
}
int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    #ifdef LOCAL
        freopen("test.inp", "r", stdin);
        freopen("test.out", "w", stdout);
    #endif // LOCAL
    int ntest = 1;
    cin >> ntest;
    while(ntest--) {
        read_input();
        solve();
    }
}