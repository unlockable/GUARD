#include <iostream>
using namespace std;
int main() {
    // your code goes here
    int c;
    cin>>c;
    if(c<=1000) cout<<"Yes"<<endl;
    else cout<<"No"<<endl;
        return 0;
}