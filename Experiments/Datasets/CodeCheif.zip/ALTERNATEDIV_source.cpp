#include <iostream>
using namespace std;
int main() {
    // your code goes here
        ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);
        int t;
    cin >> t;
    while (t--)
    {
        int n;
        cin >> n;
        int arr[n];
        if (n == 1)
        {
            cout << 1 << "\n";
        }
        else if (n == 2)
        {
            cout << "1 2\n";
        }
        else if (n == 3)
        {
            cout << "1 2 3\n";
        }
        else if (n == 4)
        {
            cout << "1 2 3 6\n";
        }
        else 
        {
            for (int i = 1; i <= n; i++)
            {
                if (i % 2 == 1)
                {
                    cout << i << " ";
                }
                else
                {
                    cout << 2 * (i - 1) << " ";
                }
            }
            cout << "\n";
        }
    }
        return 0;
}