#include <iostream>
using namespace std;
int main(){
    int t;
    cin >> t;
    while(t--){
        int x,y;
        cin >> x >> y;
        if(x%2!=0){cout << y << " "; x--;}
        int ct =1;
        while(x>=2){
            cout << y+ct << " " << y-ct << " ";
            ct++;
            x -= 2;
        }
        cout << "\n";
    }
}