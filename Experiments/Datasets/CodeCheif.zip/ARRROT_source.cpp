#include<bits/stdc++.h>
using namespace std;
#define int long long
const int N=1e9+7;
signed main(){
    int a;cin>>a;
    vector<int>v;
    int sum=0;
    for(int i=0;i<a;i++){
        int x;cin>>x;
        v.push_back(x);
        sum+=x;
        sum=((sum%N)+N)%N;
    }
    int q;cin>>q;
    while(q--){
        int k;cin>>k;
        sum+=sum;
        sum=((sum%N)+N)%N;
        cout<<sum<<endl;
    }
}