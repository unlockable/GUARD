#define _GLIBCXX_FILESYSTEM
#include <bits/stdc++.h>
using namespace std;
int main()
{
    //freopen("stacking.in", "r", stdin);
    //freopen("stacking.out", "w", stdout);
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    int t,n,q,l,r;
    cin>>t;
    while (t--){
        cin>>n>>q;
        vector<int> v(n,0);
        while (q--){
            cin>>l>>r;
            l--;r--;
            v[l]++;
            if (r+1<n) v[r+1]-=r-l+2;
            if (r+2<n) v[r+2]+=r-l+1;
        }
        for (int i=1;i<n;i++) v[i]+=v[i-1];
        for (int i=1;i<n;i++) v[i]+=v[i-1];
        for (int i=0;i<n;i++) cout<<v[i]<<(i==n-1?'\n':' ');
    }
}