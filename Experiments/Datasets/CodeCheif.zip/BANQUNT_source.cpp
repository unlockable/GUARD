#include <iostream>
#include <string>
#include <vector>
#include <algorithm>
#include <sstream>
#include <queue>
#include <deque>
#include <bitset>
#include <iterator>
#include <list>
#include <stack>
#include <map>
#include <set>
#include <functional>
#include <numeric>
#include <utility>
#include <limits>
#include <time.h>
#include <math.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unordered_map>
#include <unordered_set>
using namespace std;
#ifdef ONLINE_JUDGE
    #define endl "\n"
#endif
#define gcd(a,b) __gcd(a,b)
#define all(cont) cont.begin(), cont.end()
#define rall(cont) cont.end(), cont.begin()
#define rsort(x) sort(x,[](auto a, auto b){rtn a > b;});
#define forr(i,v) for (int i = 0; i < v; i++)
#define each(x,v) for (auto x: v)
#define forrr(i,j,v,w) for (int i = 0; i < v; i++) for (int j = 0; j < w; j++)
#define ni(x) int x; cin >> x;
#define nii(x,y) int x,y; cin >> x >> y;
#define niii(x,y,z) int x,y,z; cin >> x >> y >> z;
#define niiii(w,x,y,z) int w,x,y,z; cin >> w >> x >> y >> z;
#define nl(x) ll x; cin >> x;
#define nll(x,y) ll x,y; cin >> x >> y;
#define nlll(x,y,z) ll x,y,z; cin >> x >> y >> z;
#define nllll(w,x,y,z) ll w,x,y,z; cin >> w >> x >> y >> z;
#define nd(x) double x; cin >> x;
#define ndd(x,y) double x,y; cin >> x >> y;
#define nddd(x,y,z) double x,y,z; cin >> x >> y >> z;
#define ndddd(w,x,y,z) double w,x,y,z; cin >> w >> x >> y >> z;
#define ns(x) str x; cin >> x;
#define nss(x,y) str x,y; cin >> x >> y;
#define nsss(x,y,z) str x,y,z; cin >> x >> y >> z;
#define nc(x) char x; cin >> x;
#define ncc(x,y) char x, y; cin >> x >> y;
#define nccc(x,y,z) char x, y, z; cin >> x >> y >> z;
#define get(v) vi v(n);forr (i,n) cin >> v[i];
#define imax(a,b) a = max(a,b);
#define imin(a,b) a = min(a,b);
#define mp make_pair
#define pb push_back
#define ff first
#define ss second
#define rz resize
#define sz size()
#define cnt continue
#define brk break
#define rtn return
#define W() int T; cin >> T; while(T--)
#define trace(x) cerr<<#x<<": "<<x<<endl;
#define output()
#define ff first
#define float double
typedef long int int32;
typedef unsigned long int uint32;
typedef long long int int64;
typedef unsigned long long int  uint64;
typedef long long ll;
typedef string str;
typedef pair<int, int> pii;
typedef pair<ll, ll> pll;
typedef pair<double, double> pdd;
typedef vector<double> vd;
typedef vector<bool> vb;
typedef vector<ll> vl;
typedef vector<int> vi;
typedef vector<pii> vpii;
typedef vector<pdd> vpdd;
typedef vector<vpii> vppii;
typedef vector<vi> vii;
typedef vector<vb> vbb;
typedef vector<vd> vdd;
typedef vector<vl> vll;
typedef map<int,int> mpii;
typedef set<int> seti;
typedef set<ll> setl;
typedef set<pair<int,int>> spii;
typedef vector<set<int>> vseti;
const ll linf = 1000000000000000010;
const int inf = 1000000010;
const int MAXN = 1e5+5;
const int LOGN = 18;
const double eps = 1e-9;
const double pi = 3.1415926535897932384626433832795;
const int mod = 998244353;
const int base = 31;
ll max(ll a, ll b){
    return a > b ? a : b;
}
ll min(ll a, ll b){
    return a < b ? a : b;
}
int count1(int x){
    rtn __builtin_popcount(x);
}
int count1(ll x){
    rtn __builtin_popcountll(x);
}
template<typename T, typename U>
void nout(pair<T,U> p);
template<typename T, typename U>
void out(pair<T,U> p);
template<typename T>
void nout(vector<T> v);
template<typename T>
void out(vector<T> v);
template<typename T>
void nout(set<T> s);
template<typename T>
void out(set<T> s);
template<typename T>
void nout(unordered_set<T> s);
template<typename T>
void out(unordered_set<T> s);
template<typename T>
void nout(multiset<T> s);
template<typename T>
void out(multiset<T> s);
template<typename T, typename U>
void nout(map<T,U> m);
template<typename T, typename U>
void out(map<T,U> m);
template<typename T, typename U>
void nout(unordered_map<T,U> m);
template<typename T, typename U>
void out(unordered_map<T,U> m);
template<typename T>
void nout(T v[], int n);
template<typename T>
void out(T v[], int n);
template<typename T>
void nout(T x){
    cerr << x;
}
template<typename T>
void out(T x){
    nout(x);cerr << " ";
}
template<typename T, typename U>
void nout(pair<T,U> p){
    cerr << "<";nout(p.ff);cerr << ",";nout(p.ss);cerr << ">";
}
template<typename T, typename U>
void out(pair<T,U> p){
    nout(p);cerr << " ";
}
template<typename T>
void nout(vector<T> v){
    out("{");
    each (x,v) {
        out(x);
    }
    nout("}");
}
template<typename T>
void out(vector<T> v){
    nout(v);
    cerr << endl;
}
template<typename T>
void nout(set<T> s){
    for (T x:s){
        out(x);
    }
}
template<typename T>
void out(set<T> s){
    nout(s);
    cerr << endl;
}
template<typename T>
void nout(unordered_set<T> s){
    each (x,s){
        out(x);
    }
}
template<typename T>
void out(unordered_set<T> s){
    nout(s);
    cerr << endl;
}
template<typename T>
void nout(multiset<T> s){
    each (x,s){
        out(x);
    }
}
template<typename T>
void out(multiset<T> s){
    nout(s);
    cerr << endl;
}
template<typename T, typename U>
void nout(map<T,U> m){
    each (x,m){
        cerr << "[";nout(x.ff);cerr << "=>";nout(x.ss);cerr << "]";
    }
}
template<typename T, typename U>
void out(map<T,U> m){
    nout(m);
    cerr << endl;
}
template<typename T, typename U>
void nout(unordered_map<T,U> m){
    each (x,m){
        cerr << "[";nout(x.ff);cerr << "=>";nout(x.ss);cerr << "]";
    }
}
template<typename T, typename U>
void out(unordered_map<T,U> m){
    nout(m);
    cerr << endl;
}
template<typename T>
void nout(T v[], int n){
    forr (i,n){
        out(v[i]);
    }
}
template<typename T>
void out(T v[], int n){
    nout(v,n);
    cerr << endl;
}
int add(int a, int b){
    int res = (a+b) % mod;
    if (res < 0)
        res += mod;
    rtn res;
}
void iadd(int &a, int b){
    a = add(a,b);
}
int mul(int a, int b){
    int res = (a * 1LL * b) % mod;
    if (res < 0)
        res += mod;
    rtn res;
}
void imul(int &a, int b){
    a = mul(a,b);
}
int power(int a, ll b){
    int res = 1;
    while(b){
        if (b % 2)
            res = mul(res,a);
        a = mul(a,a);
        b /= 2;
    }
    rtn res;
}
void ipower(int &a, int b){
    a = power(a,b);
}
ll npow(ll a, ll b){
    ll res = 1;
    while(b){
        if (b % 2)
            res *= a;
        a *= a;
        b /= 2;
    }
    rtn res;
}
int inv(int x){
    rtn x == 1 ? 1 : power(x,mod-2);
}
void iinv(int &x){
    x = inv(x);
}
template<typename T>
void igcd(T &g, T x){
    g = gcd(g,x);
}
void ans (str x){
    cout << x << endl;
}
void ans (const char* x){
    cout << x << endl;
}
template<typename T>
void ans (vector<T> v){
    for (T x:v){
        cout << x << " ";
    }
    cout << endl;
}
template<typename T>
void ans (T x){
    cout << x << endl;
}
void ans (bool x){
    ans(x ? "YES" : "NO");
}
bool isPrime(int x)
{
    int primes[168] = {2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61, 67, 71, 73, 79, 83, 89, 97, 101, 103, 107, 109, 113, 127, 131, 137, 139, 149, 151, 157, 163, 167, 173, 179, 181, 191, 193, 197,                                                                                                                           
    int j = 0;
    while (primes[j] < floor(sqrt(x)) + 1)
    {
        if (x % primes[j] == 0)
        {
            return false;
        }
        j++;
    }
    return true;
}
void sieve(int n=1000005){
    bool p[1000005];
    memset(p,1,sizeof(p));
    p[0] = p[1] = 0;
    for (int i = 2; i * i < n; i++){
        if (p[i]){
            for (int j = 2 * i; j < n; j += i){
                p[j] = 0;
            }
        }
    }
}
vi range(int n){
    vi v(n);
    for (int i = 1;i < n; i++){
        v[i] = i;
    }
    rtn v;
}
seti srange(int n){
    seti s;
    forr (i,n){
        s.insert(i);
    }
    rtn s;
}
int fact[100];
void pre(){
    fact[0] = 1;
    for (int i = 1; i < 100; i++){
        fact[i] = mul(fact[i-1],i);
    }
}
int find_max(ll n, ll m){
    int i = 0;
    ll c = 1;
    while (m <= n / c && m * c < n){
        i++;
        c *= m;
    }
    rtn i;
}
void bf(int n, int m){
    n++;
    seti r;
    vi v(10);
    for (ll i = 1; i < n; i++){
        if (r.find(i) != r.end()) cnt;
        int c = -1;
        for (ll k = i; k < n; k *= m){
            r.insert(k);
            c++;
        }
        v[c]++;
    }
    trace(r.sz)
    out(v);
}
void solve(){
    nll(n,m)
    // n++;
    // int s = find_max(n+1,m);
    ll x = 1;
    int c = 1;
    vl v(100,1);
    while(n/x >= m){
        x*=m;
        v[c]=x;
        c++;
    }
    int a = 1;
    ll t = n, u = 0;
    // out(v);
    for (int i = c; i > 0; i--){
        ll x = n / v[i-1];
        x -= x / m;
        x -= u;
        u += x;
        t -= (i / 2) * x;
        if (i & 1) cnt;
        imul(a,power(i/2+1,x));
    }
    cout << t << " ";
    ans(a);
}
int32_t main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);cout.tie(NULL);cerr.tie(NULL);
    // cout << fixed;
    // cout.precision(10);
    // cerr << fixed;
    // cerr.precision(6);
    #ifndef ONLINE_JUDGE
        freopen("../../input.txt","r",stdin);
        freopen("../../output.txt","w",stdout);
        freopen("../../error.txt","w",stderr);
    #endif
    clock_t tStart = clock();
    pre();
    W()
        solve();
    double t =  (double)(clock() - tStart)/CLOCKS_PER_SEC;
    cerr << endl << "Time: " << t;
    rtn 0;
}
/*
*/