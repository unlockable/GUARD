#include <iostream>
#include <bits/stdc++.h>
 using namespace std;
 /*
    NOTES:
        __builtin_popcount(int) gives number of 1s in binary representation of number
*/
 #define ull unsigned long long
#define ll long long
#define nl "\n"
#define INTBITS 32
#define kickstartoutput cout << "Case #" << tc <<": " 
const int mod = 1000000007;
 int smalla = 97;
int biga = 65;
void solve(int tc)
{
    int n,m;
    cin >> n >> m;
    vector<int> cr(n), sr(m);  
    vector<int> co(n+1, 0);
    for(int& x:cr)
        cin >> x;
    for(int& x:sr)
        cin >> x;
    int chefrank = sr[0];
    int id = -1;
    unordered_map<int, vector<int> > ranktopref;
    for(int i = 0; i <m; i++)
    {
        int k;
        cin >> k;
        vector<int> pref(k);
        for(int& x:pref)
            cin >> x;
        sort(pref.begin(), pref.end());
        ranktopref[sr[i]] = pref;
    }
    map<int, vector<int>> sortedrtp(ranktopref.begin(), ranktopref.end());
    for(auto x : sortedrtp)
    {
        if(chefrank == x.first)
        {
            // cout << chefrank << ":" ;
            // for(int y:x.second)
            //     cout << y << " ";
            // cout << nl;
            for(int y: x.second)
            {
                if(!co[y])
                {
                    cout << y << nl;
                    return;
                }
            }
            cout << 0 << nl;
            return;
        }
        for(int y:x.second)
        {
            if(!co[y])
            {
                co[y] = 1;
                break;
            }
        }
    }
    cout << 0 << nl;
}
  int main(){
     ios_base::sync_with_stdio(false);
    cin.tie(NULL);
     int t = 1;
    cin>>t; 
     int c = 1;
    while(t--)
    {
        solve(c);
    c++;
}
}