#include <bits/stdc++.h>
using namespace std;
#define int long long int
#define ll long long int
#define pb push_back
#define endl '\n'
#define fr(a, b) for (int i = (a); i < (b); i++)
#define rep(i, a, b) for (int i = (a); i < (b); i++)
#define per(i, a, b) for (int i = (a); i >= (b); i--)
void solve()
{
    int n1, n2, n3;
    cin >> n1 >> n2 >> n3;
    map<int, int> m;
    rep(i, 0, n1 + n2 + n3)
    {
        int x;
        cin >> x;
        m[x]++;
    }
    int ct = 0;
    for (auto ele : m)
    {
        if (ele.second >= 2)
        {
            ct++;
        }
    }
    cout << ct << endl;
    for (auto ele : m)
    {
        if (ele.second >= 2)
        {
            cout << ele.first << endl;
        }
    }
}
signed main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    int t = 1;
    // cin >> t;
    while (t--)
    {
        solve();
    }
    return 0;
}