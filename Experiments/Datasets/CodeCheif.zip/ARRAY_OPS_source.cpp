/*#include <iostream>
using namespace std;
int main() {
    // your code goes here
    return 0;
}*/
#include<bits/stdc++.h>
using namespace std;
const int N=5e5+1e3+7;
int T,n;
long long a[N];
int main()
{
    scanf("%d",&T);
    while(T--)
    {
        scanf("%d",&n);
        map<long long,int>cnt;
        for(int i=1;i<=n;i++)
            scanf("%lld",&a[i]),cnt[a[i]]++;
        for(int i=1;i<n;i++)
        {
            map<long long,int>nc;
            long long la=-1;
            for(auto [x,y]:cnt)
            {
                if(y-1)
                    nc[0]+=y-1;
                if(la!=-1)
                    nc[x-la]++;
                la=x;
            }
            cnt.swap(nc);
        }
        printf("%lld\n",cnt.begin()->first);
    }
}