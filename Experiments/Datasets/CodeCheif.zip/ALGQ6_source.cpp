#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef vector<ll> vl;
ll M;
inline ll mul(ll a, ll b) {
    return (a*b)%M;
}
ll bp(ll b, ll p) {
    ll ac = 1;
    while(p) {
        if(p&1) {ac = mul(ac,b);}
        b = mul(b,b);
        p >>= 1;
    }
    return ac;
}
inline ll inv(ll b) {
    return bp(b,M-2);
}
struct S {
    ll x,p;
    S() {}
    explicit S(ll x, ll p): x(x), p(p) {
    }
    S operator*(const S& ot) const {
        S ans;
        ans.x = mul(x,ot.x);
        ans.p = p+ot.p;
        return ans;
    }
    S iinv() const {
        S ans;
        ans.x = inv(x);
        ans.p = -p;
        return ans;
    }
    S operator/(const S& ot) const {
        return (*this)*ot.iinv();
    }
};
vl facs;
void pre() {
    facs.push_back(1);
    for(int i=1;i<M;i++) {
        facs.push_back(mul(facs.back(),i));
    }
}
S fac(ll n) {
    if(n < M) {
        return S(facs[n],0);
    }
    ll kt = n/M;
    S ans(mul(bp(facs[M-1],kt),facs[n%M]),n/M);
    S ad = fac(n/M);
    return ans * ad;
}
S get(ll x) {
    assert(x != 0);
    int kt = 0;
    while(!(x%M)) {
        kt++;
        x /= M;
    }
    return S(x,kt);
}
int main() {
    ll N;
    cin >> N >> M;
    pre();
    while(N--) {
        ll n;
        cin >> n;
        n >>= 1;
        S ans(fac(4*n+1));
        ans = ans*get(8)*get(n)*get(n+2);
        ans = ans/fac(2*n+4)/fac(2*n);
        if(ans.p > 0) {
            cout << 0 << '\n';
        } else {
            cout << ans.x << '\n';
        }
    }
}