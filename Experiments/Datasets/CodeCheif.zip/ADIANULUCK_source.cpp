#include <bits/stdc++.h>
using namespace std;
#define TURBO ios_base::sync_with_stdio(0); cin.tie(0); cout.tie(0);
typedef long long ll;
#define all(x) x.begin(), x.end()
#define vi vector<int>
void solve(){
    int n;
    cin >> n;
    vi a(n);
    for(int i = 0; i < n; i++) cin >> a[i];
    priority_queue<int64_t> pq(all(a));
    vector<int64_t> cur(2);
    int me = 0;
    while (!pq.empty()) {
        auto p = pq.top();
        pq.pop();
        cur[me] += p;
        p /= 2;
        if(p) pq.push(p);
        me ^= 1;
    }
    cout << abs(cur[0] - cur[1]) << '\n';
}
int main() {
    // your code goes here
    TURBO;
    ll testcase = 1;
    cin >> testcase;
    for(int tc = 1; tc <= testcase; tc++) {
        // cout << "Case #" << tc << ": ";
        solve();
    }
    return 0;
}