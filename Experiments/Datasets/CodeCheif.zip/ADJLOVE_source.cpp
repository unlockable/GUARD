#include <bits/stdc++.h>
using namespace std;
int main() {
    int test;
    cin>>test;
    while(test--){
        int n;
        cin>>n;
        int c=0,d=0;
        int a[n];
        vector<int>v1;
        vector<int>v2;
        for(int i=0;i<n;i++){
            cin>>a[i];
            if(a[i]%2==1){
                c++;
                v1.push_back(a[i]);
            }
            else{
                v2.push_back(a[i]);
                d++;
            }
        }
        if(c%2==0){
            if(c>0){
            for(int i=0;i<v1.size();i++){
                cout<<v1[i]<<" ";
            }
            for(int i=0;i<v2.size();i++){
                cout<<v2[i]<<" ";
            }
            cout<<endl;
            }
            else{
                cout<<-1<<endl;
            }
        }
        else{
            if(d>0 && c>1){
                 for(int i=0;i<v1.size()-1;i++){
                cout<<v1[i]<<" ";
            }
            for(int i=0;i<v2.size();i++){
                cout<<v2[i]<<" ";
            }
            cout<<v1[c-1]<<endl;
            }
            else{
                cout<<-1<<endl;
            }
        }
    }
    // your code goes here
    return 0;
}