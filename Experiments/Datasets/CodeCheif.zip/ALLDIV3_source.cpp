#include <iostream>
#include <bits/stdc++.h>
using namespace std;
int main() {
int t;
cin>>t;
while(t--){
    int n;
    int ct=0;
    cin>>n;
    int a[n];
   unordered_map <int,int>m;
    for(int i=0; i<n; i++){
        cin>>a[i];
    }
    for(int i=0; i<n; i++){
        a[i]=a[i]%3;
        m[a[i]]++;
    }
    int x=min(m[1],m[2]);
    ct+=x;
    int y=max(m[1],m[2]);
    int b=y-x;
    if(b%3!=0)cout<<-1<<endl;
    else {
        ct+=2*b/3;
        cout<<ct<<endl;
}}
    return 0;
}