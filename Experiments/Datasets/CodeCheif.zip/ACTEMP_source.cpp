#include <iostream>
using namespace std;
int main() {
    // your code goes here
    int T, A, B, C;
    cin >> T;
    while(T--){
        cin >> A >> B >> C;
        if(A <= B && C <= B){
            cout << "YES" << endl;
        } else{
            cout << "NO" << endl;
        }
    }
    return 0;
}