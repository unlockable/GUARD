#include <bits/stdc++.h>
#define ll long long int;
using namespace std;
int M=1000000007;
vector<vector<long long>> dp;
long long solve(vector<int> & a, int x, int prev, int i)
{
    if(i>=a.size()) return 0;
    if(i==0) return max(solve(a, x, a[i], i+1), solve(a,x,a[i]+x,i+1));
    int ind2=0;
    if(prev!=a[i-1]) ind2=1;
    if(dp[i][ind2]!=-1) return dp[i][ind2];
    return dp[i][ind2]=max((prev^a[i])+solve(a, x, a[i], i+1), (prev^(a[i]+x))+solve(a, x, a[i]+x, i+1));
}
int main() {
    // your code goes here
    int t;
    cin>>t;
    while(t--)
    {
        int n, x;
        cin>>n>>x;
        vector<int> a(n);
        dp.clear();
        dp.assign(n, vector<long long> (2, -1));
        for(int i=0 ; i<n ; i++)
        {
            cin>>a[i];
        }
        cout<<solve(a, x, 0, 0)<<endl;
    }
    return 0;
}