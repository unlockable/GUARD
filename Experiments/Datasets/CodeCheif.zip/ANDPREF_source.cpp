#include<bits/stdc++.h>
using namespace std;
#define int long long
#define pii pair<int,int>
#define f first
#define s second
const int N = 2e6 + 5, mod = 1e9 + 7; //!
int t, dp[N], cn[N];
main() {
    ios_base::sync_with_stdio(false),cin.tie(0),cout.tie(0);
    cin >> t;
    while(t--) {
        int n;
        cin >> n;
        int x = 0;
        while((1 << x) < n) ++x;
        for(int i = 0; i < (1 << x); i++) cn[i] = 0; 
        for(int i = 1; i <= n; i++) {
            int a;
            cin >> a;
            cn[a] += 1;
        }
        for(int j = 0; j < x; j++) {
            for(int i = 0; i < (1 << x); i++) {
                if((1 << j) & i) continue;
                cn[i] += cn[i ^ (1 << j)];
            }
        }
        for(int i = (1 << x) - 1; i >= 0; i--) {
            dp[i] = cn[i] * i; 
            for(int j = 0; j < x; j++) {
                if(!((1 << j) & i)) {
                    dp[i] = max(dp[i], dp[i + (1 << j)] + i * (cn[i] - cn[i ^ (1 << j)]));
                }
            }
        }
        cout << dp[0] << " " ;
            }
}