#include <bits/stdc++.h>
#include<cmath>
using namespace std;
#define ll long long int
#define end "\n"
int main (){
    ll n,d,k=0;
    cin>>n>>d;
    for (int i=(pow(10,n));i<=pow(10,n);--i){
        if (k<d+1){
            if (i%3==0){k++;
            if (k==d) {cout<<i<<end;return 0;}
            }
        }
    }
}