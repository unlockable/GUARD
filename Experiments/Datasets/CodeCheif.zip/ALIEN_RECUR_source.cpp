#include<bits/stdc++.h>
using namespace std;
#define int        long long int 
#define ld         long double
#define mod        1000000007
#define mod1       998244353
#define accelerate ios_base::sync_with_stdio(false);cin.tie(NULL);cout.tie(NULL)
#define endl       "\n"
#define po         pop_back
#define pb         push_back
#define bs         binary_search
#define all(x)     (x).begin(),(x).end()  
#define tc         int test;cin>>test; while(test--)
#define ra(arr,n)  vector<int> arr(n);for(int in=0;in<n;in++){cin>>arr[in];}
const int inf = 1e18;
void solve()
{ 
   tc
   {
    int n,k;
    cin>>n>>k;
    vector<int>v(k,0);
    v[0]=1;
    n--;
    int check=n%9;
    int flag=n/9;
    for(int i=k-1;i>=k-flag;i--)
    {
     v[i]=9;
    }v[k-1-flag]=v[k-1-flag]+check;
    for(int x:v)cout<<x;
     cout<<endl;
}
    }
            signed main()
{  
     accelerate;
#ifndef ONLINE_JUDGE
     freopen("input.txt","r",stdin);
     freopen("output.txt","w",stdout);
#endif
               solve();
     return 0;
}