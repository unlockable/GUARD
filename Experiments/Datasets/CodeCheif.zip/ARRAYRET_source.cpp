#include<bits/stdc++.h>
using namespace std;
#define int long long int 
signed main()
{
    int t;
    cin>>t;
    while(t--)
    {
        int n;
        cin>>n;
        int b[n];
        int sum=0;
        for(int i=0;i<n;i++)
        {
            cin>>b[i];
            sum+=b[i];
        }
        sum=sum/(n+1);
        for(int i=0;i<n;i++)
        {
            cout<<b[i]-sum<<" ";
        }
        cout<<endl;
    }
    return 0;
}