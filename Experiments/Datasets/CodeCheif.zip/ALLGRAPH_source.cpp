#include<bits/stdc++.h>
using namespace std;
#define pb push_back
#define eb emplace_back
#define mp make_pair
#define Fast_IO ios::sync_with_stdio(false);
#define DEBUG fprintf(stderr,"Running on Line %d in Function %s\n",__LINE__,__FUNCTION__)
#define fir first
#define sec second
#define mod 998244353
#define ll long long
#define inf 0x3f3f3f3f
#define INF 0x3f3f3f3f3f3f3f3f
inline int read()
{
    char ch=getchar(); int nega=1; while(!isdigit(ch)) {if(ch=='-') nega=-1; ch=getchar();}
    int ans=0; while(isdigit(ch)) {ans=ans*10+ch-48;ch=getchar();}
    if(nega==-1) return -ans;
    return ans;
}
typedef pair<int,int> pii;
void print(vector<int> x){for(int i=0;i<(int)x.size();i++) printf("%d%c",x[i]," \n"[i==(int)x.size()-1]);}
#define N 1000005
#define M 4005
int n,m,a[N];
vector<pii> G[N];
int vis[N],hav[N],dis[N],tw[N];
ll ans;
struct Node
{
    int id,val,op;
    bool operator < (const Node &x) const {return val>x.val;}
    Node(int a,int b,int c) {id=a,val=b,op=c;}
};
set<int> s;
priority_queue<Node> q;
void work()
{
    n=read();
    for(int i=1;i<=n;i++) a[i]=read();
    m=read();
    vector<int> occ;
    for(int i=1;i<=m;i++)
    {
        int u=read(),v=read(),w=read();
        G[u].eb(v,w),vis[u]=1;
        hav[u]=hav[v]=1;
        occ.pb(u),occ.pb(v);
    }
    for(int i=1;i<=n;i++) sort(G[i].begin(),G[i].end());
    sort(occ.begin(),occ.end());
    occ.erase(unique(occ.begin(),occ.end()),occ.end());
    ans=0;
    int nmn=inf;
    for(int i=1;i<=n;i++) if(!hav[i]) nmn=min(nmn,a[i]);
    // cout<<nmn<<endl;
    // print(occ);
    const set<int> all(occ.begin(),occ.end());
    int qwq=0;
    for(int i=1;i<=n;i++)
    {
        if(!vis[i]) ans+=1LL*(n-1)*a[i];
        else
        {
            for(int j:occ) dis[j]=inf;
            dis[i]=0; q.emplace(i,0,0);
            vector<int> s=occ;
            while(!q.empty())
            {
                auto [u,d,op]=q.top(); q.pop();
                if(op==0)
                {
                    qwq++;
                    if(dis[u]!=d) continue;
                    q.emplace(u,dis[u]+a[u],1);
                    for(auto [v,w]:G[u])
                    {
                        if(dis[v]>dis[u]+w) dis[v]=dis[u]+w,q.emplace(v,dis[v],0);
                    }
                }
                else if(!s.empty())
                {
                    vector<int> bad,go;
                    int cur=0;
                    for(int j=0;j<(int)s.size();j++)
                    {
                        while(cur<(int)G[u].size()&&G[u][cur].fir<s[j]) cur++;
                        if(cur<(int)G[u].size()&&G[u][cur].fir==s[j]) bad.pb(s[j]);
                        else go.pb(s[j]);
                    }
                    for(int k:go) if(dis[k]>d) dis[k]=d,q.emplace(k,dis[k],0);
                    s=bad;
                }
            }
            int mn=inf; for(int j:occ) mn=min(mn,dis[j]+a[j]);
            int out=inf; for(int j:occ) out=min(out,dis[j]+a[j]+nmn);
            ans+=1LL*(n-(int)occ.size())*mn;
            for(int j:occ) ans+=min(dis[j],out);
            // printf("%d\n",ans);
        }
    }
    printf("%lld\n",ans);
    for(int i=1;i<=n;i++) G[i].clear(),vis[i]=0,hav[i]=0;
}
// --------------main()--------------
signed main()
{
    int T=read(); while(T--) work();
    return 0;
}