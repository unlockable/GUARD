#include <iostream>
using namespace std;
int gcd(int x, int y){
    if(!y)
    return x;
    return gcd(y,x%y);
}
int main() {
    int t;
    cin >> t;
    while(t--){
        int n,k;
                cin >> n >> k;
                for(auto i : {2,3,5,7,9,11,13,17,19}){
            if(gcd(k,i) == 1){
                for(int j = 1; j <= n; j++){
                    cout << j*i << " ";
                }
                cout << "\n";
                break;
            }
        }
            }
}