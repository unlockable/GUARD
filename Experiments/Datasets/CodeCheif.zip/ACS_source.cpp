#include <iostream>
using namespace std;
int main() {
    // your code goes here
    int t;
    cin>>t;
    for(int i=0;i<t;i++)
    {
        int p;
        cin>>p;
        int r=p%100+p/100;
       if(r<=10)
       {
           cout<<r<<endl;
       }
        else
        {
            cout<<"-1"<<endl;
        }
    }
    return 0;
}