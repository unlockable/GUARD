#include <bits/stdc++.h>
using namespace std;
int main() {
    int n;
    cin>>n;
    int arr[n];
    vector<vector<int>> ans;
    for(int i=0; i<n; i++) cin>>arr[i];
    for(int mask=19; mask>=0; mask--) {
        int compare = 1<<mask, mini=INT_MAX, ind = -1;
        map<int, int> map;
        for(int i=0; i<n; i++) {
            if(arr[i]>=compare) {
                if(arr[i]<mini) {
                    mini = min(mini, arr[i]);
                    ind = i;
                }
                map[i] = arr[i];
            }
        }
        vector<int> push;
        for(auto &index : map) {
            push.push_back(index.first+1);
            arr[index.first] -= mini;
        }
        push.push_back(ind+1);
        if(push.size()>1) ans.push_back(push);
    }
    cout<<ans.size()<<endl;
    for(int i=0; i<ans.size(); i++) {
        cout<<ans[i].size()-1<<endl;
        for(int j=0; j<ans[i].size()-1; j++) {
            cout<<ans[i][j]<<" ";
        }
        cout<<endl;
        cout<<"- "<<ans[i][ans[i].size()-1]<<endl;
    }
    return 0;
}