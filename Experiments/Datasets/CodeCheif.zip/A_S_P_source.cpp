#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef pair <int, int> pii;
#define ALL(a) a.begin(), a.end()
#define FastIO ios::sync_with_stdio(false); cin.tie(0);cout.tie(0)
#define IN freopen("input.txt","r+",stdin)
#define OUT freopen("output.txt","w+",stdout)
#define DBG(a) cerr<< "line "<<__LINE__ <<" : "<< #a <<" --> "<<(a)<<endl
#define NL cerr<<endl
template < class T1,class T2>
ostream &operator <<(ostream &os,const pair < T1,T2 > &p)
{
    os<<"{"<<p.first<<","<<p.second<<"}";
    return os;
}
template <class T , size_t N>
ostream &operator <<(ostream &os,const array <T,N> &a)
{
    os<<"{";
    for(auto x: a)
        os<<x<<" ";
    os<<"}";
    return os;
}
template <class T>
ostream &operator <<(ostream &os,const vector<T> &a)
{
    os<<"{ ";
    for(auto x: a)
        os<<x<<" ";
    os<<"}";
    return os;
}
const int N=3e5+5;
const int oo=1e9+7;
const int K=22;
int up[K][N];
vector<int> g[N];
int dep[N];
int nd[N];
int in[N];
int out[N];
int curr=1;
void dfs(int u,int p)
{
    up[0][u]=p;
    dep[u]=dep[p]+1;
    for(int i=1;i<K;i++)
        up[i][u]=up[i-1][up[i-1][u]];
    nd[curr]=u;
    in[u]=curr;
    curr++;
    for(int v: g[u]) if(v!=p)
    {
        dfs(v,u);
    }
    out[u]=curr-1;
}
int a[N];
int b[N];
int lca(int u,int v)
{
    if(dep[u]>dep[v]) swap(u,v);
    for(int i=K-1;i>=0;i--)
    {
        if(dep[u] <= (dep[v] - (1<<i)))
        {
            v=up[i][v];
        }
    }
    if(u==v) return u;
    for(int i=K-1;i>=0;i--)
        if(up[i][u]!=up[i][v])
        {
            u=up[i][u];
            v=up[i][v];
        }
    assert(up[0][u]==up[0][v]);
    return up[0][u];
}
int kth(int u,int k)
{
    for(int i=K-1;i>=0;i--)
        if((k>>i)&1)
            u=up[i][u];
    return u;
}
struct node
{
    map<int,int> cnt;
    int lazy;
};
node s[N<<2];
void prop(int u,int ss,int se)
{
    if(s[u].lazy != -1)
    {
        s[u].cnt.clear();
        s[u].cnt[s[u].lazy]=se-ss+1;
        if(ss!=se)
        {
            s[u<<1].lazy = s[u].lazy;
            s[u<<1|1].lazy = s[u].lazy;
        }
        s[u].lazy=-1;
    }
}
void upd(int u,int ss,int se,int qs,int qe,int c)
{
    prop(u,ss,se);
    if(qe < ss or se < qs) return ;
    if(qs<=ss and se<=qe)
    {
        s[u].lazy = c;
        return prop(u,ss,se);
    }
    int mid = ss+se>>1;
    upd(u<<1,ss,mid,qs,qe,c);
    upd(u<<1|1,mid+1,se,qs,qe,c);
    s[u].cnt = s[u<<1].cnt;
    for(auto [i,j]: s[u<<1|1].cnt)
        s[u].cnt[i]+=j;
}
int gt(int u,int ss,int se,int qs,int qe,int c)
{
    prop(u,ss,se);
    if(qe < ss or se < qs) return 0;
    if(qs<=ss and se<=qe)
    {
        auto x = s[u].cnt.find(c);
        return x == s[u].cnt.end() ? 0: x->second;
    }
    int mid = ss+se>>1;
    return gt(u<<1,ss,mid,qs,qe,c)+
    gt(u<<1|1,mid+1,se,qs,qe,c);
}
void build(int u,int ss,int se)
{
    s[u].lazy=-1;
    if(ss==se)
    {
        s[u].cnt.clear();
        s[u].cnt[a[ss]]++;
    }
    else 
    {
        int mid = ss+se>>1;
        build(u<<1,ss,mid);
        build(u<<1|1,mid+1,se);
        s[u].cnt = s[u<<1].cnt;
        for(auto [i,j]: s[u<<1|1].cnt)
            s[u].cnt[i]+=j;
    }
}
int32_t main()
{
    FastIO;
    int T,cs=0;
    cin>>T;
    while(T--)
    {
        curr=1;
        int n;
        cin>>n;
        for(int i=1;i<=n;i++) g[i].clear();
        for(int i=1;i<=n;i++) cin>>b[i];
        for(int i=1;i<=n-1;i++)
        {
            int u,v;
            cin>>u>>v;
            g[u].push_back(v);
            g[v].push_back(u);
        }
        dfs(1,0);
        assert(curr==n+1);
        for(int i=1;i<=n;i++) a[i]=b[nd[i]];
        build(1,1,n);
        int root=1;
        int q;
        cin>>q;
        // DBG(q);
        while(q--)
        {
            int t,u,c;
            cin>>t>>u;
            if(t==1)
            {
                cin>>c;
                int lc=lca(root,u);
                if(lc == u)
                {
                    if(u==root)
                    {
                        upd(1,1,n,1,n,c);
                    }
                    else 
                    {
                        assert(dep[u]<dep[root]);
                        int x = kth(root,dep[root]-dep[u]-1);
                        if(in[x]>1) upd(1,1,n,1,in[x]-1,c);
                        if(out[x]<n)    upd(1,1,n,out[x]+1,n,c);
                    }
                }
                else 
                {
                    upd(1,1,n,in[u],out[u],c);
                }
            }
            else if(t==2)
            {
                root=u;
            }
            else 
            {
                cin>>c;
                int lc=lca(root,u);
                int ans=0;
                if(lc == u)
                {
                    if(u==root)
                    {
                        ans+=gt(1,1,n,1,n,c);
                    }
                    else 
                    {
                        assert(dep[u]<dep[root]);
                        int x = kth(root,dep[root]-dep[u]-1);
                        ans+=gt(1,1,n,1,n,c);
                        ans-=gt(1,1,n,in[x],out[x],c);
                    }
                }
                else 
                {
                    ans+=gt(1,1,n,in[u],out[u],c);
                }
                cout<<ans<<'\n';
            }
        }   
    }
}
//