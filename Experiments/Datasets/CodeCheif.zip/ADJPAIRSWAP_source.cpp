/*
#include <iostream>
using namespace std;
int main() {
    // your code goes here
    return 0;
}
*/
#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define pb push_back
#define F first
#define S second
#define vi vector<int>
#define vl vector<ll>
#define vs vector<string>
#define vvi vector<vector<int>>
#define vvl vector<vector<ll>>
#define pii pair<int, int>
#define pll pair<ll, ll>
#define umii unordered_map<int, int>
#define umll unordered_map<ll, ll>
#define mii map<int, int>
#define mll map<ll, ll>
#define usi unordered_set<int>
#define usl unordered_set<ll>
#define si set<int>
#define sl set<ll>
#define umsi unordered_multiset<int>
#define umsl unordered_multiset<ll>
#define msi multiset<int>
#define msl multiset<ll>
#define popCount(x) __builtin_popcount(x)
// #define MOD               1000000007
void solve(vi &a, int n, vector<pii> &ops)
{
    int keep = 0;
    for(int i=2; i<=n; ++i){
        if(a[i] == 0 && a[i-1] == 1){
            while(a[keep] == 0){
                keep++;
            }
            if(i == n){
                ops.pb({i-3,i-1});
                swap(a[i-3],a[i-1]);
                swap(a[i-2],a[i]);
                ops.pb({keep,i-2});
                swap(a[keep],a[i-2]);
                swap(a[keep+1],a[i-1]);
            }
            else if(keep + 1 < i){
                ops.pb({keep,i});
                swap(a[keep],a[i]);
                swap(a[keep+1],a[i+1]);
            }
            else{
                ops.pb({i,i+2});
                swap(a[i],a[i+2]);
                swap(a[i+1],a[i+3]);
                ops.pb({keep, keep+3});
                swap(a[keep],a[keep+3]);
                swap(a[keep+1],a[keep+4]);
            }
        }
    }
}
int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
#ifndef ONLINE_JUDGE
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);
#endif
    int t;
    cin >> t;
    while (t--)
    {
        int n;
        cin >> n;
        vi a(n + 1);
        vector<pii> ops;
        int zeros = 0, ones = 0;
        for (int i = 1; i <= n; ++i)
        {
            cin >> a[i];
            if(a[i]){ones++;}
            else{zeros++;}
        }
        if (max(zeros, ones) == n)
        {
            cout << 0 << '\n'; continue;
        }
        if (zeros <= ones)
        {
            solve(a,n,ops);
        }
        else
        {
            vi b(n+1);
            for(int i=1; i<=n; ++i){
                b[i] = a[n-i+1]^1;
            }
            solve(b,n,ops);
            for(auto &x : ops){
                x = {n-x.S,n-x.F};
            }
        }
        cout << ops.size() << '\n';
        for (auto &x : ops)
        {
            cout << x.F << " " << x.S << '\n';
        }
    }
    return 0;
}