#include <iostream>
using namespace std;
int main() {
    // your code goes here
    int t,x,y;
    cin>>t;
    while(t--){
        cin>>x>>y;
        int p,q,r,s;
        p=500-(x*2);
        q=1000-(y+x)*4;
        r=1000-y*4;
        s=500-(x+y)*2;
        if(p+q>=r+s)
        cout<<p+q<<endl;
        else cout<<r+s<<endl;
    }
    return 0;
}