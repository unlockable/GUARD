#include<bits/stdc++.h>
using namespace std;
typedef int ll;
typedef long double ld;
ll main(){
  ios_base::sync_with_stdio(0); cin.tie(0); cout.tie(0);
  ll t,t1; cin>>t;
  while(t--) {
  ll i,j,k=0,n,sm=0,m; cin>>n>>m;
  ll a[n+1][m+1],b[n+1][m+1];
  map<ll,ll>  ev,od,ev1,od1;
  for(i=1;i<=n;i++){
    for(j=1;j<=m;j++) {cin>>a[i][j];
    if((i+j)%2) od[a[i][j]]++; else ev[a[i][j]]++;
  }} for(i=1;i<=n;i++){
    for(j=1;j<=m;j++) {cin>>b[i][j];
    if((i+j)%2) od1[b[i][j]]++; else ev1[b[i][j]]++;
  }} if(n==1||m==1){
  for(i=1;i<=n&&!k;i++) for(j=1;j<=m;j++) if(a[i][j]!=b[i][j]) {k=1; break;}}
  for(i=1;i<=n;i++){ if(k) break;
    for(j=1;j<=m;j++)
    if(ev[a[i][j]]!=ev1[a[i][j]]||od[a[i][j]]!=od1[a[i][j]]) {k=1; break;}}
    if(k) cout<<"NO"<<'\n'; else cout<<"YES"<<'\n';
}
}