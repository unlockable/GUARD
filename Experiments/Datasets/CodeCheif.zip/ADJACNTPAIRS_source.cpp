#include <iostream>
using namespace std;
#define AMSZ 200000
class Node{
    public:
    int posi;
    Node* next;
    Node(int posi){
        next=NULL;
        this->posi=posi;
    }
};
int A[AMSZ],cnt[2][AMSZ+1],dnum[2][AMSZ>>1],pap[AMSZ+1],pape[AMSZ>>1];
int papes,N;
Node *pos[AMSZ+1];
void dhpfy(int cni,int* arr,int arrs,int* cnt){
    while(true){
        int lci=(cni<<1)+1,rci=lci+1,mi=cni;
        if(lci<arrs&&cnt[arr[lci]]<cnt[arr[mi]])
            mi=lci;
        if(rci<arrs&&cnt[arr[rci]]<cnt[arr[mi]])
            mi=rci;
        if(mi==cni)
            break;
        int tmp=arr[cni];
        arr[cni]=arr[mi];
        arr[mi]=tmp;
        cni=mi;
    }
}
void sort(int* arr,int arrs,int* cnt){
    for(int nln=(arrs>>1)-1;nln>=0;nln--)
        dhpfy(nln,arr,arrs,cnt);
    while(arrs>1){
        int tmp=arr[arrs-1];
        arr[arrs-1]=arr[0];
        arr[0]=tmp;
        arrs--;
        dhpfy(0,arr,arrs,cnt);
    }
}
void fillpap(int opnum){
    Node* curn=pos[opnum];
    bool bllt=false,blrt=false;
    papes=0;
    while(curn!=NULL){
        if(curn->posi-2>=0&&A[curn->posi-2]!=A[curn->posi])
            bllt=blrt=false;
        else if(!blrt&&curn->posi-2>=0&&A[curn->posi-2]==A[curn->posi])
            bllt=true;
        if(!bllt&&curn->posi+1<N&&A[curn->posi-1]==A[curn->posi+1])
            blrt=true;
        else
            blrt=false;
        if(!bllt){
            if(pap[A[curn->posi-1]]==0)
                pape[papes++]=A[curn->posi-1];
            pap[A[curn->posi-1]]++;
        }
        if(!blrt&&curn->posi+1<N){
            if(pap[A[curn->posi+1]]==0)
                pape[papes++]=A[curn->posi+1];
            pap[A[curn->posi+1]]++;
        }
        curn=curn->next;
    }
}
void clearpap(){
    while(papes>0)
        pap[pape[--papes]]=0;
}
int main() {
    int tc;
    cin>>tc;
    for(int test=0;test<tc;test++){
        int dnums[2]={0,0};
        cin>>N;
        for(int i=0;i<N;i++){
            cin>>A[i];
            if(cnt[i&1][A[i]]==0)
                dnum[i&1][dnums[i&1]++]=A[i];
            cnt[i&1][A[i]]++;
        }
        for(int i=(N&1)?N-2:N-1;i>=1;i-=2){
            Node* newn=new Node(i);
            newn->next=pos[A[i]];
            pos[A[i]]=newn;
        }
        /*for(int i=1;i<=N;i++){
            Node* cnp=pos[i];
            if(cnp!=NULL)
                cout<<i<<" ";
            while(cnp!=NULL){
                cout<<cnp->posi<<" ";
                cnp=cnp->next;
            }
            if(pos[i]!=NULL)
                cout<<endl;
        }
        for(int i=1;i<=N;i++){
            if(cnt[0][i]!=0)
                cout<<"oposcnt "<<i<<" "<<cnt[0][i]<<endl;
            if(cnt[1][i]!=0)
                cout<<"eposcnt "<<i<<" "<<cnt[1][i]<<endl;
        }*/
        /*cout<<"Before sorting"<<endl;
        for(int i=0;i<dnums[0];i++)
            cout<<dnum[0][i]<<" ";
        cout<<endl;
        for(int i=0;i<dnums[1];i++)
            cout<<dnum[1][i]<<" ";
        cout<<endl;*/
        sort(dnum[0],dnums[0],cnt[0]);
        sort(dnum[1],dnums[1],cnt[1]);
        /*cout<<"After sorting"<<endl;
        for(int i=0;i<dnums[0];i++)
            cout<<dnum[0][i]<<" ";
        cout<<endl;
        for(int i=0;i<dnums[1];i++)
            cout<<dnum[1][i]<<" ";
        cout<<endl<<endl;*/
        int fini=dnums[1],omtv=0;
        for(int i=0;i<dnums[0];i++){
            fillpap(dnum[0][i]);
            /*cout<<"pap for "<<dnum[0][i]<<endl;
            for(int j=1;j<=N;j++){
                if(pap[j]!=0)
                    cout<<j<<" "<<pap[j]<<endl;
            }*/
            int mtv=0;
            for(int j=0;j<fini;j++){
                if(dnum[1][j]==dnum[0][i])
                    continue;
                int tv=cnt[1][dnum[1][j]]-pap[dnum[1][j]];
                mtv=(mtv>tv)?mtv:tv;
                if(pap[dnum[1][j]]==0){
                    fini=j;
                    break;
                }
            }
            mtv+=cnt[0][dnum[0][i]];
            omtv=(omtv>mtv)?omtv:mtv;
            clearpap();
            /*for(int j=1;j<=N;j++){
                if(pap[j]!=0)
                    cout<<"Clearpap failed"<<endl;
            }*/
        }
        for(int i=0;i<dnums[1];i++)
            omtv=(omtv>cnt[1][dnum[1][i]])?omtv:cnt[1][dnum[1][i]];
        cout<<(N-omtv)<<endl;
        //clean up for next tc starts here
        for(int i=1;i<=N;i++)
            cnt[0][i]=cnt[1][i]=0;
        for(int i=1;i<N;i+=2){
            Node* nxtn=pos[A[i]]->next;
            delete pos[A[i]];
            pos[A[i]]=nxtn;
        }
        /*for(int i=1;i<=N;i++){
            if(pos[i]!=NULL)
                cout<<"Cleanup failed"<<endl;
        }
        cout<<endl;*/
    }
    return 0;
}
//cpp