#include<bits/stdc++.h>
#define num 1000000007
#define mod 998244353
#define print(x) for(auto i:x) cout<<i<<" ";cout<<endl;
#define printa(x,st,en) for(ll i=st;i<en;i++) cout<<x[i]<<" ";cout<<endl;
#define mp make_pair
#define printm(x) for(auto i:x) cout<<i->first<<"*"<<i->second<<" ";cout<<endl;
#define pq priority_queue
#define minpq(type) pq<type,vector<type>,greater<type> >
#define printp(p) for(auto i:p) cout<<i.first<<"*"<<i.second<<" ";cout<<endl;
#define mem(a) memset(a,0,sizeof(a))
#define allof(a) a.begin(),a.end()
#define loop(i,start,end) for(ll i=start;i<end;i++)
#define deloop(i,start,end) for(ll i=start;i>end;i--)
#define testing cout<<"Test"<<endl;
#define prints(a) cout<<a<<endl;
#define vl vector<ll>
#define vb vector<bool>
#define vvl vector< vector<ll> >
#define pb push_back
#define ff first
#define ss second
#define pll pair<ll,ll>
#define vpll vector< pair<ll,ll> >
#define enter(a,begin,end) for(ll i=begin;i<end;i++) cin>>a[i];
typedef long long int ll;
const int dx[]={+0,+0,+1,-1,-1,+1,-1,+1};
const int dy[]={-1,+1,+0,+0,+1,+1,-1,-1}; 
using namespace std;
ll mul(ll x,ll y){
    return ((x%mod)*(y%mod))%mod;
}
ll powers(ll x,ll p){
    x=x%mod;
    if(p==0) return 1;
    if(p==1) return x%mod;
    ll z=powers(x,p/2);
    if(p%2) return mul(x,mul(z,z));
    return mul(z,z);
}
ll dividing(ll x,ll y){
    return mul(x,powers(y,mod-2));
}
ll max(ll a,ll b){
    return a>b?a:b;
}
ll min(ll a,ll b){
    return a<b?a:b;
}
bool isValid(ll r,ll c,ll n,ll m){
    return r>=0 and r<n and c>=0 and c<m;
}
bool can(pll src,pll dest,ll v,vvl &dist,ll n,ll m){
    vector<vector<bool>> visited(n,vector<bool>(m,false));
    queue<pll> queue;
    queue.push(src);
    while(!queue.empty()){
        auto node = queue.front();
        queue.pop();
        if(visited[node.ff][node.ss])
            continue;
        visited[node.ff][node.ss] = true;
        if(node.ff==dest.ff and node.ss==dest.ss)
            return true;
        loop(i,0,8){
            int nr = node.ff + dx[i];
            int nc = node.ss + dy[i];
            if(!isValid(nr,nc,n,m) or visited[nr][nc] or dist[nr][nc]<v){
                continue;
            }
            queue.push({nr,nc});
        }
    }
    return false;
}
bool cans(ll hi,vvl &a,ll n, ll m, ll i, ll j,ll di,ll dj){
    vvl v(n,vl(m,0));
    queue<pll>q;
    if(a[i][j]>=hi) q.push(mp(i,j));
    while(q.size()){
        i=q.front().first;
        j=q.front().second;
        q.pop();
        v[i][j]=1;
        if(i==di && j==dj) return true;
        loop(x,-1,2){
            loop(y,-1,2){
                if(i+x>=0 && j+y>=0 && i+x<n && j+y<m && v[i+x][j+y]==0 && (a[i+x][j+y]>=hi)){
                    q.push(mp(x+i,y+j));
                }
            }
        }
    }
    return false;
}
void solve(){
    ll n, m;
    cin>>n>>m;
    vvl a(n,vl(m,-1));
    pll src,dst;
    string s;
    queue<pll>q;
    loop(i,0,n){
        cin>>s;
        loop(j,0,m){
            if(s[j]=='$') dst=mp(i,j);
            else if(s[j]=='@') src=mp(i,j);
            else if(s[j]=='D'){
                q.push({i,j});
                a[i][j]=0;
            }
        }
    }
    ll i,j;
    while(q.size()){
        i=q.front().first;
        j=q.front().second;
        q.pop();
        loop(x,-1,2){
            loop(y,-1,2){
                if((i+x!=0 || j+y!=0) && i+x>=0 && j+y>=0 && i+x<n && j+y<m && a[i+x][j+y]==-1){
                    a[i+x][j+y]=a[i][j]+1;
                    q.push(mp(x+i,y+j));
                }
            }
        }
    }
    ll low=0, high=n+m+5;
    while(low<high){
        ll mid=(low+high+1)/2;
        if(can(src,dst,mid,a,n,m)) low=mid;
        else high=mid-1;
    }
    cout<<high<<endl;
}
int main(){
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    // freopen("input.txt","r",stdin);
    ll t=1;
    while(t--) solve();
    return 0;
}