#include <bits/stdc++.h>
using namespace std;
mt19937 rng(chrono::steady_clock::now().time_since_epoch().count());
void solve() {
    int n;
    cin >> n;
    vector<int> p(n), pos(n);
    for (int i = 0; i < n; i++) {
        cin >> p[i], p[i]--;
        pos[p[i]] = i;
    }
    vector<pair<int, int>> ans;
    for (int i = 0; i < n; i++) {
        int j = p[i];
        while (j != i) {
            j = p[i] - 1;
            ans.push_back({i, pos[j]});
            swap(p[i], p[pos[j]]);
            pos[p[i] + 1] = pos[j];
            pos[j] = i;
        }
    }
    cout << ans.size() << '\n';
    for (auto [i, j] : ans)
        cout << i + 1 << ' ' << j + 1 << '\n';
}
int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(0);
    int t = 1;
    // gen_primes();
    // gen_factorials((int)1e6 + 5);
    // cout << fixed << setprecision(6);
    cin >> t;
    for (int te = 0; t--;){
        // cout << "Case #" << ++te << ": ";
        solve();
    }
}