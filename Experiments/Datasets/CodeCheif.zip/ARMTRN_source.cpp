#include <bits/stdc++.h>
using namespace std;
int main() {
    long int test;
    cin>>test;
    while(test--){
        long int n;
        cin>>n;
        long int a[n];
        long int s1=0;
        for(long int i=0;i<n;i++){
            cin>>a[i];
            s1=s1+a[i];
        }
        sort(a,a+n);
        long int ans=0;
        long int s2=0;
        for(int i=0;i<n;i++){
            long int tem=s1*s2;
            ans=max(ans,tem);
            s1=s1-a[i];
            s2=s2+(1000-a[i]);
        }
        cout<<ans<<endl;
    }
    // your code goes here
    return 0;
}