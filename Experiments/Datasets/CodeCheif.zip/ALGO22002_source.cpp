#include <iostream>
using namespace std;
float area(int x1, int y1, int x2, int y2, int x3, int y3)
{
   return abs((x1*(y2-y3) + x2*(y3-y1)+ x3*(y1-y2))/2.0);
}
int isIns(int x1, int y1, int x2, int y2, int x3, int y3, int x, int y)
{  
    float A = area (x1, y1, x2, y2, x3, y3);
    float A1 = area (x, y, x2, y2, x3, y3);
    float A2 = area (x1, y1, x, y, x3, y3);
    float A3 = area (x1, y1, x2, y2, x, y);
    // cout<<A1<<" "<<A2<<" "<<A3<<endl;
    if(A1==0 || A2==0 ||A3==0)
        return 2;
    else if(A == A1 + A2 + A3)
        return 1;
    else
        return 0;
}
int main() {
    // your code goes here
    int x[4],y[4];
    for(int i=0;i<4;i++)
        cin>>x[i]>>y[i];
    if((isIns(x[0],y[0],x[1],y[1],x[2],y[2],x[3],y[3])==2||isIns(x[0],y[0],x[1],y[1],x[3],y[3],x[2],y[2])==2||isIns(x[0],y[0],x[3],y[3],x[2],y[2],x[1],y[1])==2||isIns(x[3],y[3],x[1],y[1],x[2],y[2],x[0],y[0])==2))
        cout<<"0"<<endl;
    else if((isIns(x[0],y[0],x[1],y[1],x[2],y[2],x[3],y[3])||isIns(x[0],y[0],x[1],y[1],x[3],y[3],x[2],y[2])||isIns(x[0],y[0],x[3],y[3],x[2],y[2],x[1],y[1])||isIns(x[3],y[3],x[1],y[1],x[2],y[2],x[0],y[0]))==1)
        cout<<"3"<<endl;
    else
        cout<<"1"<<endl;
    return 0;
}