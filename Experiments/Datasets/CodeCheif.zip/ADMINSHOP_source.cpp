#include <iostream>
#include <algorithm>
#include <vector>
#define ll long long int
using namespace std;
void solve()
{
    ll n,x;
    cin >> n>>x;
    vector<ll> v;
    for (int i = 0; i < n; i++)
    {
        int a;
        cin >> a;
        v.push_back(a);
    }
    sort(v.begin(), v.end());
    // ll d = (x + (v[0] - 1)) / v[0];
    ll d = (x / v[0]) + (x % v[0] ? 1 : 0);
    if (d < n)
        cout << n << endl;
    else
        cout << d << endl;
}
int main()
{
    ll t;
    cin >> t;
    while (t--)
        solve();
    return 0;
}