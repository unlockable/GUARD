#include <bits/stdc++.h>
#define ll  long long
#define ull unsigned long long  
using namespace std;
#define  inf 1e15+2
#define fastio ios_base::sync_with_stdio(false); cin.tie(NULL)
#define mod 1000000007
#define mod1 998244353
const int maxn=504;
#define vpll  vector<pair<ll,ll>>
#define  pq priority_queue
#define  ff first
#define  ss second 
#define pb  push_back
#define pob pop_back
#define lb lower_bound
#define ld long double
#define ub upper_bound
#define LB 60
#define setp(x) cout<<fixed<<setprecision(x)
#define PQ_MIN  priority_queue <ll, vector<ll>, greater<ll> >
#define setbit(x)   __builtin_popcount(x)
#define all(x) (x).begin(),(x).end()
#define pie 3.14159265358
#define enter(a)   for(ll i=0;i<a.size();i++) cin>>a[i];
#define show(a)     for(ll e: a) cout<<e<<" "; cout<<"\n";
#define pii pair<ll,ll>
using vi = vector<int>;
ll power(ll n,ll p){
 ll r=1;
 while(p){
  if(p%2){
   r=(r*n)%mod;
   p--;
 }
 p=p/2;
 n=(n*n)%mod;
}
return r;
}
ll quer(int a,int b,int c){
  cout<<"? "<<a<<" "<<b<<" "<<c<<"\n";
  fflush(stdout);
  int k;
  cin >> k;
  return k;
}
const int N=1e5+5;
int dx[4]={1,-1,0,0};
int dy[4]={0,0,1,-1};
ll temp;
int bit[N];
void update(int i,int x){
    for(;i<N;i+=i&(-i))
        bit[i]+=x;
}
int get(int i){
    int ans=0;
    for(;i;i-=i&(-i))
        ans+=bit[i];
    return ans;
}
int main(){
 fastio;
 int thaan=1;
   cin >>thaan;
   while(thaan--){
            memset(bit,0,sizeof(bit));
            ll i,j,k,l,n,m,r;
            cin >> n >> m ;
            ll a[n+1];
            unordered_map<ll,ll>mp;
            for(i=1;i<=n;i++){
                cin >> a[i];
                mp[a[i]]=i;
            }
            ll pre[n+1]={};
            ll suf[n+2];
            for(i=1;i<=n+1;i++)
                suf[i]=n+1;
            stack<int>s;
            for(i=n;i>=1;i--){
                 while(!s.empty() && a[s.top()]<=a[i]){
                     pre[s.top()]= i ;
                     s.pop();
                 }
                 s.push(i);
            }
            while(!s.empty())
                s.pop();
            for(i=1;i<=n;i++){
                  while(!s.empty() && a[s.top()]<=a[i]){
                     suf[s.top()]= i ;
                     s.pop();
                 }
                 s.push(i);
            }
            vector<array<ll,2>>v;
            for(i=1;i<=n;i++){
                  l=pre[i]+1;
                  r=suf[i]-1;
                  if(i-l<=r-i){
                    for(j=l;j<=i;j++){
                        if((a[i]%a[j]) == 0 && mp.count(a[i]/a[j]) == 1){
                            k=mp[a[i]/a[j]];
                            if(k>=i && k<=r)
                            v.push_back({j,k});
                        }
                    }
                  }
                  else{
                    for(j=i;j<=r;j++){
                           if((a[i]%a[j]) == 0 && mp.count(a[i]/a[j]) == 1){
                            k=mp[a[i]/a[j]];
                            if(k>=l && k<=i)
                            v.push_back({k,j});
                        }
                    }
                  }
            };
            vector<array<ll,3>>q;
            sort(all(v));
            for(i=1;i<=m;i++){
                cin >> j >> k ;
                q.push_back({j,k,i});
            }
            sort(all(q));
            ll ans1[m+1];
            while(!q.empty()){
                 l=q.back()[0];
                 r=q.back()[1];
                 while(!v.empty() && v.back()[0]>=l){
                    update(v.back()[1],1);
                    v.pop_back();
                 }
                 ans1[q.back()[2]]=get(r);
                 q.pop_back();
            }
            for(i=1;i<=m;i++)
                cout<<ans1[i]<<"\n";
 }
}