#include <iostream>
using namespace std;
int main() {
    // your code goes her
        int t;
    cin>>t;
        while(t--) {
        int n, k, x=0;
        cin>>n>>k;
        int arr[k];
        for(int i=0; i<k; i++)
        cin>>arr[i];
        int minus=0;
        for(int i=0; i<k; i++) 
        {
            x+=(arr[i]-minus-1);
            x/=2;
            minus=arr[i];
        }
        x+=(n-arr[k-1]);
        int count=0;
        while(x) {
            if(x%2) count++;
            x/=2;
        }
        cout<<n-k-count<<endl;
    }
    return 0;
}
    