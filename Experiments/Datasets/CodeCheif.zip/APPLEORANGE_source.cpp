#include <bits/stdc++.h>
using namespace std;
int main() {
    int tt;
    cin>>tt;
    while(tt--)
    {
        int n,m, ans;
        cin>>n>>m;
        ans = n+m;
        cout<<__gcd(ans-min(n,m), min(m,n) )<<endl;
    }
    return 0;
}