#include <iostream>
using namespace std;
void diff(string s,string t,long long int n,long long k)
{
    long long int k1=0,k2=0;
    for(long long int i=0;i<=n;i++)
    {
        if(s[i]!=t[i])
        {
            k1++;
            while(i+1<n&&s[i+1]!=t[i+1])
            {
                i++;
            }
        }
        else{
            k2++;
            while(i+1<n && s[i+1]==t[i+1])
            {
                i++;
            }
        }
    }
    if(k1<=k)
    {
        if((k-k1)%2==0)
        {
            cout<<"YES"<<endl;
        }
        else{
            if(n==1)
            {
                cout<<"NO"<<endl;   
            }
            else if(k2&&k==1&&k1==0)
            {
                cout<<"NO"<<endl;
            }
            else{
                cout<<"YES"<<endl;
            }
        }
    }
    else{
        cout<<"NO"<<endl;
    }
}
int main() {
    long long int t;
    cin>>t;
    for(long long int x=0;x<t;x++)
    {
        long long int n,k;
        cin>>n>>k;
        string s ,t;
        cin>>s;
        cin>>t;
        diff(s,t,n,k);
    }
    return 0;
}