/**
 *    author:  tourist
 *    created: 31.07.2021 16:33:04       
**/
#include <bits/stdc++.h>
using namespace std;
int main() {
  ios::sync_with_stdio(false);
  cin.tie(0);
  int tt;
  cin >> tt;
  while (tt--) {
    int n, k;
    cin >> n >> k;
    vector<int> x, t, c;
    for (int i = 0; i < n; i++) {
      int xx, tt, cc;
      cin >> xx >> tt >> cc;
      if (xx <= tt) {
        x.push_back(xx);
        t.push_back(tt);
        c.push_back(cc);
      }
    }
    n = (int) x.size();
    vector<int> order(n);
    iota(order.begin(), order.end(), 0);
    sort(order.begin(), order.end(), [&](int i, int j) {
      return (x[i] < x[j] || (x[i] == x[j] && t[i] < t[j]));
    });
    vector<int> a(n);
    for (int i = 0; i < n; i++) {
      a[i] = t[i] - x[i];
    }
    vector<map<int, long long>> s(k);
    function<void(int, int, int)> Insert = [&](int row, int val, int cnt) {
      if (row >= k) {
        return;
      }
      auto it = s[row].lower_bound(val + 1);
      int init = cnt;
      while (it != s[row].end() && cnt > 0) {
        if (it->second <= cnt) {
          cnt -= it->second;
          Insert(row + 1, it->first, it->second);
          it = s[row].erase(it);
        } else {
          Insert(row + 1, it->first, cnt);
          it->second -= cnt;
          cnt = 0;
          break;
        }
      }
      s[row][val] += init;
    };
    for (int i = 0; i < n; i++) {
      Insert(0, a[order[i]], c[order[i]]);
    }
    vector<long long> res(k);
    for (int i = 0; i < k; i++) {
      for (auto& p : s[i]) {
        res[i] += p.second;
      }
      if (i < k - 1) {
        res[i + 1] += res[i];
      }
    }
    for (auto v : res) {
      cout << v << '\n';
    }
  }
  return 0;
}