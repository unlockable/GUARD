#include <bits/stdc++.h>
using namespace std;
int main() {
    // your code goes here
    int t;
    cin>>t;
    while(t--)
    {
        int n;
        cin>>n;
        int c[2*n];
        for(int i=0;i<2*n;i++)
        {
            cin>>c[i];
        }
        sort(c,c+(2*n),greater<int>());
        int m=c[0]-c[(2*n)-1];
        for(int i=0;i<=n;i++)
        {
            m=min(m,c[i]-c[i+n-1]);
            if(m==0)
            {
                m=0;
                break;
            }
        }
        cout<<m<<endl;
    }
    return 0;
}