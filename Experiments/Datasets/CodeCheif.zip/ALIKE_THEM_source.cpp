#include <bits/stdc++.h>
using namespace std;
#define int long long 
long long power(long long a, long long b, long long m) {
    a %= m;
    long long res = 1;
    while (b > 0) {
        if (b & 1)
            res = res * a % m;
        a = a * a % m;
        b >>= 1;
    }
    return res;
}
int32_t main(void)
{
    int mod = 1e9 + 7;
    int t = 0;
    cin >> t;
    while (t--)
    {
        int n = 0;
        int m = 0;
        cin >> n >> m;
        int useless = 0;
        std::vector<int> v1;
        std::vector<int> v2;
        int p[n];
        for (int i = 0; i < n; i++)
        {
            cin >> p[i];
            if (p[i] < i + 1)
            {
                useless++;
                v2.push_back(p[i]);
            }
            else
            {
                v1.push_back(p[i]);
            }
        }
        int a[n];
        for (int i = 0; i < n; i++)
        {
            cin >> a[i];
        }
        int len = v2.size();
        for (int i = 0; i < len; i++)
        {
            if (a[v2[i] - 1] != 0)
            {
                useless--;
            }
        }
        int flag = 1;
        len = v1.size();
        set<int> s;
        for (int i = 0; i < len; i++)
        {
            if (a[v1[i] - 1] != 0)
            {
                s.insert(a[v1[i] - 1]);
                flag = 0;
            }
        }
        int answer = 0;
        if (s.size() <= 1)
        {
            answer = power(m, useless + flag, mod);
        }
        cout << answer << "\n";
    }
}