#include <bits/stdc++.h>
using namespace std;
#define read(n) ll n;cin>>(n);
#define mod ll(pow(10,9)+7)
typedef long long ll;
#define fast() ios_base::sync_with_stdio(false);cin.tie(NULL); cout.tie(NULL)
ll dp[101][51][1001];
inline ll max(ll a, ll b){
    if(a>b) return a;
    else return b;
}
ll findcnt(ll s,ll a,ll v){
    if(v<0) return 0;
    if(dp[s][a][v] != -1) return dp[s][a][v];
    if(s<=1){
        return dp[s][a][v] = (a<=v);
    }
    ll cnt{};
    ll c1 = s/2;
    ll c2 = (s%2)? s/2+1:s/2;
    ll lower = (0<a-c2)? (a-c2):0;
    ll higher = (a>c1)? c1:a;
    for (int i = lower; i <= higher; ++i) {
        cnt += findcnt(c1,i,v-a) * findcnt(c2,a-i,v-a);
        cnt %= mod;
    }
    dp[s][a][v] = cnt;
    return cnt;
}
void solve(){
    ios_base::sync_with_stdio(false);cin.tie(nullptr); cout.tie(nullptr);
    read(a)
    read(e)
    read(v)
    ll cnt = (findcnt(a+e,a,v)-findcnt(a+e,a,v-1)+mod)%mod;
    cout<<cnt<<'\n';
    return;
}
int main() {
    ios_base::sync_with_stdio(false);cin.tie(nullptr); cout.tie(nullptr);
    memset(dp,-1,sizeof(dp));
    read(t);
    while(t--){
        solve();
    }
}