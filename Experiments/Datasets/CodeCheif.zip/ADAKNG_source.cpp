#include <stdio.h>
int max(int a, int b) {
    return (a>b) ? a : b;
}
int min(int a, int b) {
    return (a<b) ? a : b;
}
int main()
{
    int t;
    scanf("%d", &t);
    while (t--) {
        int r, c, k, dx, dy;
        scanf("%d%d%d", &r, &c, &k);
        dx = min(c+k, 8) - max(c-k, 1) + 1;
        dy = min(r+k, 8) - max(r-k, 1) + 1;
        printf("%d\n", dx*dy);
    }
}