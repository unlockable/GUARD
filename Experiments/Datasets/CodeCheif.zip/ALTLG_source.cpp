#include<bits/stdc++.h>
using namespace std;
typedef long long int ll;
ll power(ll x,ll y,ll m){if(y==0)return 1;ll p=power(x,y/2,m)%m;p=(p*p)%m;return (y%2==0)?p:(x*p)%m;}
vector<ll> Fac(1,1),Mod_Inv(1,1);int Last_Index = 0;
ll nCr(ll n,ll r,ll m){if(n<0 || r<0) return 0;if(r>n) return 0;if(n>Last_Index){for(ll i=Last_Index+1;i<=n;++i){Fac.push_back(Fac[i-1]*i);Fac[i]%=m;Mod_Inv.push_back(power(Fac[i],m-2,m));}Last_Index=n;}return (((Fac[n]             
#define Test int t;cin>>t;while(t--)
#define endl '\n'
int Google_Test;
#define int ll
int lcm(int a,int b)
{
    return a*b/gcd(a,b);
}
vector<int> Set1,height1,Set2,height2;
void Union1(int u,int v)
{
    while(Set1[u]!=u)
    u=Set1[u];
    while(Set1[v]!=v)
    v=Set1[v];
    if(height1[u]>=height1[v])
    {
        height1[u] = max(height1[u],height1[v]+1);
        Set1[v] = u;
    }
    else
    {
        height1[v] = max(height1[v],height1[u]+1);
        Set1[u]=v;
    }
}
void Union2(int u,int v)
{
    while(Set2[u]!=u)
    u=Set2[u];
    while(Set2[v]!=v)
    v=Set2[v];
    if(height2[u]>=height2[v])
    {
        height2[u] = max(height2[u],height2[v]+1);
        Set2[v] = u;
    }
    else
    {
        height2[v] = max(height2[v],height2[u]+1);
        Set2[u]=v;
    }
}
bool isInOneSet1(int u,int v)
{
    while(Set1[u]!=u)
    u=Set1[u];
    while(Set1[v]!=v)
    v=Set1[v];
    if(u!=v)
    return false;
    return true;
}
bool isInOneSet2(int u,int v)
{
    while(Set2[u]!=u)
    u=Set2[u];
    while(Set2[v]!=v)
    v=Set2[v];
    if(u!=v)
    return false;
    return true;
}
void solve()
{
    // cout << "Case #" << ++Google_Test << ": ";
    int n,q;
    cin >> n >> q;
    vector<int> v(n);
    Set1 = height1 = Set2 = height2 = vector<int>(n);
    for(int i=0;i<n;++i)
    Set1[i] = Set2[i] = i;
    for(int i=0;i<n;++i)
    cin >> v[i];
    vector<array<int,4>> ans(q);
    vector<int> fans(q);
    for(int i=0;i<q;++i)
    {
        cin >> ans[i][2] >> ans[i][0] >> ans[i][1];
        ans[i][0]--;
        ans[i][1]--;
        ans[i][3] = i;
    }
    int last = q-1;
    sort(ans.begin(),ans.end());
    vector<array<int,2>> temp1,temp2;
    for(int i=n-1;i>=0;--i)
    {
        if(i%2==0)
        {
            for(array<int,2> &j:temp1)
            j[0] = gcd(v[i],j[0]);
            for(array<int,2> &j:temp2)
            j[0] = lcm(v[i],j[0]);
        }
        else
        {
            for(array<int,2> &j:temp1)
            j[0] = lcm(v[i],j[0]);
            for(array<int,2> &j:temp2)
            j[0] = gcd(v[i],j[0]);
        }
        temp1.push_back({v[i],i});
        temp2.push_back({v[i],i});
        sort(temp1.begin(),temp1.end());
        sort(temp2.begin(),temp2.end());
        int tsz1 = temp1.size();
        int tsz2 = temp2.size();
        vector<int> vis1(tsz1),vis2(tsz2);
        for(int j=0;j<tsz1-1;++j)
        {
            if(temp1[j][0]==temp1[j+1][0])
            {
                vis1[j]=1;
                Union1(temp1[j][1],temp1[j+1][1]);
            }
        }
        for(int j=0;j<tsz2-1;++j)
        {
            if(temp2[j][0]==temp2[j+1][0])
            {
                vis2[j]=1;
                Union2(temp2[j+1][1],temp2[j][1]);
            }
        }
        vector<array<int,2>> newtemp1,newtemp2;
        for(int j=0;j<tsz1;++j)
        {
            if(!vis1[j])
            newtemp1.push_back({temp1[j][0],temp1[j][1]});
        }
        for(int j=0;j<tsz2;++j)
        {
            if(!vis2[j])
            newtemp2.push_back({temp2[j][0],temp2[j][1]});
        }
        temp1 = newtemp1;
        temp2 = newtemp2;
        if(i%2==0)
        {
            while(last>=0 && ans[last][0]==i)
            {
                if(ans[last][2]==1)
                {
                    for(array<int,2> j:temp1)
                    {
                        if(isInOneSet1(j[1],ans[last][1]))
                        fans[ans[last][3]]=j[0];
                    }
                }
                else
                {
                    for(array<int,2> j:temp2)
                    {
                        if(isInOneSet2(j[1],ans[last][1]))
                        fans[ans[last][3]]=j[0];
                    }
                }
                last--;
            }
        }
        else
        {
            while(last>=0 && ans[last][0]==i)
            {
                if(ans[last][2]==1)
                {
                    for(array<int,2> j:temp2)
                    {
                        if(isInOneSet2(j[1],ans[last][1]))
                        fans[ans[last][3]]=j[0];
                    }
                }
                else
                {
                    for(array<int,2> j:temp1)
                    {
                        if(isInOneSet1(j[1],ans[last][1]))
                        fans[ans[last][3]]=j[0];
                    }
                }
                last--;
            }
        }
    }
    for(int i:fans)
    cout << i << endl;
}
int32_t main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    Test
    solve();
    return 0;
}