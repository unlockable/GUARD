#include <bits/stdc++.h>
using namespace std;
mt19937 rng(chrono::steady_clock::now().time_since_epoch().count());
const int ALPHA = 26;
void solve() {
    int n;
    string s;
    cin >> n >> s;
    vector<vector<int>> adj(n);
    for (int i = 0; i < n - 1; i++) {
        int u, v;
        cin >> u >> v;
        u--, v--;
        adj[u].push_back(v);
        adj[v].push_back(u);
    }
    vector<vector<pair<int, int>>> p(n, vector<pair<int, int>> (18));
    vector<int> d(n);
    function<void(int, int, int)> dfs = [&](int u, int par, int depth) {
        d[u] = depth;
        p[u][0].first = par;
        p[u][0].second = 1 << (s[u] - 'a');
        for (int v : adj[u]) 
            if (v != par) dfs(v, u, depth + 1);
    };
    dfs(0, 0, 0);
    for (int pw = 1; pw < 18; pw++)
        for (int i = 0; i < n; i++) {
            auto [par, c] = p[i][pw - 1];
            p[i][pw] = p[par][pw - 1];
            p[i][pw].second |= c;
        }
    int q;
    cin >> q;
    for (int i = 0; i < q; i++) {
        int u, v;
        cin >> u >> v;
        u--, v--;
        if (d[v] > d[u]) swap(u, v);
        int diff = d[u] - d[v];
        vector<int> cnt(2);
        for (int pw = 0; pw < 18; pw++)
            if (diff >> pw & 1) {
                cnt[0] |= p[u][pw].second;
                u = p[u][pw].first;
            }
        for (int pw = 17; pw >= 0; pw--) {
            int u_par = p[u][pw].first;
            int v_par = p[v][pw].first;
            if (u_par != v_par) {
                cnt[0] |= p[u][pw].second;
                cnt[1] |= p[v][pw].second;
                u = u_par, v = v_par;
            }
        }
        if (u != v)
            cnt[0] |= p[u][0].second, cnt[1] |= p[v][0].second;
        cout << (cnt[0] & cnt[1] ? "YES\n" : "NO\n");
    }
}
int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(0);
    int t = 1;
    // gen_primes();
    // gen_factorials((int)1e6 + 5);
    // cout << fixed << setprecision(6);
    cin >> t;
    for (int te = 0; t--;){
        // cout << "Case #" << ++te << ": ";
        solve();
    }
}