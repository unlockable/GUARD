#include <bits/stdc++.h>
using namespace std;
#define ll long long
void solve()
{
    ll n;
    cin >> n;
        ll a[n],b[n];
        for(int i=0;i < n;i++)
    {
        cin >> a[i];
    }
        ll mini = n-1;
        for(int i=0;i < n;i++)
    {
        cin >> b[i];
        mini = min(mini,(a[0]+b[i])%n);
    }
        set<vector<ll>> s1;
        int co = 0;
    for(int i=0;i < n;i++)
    {
        if((a[0] + b[i])%n == mini)
        {
            co++;
            vector<ll> v1;
                        for(int j=0;j < n;j++)
            {
                v1.push_back((a[j] + b[(i+j)%n])%n);
            }
            s1.insert(v1);
        }
    }
    vector<ll> ans = *s1.begin();
        for(auto it : ans){
        cout << it << " ";
    }
    cout << endl;
}
int main() {
    // your code goes here
    int t;
    cin >> t;
    while(t--)
    {
        solve();
    }
    return 0;
}