#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int MAXN = 2e5 +  21;
ll mod = 1e9 + 7;
ll fact[MAXN], inv[MAXN];
ll bigmod(ll base, ll poww) {
   ll ret = 1;
   while(poww > 0) {
      if(poww&1) ret*=base, ret%=mod;
      base*=base; base%=mod;
      poww/=2;
   }
   return ret;
}
int main() {
    ll t;  cin >>  t;
     fact[0] = inv[0] = 1;
    for(ll i = 1; i <= MAXN - 1; i++) fact[i] = (fact[i - 1] * i)%mod;
    inv[MAXN - 1] = bigmod(fact[MAXN - 1], mod - 2);
    for(ll i = MAXN - 2; i >= 1; i--) inv[i] = (inv[i + 1] * (i + 1))%mod;
    while(t--) {
   ll n; cin >> n;
   ll total = 0;
   for(ll i = 2; i <= n; i++) {
        ll asc_order = fact[n] * inv[i]; asc_order%=mod;
        asc_order*=inv[n - i]; asc_order%=mod;
        ll check_indx = n - i + 1;
        ll first_type = asc_order*fact[n - i]; first_type%=mod;
        first_type*=check_indx; first_type%=mod;
        first_type*=(i - 1); first_type%=mod;
        //cout << first_type <<"    kfutt  "<< endl;
        ll ii = i - 1;
        asc_order = fact[n] * inv[ii]; asc_order%=mod;
        asc_order*=inv[n - ii]; asc_order%=mod;
        ll sec_type = asc_order * fact[n - ii]; sec_type%=mod;
        first_type+=sec_type; first_type%=mod;
        first_type*=(i - 1); first_type%=mod;
      //  cout << first_type << endl;
        total+=first_type;
        total%=mod;
   }
   total+=n; total%=mod;
   total*=bigmod(n, mod - 2); total%=mod;
   total*=bigmod(fact[n], mod - 2); total%=mod;
   cout << total << endl;
    }
 }