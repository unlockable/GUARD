#include <iostream>
using namespace std;
int main() {
    int t; cin>>t;
    while(t--)
    {
        string s; cin>>s;
        int l=s.length();
        int e=0; int a=0;
        int p=0; int y=0;
        for(int i=0;i<l;i++)
        {
            if (s[i] == 'e')
            {
                e=1;
            }
            else if (s[i] == 'a')
            {
                a=1;
            }
            else if (s[i] == 's')
            {
                p=1;
            }
            else if (s[i] == 'y')
            {
                y=1;
            }
        }
        if(e==1 && a==1 && p==1 && y==1)
        {
            cout<<"YES"<<endl;
        }
        else
        {
            cout << "NO" << endl;
        }
    }
    return 0;
}