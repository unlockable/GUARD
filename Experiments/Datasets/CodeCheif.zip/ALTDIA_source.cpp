#include <bits/stdc++.h>
#define int long long
using namespace std;
int mod = 1000000007;
signed main() 
{
    int t;
    cin >> t;
    while (t--) {
        int white, black;
        cin >> black >> white;
        if (white==0 || black==0) {
            if (black==1) {cout << "B\n";}
            else if (white==1) {cout << "W\n";}
            else cout << "-1\n";
            continue;
        }
        if (white<black) {
            for (int i=0; i<white; i++) {
                cout << "W";
            } for (int i=0; i<black; i++) {
                cout << "B";
            } cout << "\n";
        } else {
            for (int i=0; i<black; i++) {
                cout << "B";
            } for (int i=0; i<white; i++) {
                cout << "W";
            } cout << "\n";
        }
        int first = 1, last = 2;
        for (int i=1; i<white+black; i++) {
            cout << first << " " << last++ << "\n";
        }
    }
    return 0;
}