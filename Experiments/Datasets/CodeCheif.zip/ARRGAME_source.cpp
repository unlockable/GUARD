#include <bits/stdc++.h>
using namespace std;
int main() {
        int t;
        cin>>t;
        while(t--){
        int n;
        cin>>n;
        int a[n];
        // taking the input
        for(int i=0;i<n;i++){
            cin>>a[i];
        }
        int count=0; //to count the frequency of consecutive zeros
        int maxc1=0,maxc2=0; //to store maximum frequency and just less than or equal to maximum frequency.
        for(int i=0;i<n;i++){
            if(a[i]){
                if(count>maxc2){
                    maxc2=count;
                    if(count>maxc1){
                        maxc2=maxc1;
                        maxc1=count;
                    }
                }
                count=0;
            }
            else{
                count++;
            }
        }
        if(a[n-1]==0){
            if(count > maxc2) {
                    maxc2 = count;
                    if(count > maxc1) {
                        maxc2 = maxc1;
                        maxc1 = count;
                    }
                }
        }
// checking if the required condition is being satisfied for B.
        if((maxc1&1) and (maxc2 < (maxc1+1)/2)){
            cout<<"Yes";
        }
        else{
            cout<<"No";
        }
                cout<<endl;
    }
        return 0;
}