#include <bits/stdc++.h>
using namespace std;
#define int long long int
void solve()
{
  int n, m;
  cin >> n >> m;
  pair<int, int> p[m];
  for (int i = 0; i < m; i++)
    cin >> p[i].first >> p[i].second;
  sort(p, p + m, greater<pair<int, int>>());
  int cur = 1, ans = 0;
  for (int i = 0; i < m; i++)
  {
    int prev = cur;
    if (cur <= n)
      cur = (cur * p[i].second) / __gcd(cur, p[i].second);
    ans += (n / prev - n / cur) * p[i].first;
  }
  cout << ans;
}
int32_t main()
{
  ios_base::sync_with_stdio(false);
  cin.tie(NULL);
#ifndef ONLINE_JUDGE
  freopen("input.txt", "r", stdin);
#endif
  int tc;
  cin >> tc;
  for (int i = 1; i <= tc; i++)
    solve(), cout << "\n";
}