#include <iostream>
using namespace std;
int main() {
    int c;
    cin>>c;
    for(int i=0;i<c;i++){
        int a,b;
        cin>>a>>b;
        if(b==0){
            cout<<a<<endl;
        }
        else if((a-b)!=0){
            cout<<(b+(a-b)+(b))<<endl;
        }
        else{
          cout<<(b+(a-b)+(b-1))<<endl;   
        }
    }
    return 0;
}