#include<bits/stdc++.h>
using namespace std;
#define ll long long 
#define pb push_back
#define loop(n) for(long long i=0;i<n;i++)
#define rloop(n) for(long long i=n-1;i>=0;i--)
////////////////////////////////////////////
 ll m=1e9+7;
long long binpow(long long a, long long b) {
    if (b == 0)
        return 1;
    long long res = binpow(a, b / 2);
    if (b % 2)
        return (res%m * res%m * a)%m;
    else
        return res%m * res%m;
}
//////////////////////////////////////////////////
//////////////////////////////////////////////
signed main(){
      ios::sync_with_stdio(false);
      cin.tie(nullptr);
      #ifndef ONLINE_JUDGE
        freopen("input.txt","r",stdin);
        freopen("output1.txt","w",stdout);
       #endif
int test_cases;
cin>>test_cases;
while(test_cases--){
ll n;
cin>>n;
ll a[n];
set<ll>s;
loop(n){
  cin>>a[i];
  }
ll x=0;
loop(n-1){
  if(a[i+1]>a[i]){
    x=-1;break;
  }
}
if(x==-1)cout<<"YES\n";
else cout<<"NO\n";
}
    return 0;
}