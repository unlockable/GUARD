#include <cstdio>
#include <cstring>
#include <vector>
#include <bits/stdc++.h>
using namespace std;
 #define MAX_N 20000
 int main(){
    int T,N,p1[MAX_N],p2[MAX_N],type[MAX_N];
    vector<int> L[MAX_N];
    int Q[MAX_N],head,tail;
        scanf("%d",&T);
        while(T--){
        scanf("%d",&N);
        for(int i = 0;i<N;++i) L[i].clear();
                for(int i = 0;i<N;++i) scanf("%d",&p1[i]);
        for(int i = 0;i<N;++i) scanf("%d",&p2[i]);
                for(int i = 0;i+1<N;i += 2){
            L[p1[i]].push_back(p1[i+1]);
            L[p1[i+1]].push_back(p1[i]);
                        L[p2[i]].push_back(p2[i+1]);
            L[p2[i+1]].push_back(p2[i]);
        }
                head = tail = 0;
        memset(type,-1,sizeof(type));
                for(int i = 0;i<N;++i){
            if(type[i]!=-1) continue;
                        Q[tail] = i; ++tail;
            type[i] = 0;
                        while(head<tail){
                int u = Q[head]; ++head;
                                for(int i = L[u].size()-1;i>=0;--i){
                    int v = L[u][i];
                    if(type[v]!=-1) continue;
                                        type[v] = 1-type[u];
                    Q[tail] = v; ++tail;
                }
            }
        }
                for(int i = 0;i<N;++i){
            if(type[i]==0) putchar('A');
            else putchar('B');
        }
        putchar('\n');
    }
   return 0;
}