#include<bits/stdc++.h>
using namespace std;
int main(){
    long long t;
    cin>>t;
    cin.ignore();
    while(t--){
        string s;
        getline(cin,s);
        string str;
        getline(cin,str);
        vector<string>v1;
        string s3;
        for(int i=0;i<str.length();i++){
            if(str[i]==' '){
                v1.push_back(s3);
                s3.clear();
            }
        else{
            s3=s3+str[i];
        }
        }
        if(s3.length()!=0){
            v1.push_back(s3);
        }
       map<string,char>mp;
       map<char,string>mp1;
       long long c=0;
       for(int i=0;i<s.length();i++){
        if(mp.find(v1[i])==mp.end()){
            mp[v1[i]]=s[i];
        }
        else{
            char x=mp[v1[i]];
            if(x!=s[i]){
                c=1;
                break;
            }
        }
        if(mp1.find(s[i])==mp1.end()){
            mp1[s[i]]=v1[i];
        }
        else{
            string s1=mp1[s[i]];
            if(v1[i]!=s1){
                c=1;
                break;
            }
        }
       }
       if(c==1)cout<<"NO"<<endl;
       else cout<<"YES"<<endl;
}
}