#include<bits/stdc++.h>
using namespace std;
// constants
const unsigned int M = 1e9+7;
const long  double  pi= 3.141592653589793238;
//type defines
typedef long long int ll;
typedef long double lld;
typedef std::vector<ll> vll;
typedef std::unordered_map<ll, ll> umll;
typedef std::map<ll, ll> mll;
typedef unordered_map<char, ll> umllc;
typedef std::map<char, ll> mllc;
typedef pair<ll,ll> pll;
typedef vector<pll> vpll;
// macros
#define debug(x) cout << #x << " ---> " << x << endl;
#define pb push_back
#define pop pop_back
#define forf(i,a,b) for(int i=a; i<b; i++)
#define forb(i,a,b) for(int i=a; i>=b; i--)
#define cyes cout << "YES" << endl;
#define cno cout << "NO" << endl;
#define cmo cout << -1 << endl;
#define asort(v) sort(v.begin(),v.end());
#define dsort(v) sort(v.begin(), v.end(), greater<int>());
 // operator overloads
template<typename T1, typename T2> // cin >> pair<T1, T2>  cin >> p;
istream& operator>>(istream &istream, pair<T1, T2> &p) { return (istream >> p.first >> p.second); }
template<typename T> // cin >> vector<T>  cin >> v;
istream& operator>>(istream &istream, vector<T> &v){for (auto &it : v)cin >> it;return istream;}
template<typename T1, typename T2> // cout << pair<T1, T2>  cout << p << endl;
ostream& operator<<(ostream &ostream, const pair<T1, T2> &p) { return (ostream << p.first << " " << p.second); }
template<typename T> // cout << vector<T>  cout << v << endl;
ostream& operator<<(ostream &ostream, const vector<T> &c) { for (auto &it : c) cout << it << " "; return ostream; }
// checks
bool isPrime(ll n){if(n<=1)return false;if(n<=3)return true;if(n%2==0||n%3==0)return false;for(int i=5;i*i<=n;i=i+6)if(n%i==0||n%(i+2)==0)return false;return true;}
bool isPowerOfTwo(int n){if(n==0)return false;return (ceil(log2(n)) == floor(log2(n)));}
bool isPerfectSquare(ll x){if (x >= 0) {ll sr = sqrt(x);return (sr * sr == x);}return false;}
bool isEven(ll n){if(n%2==0) return true;return false;}
bool isOdd(ll n){if(n%2==0) return false;return true;}
// utility functions
template <typename T>   // print(t);
void print(T &&t)  { cout << t << "\n"; }
// sort according to the second element of the pair a is for ascending and d is for descending.
// check last line of the code to get an idea.
bool sorta(const pair<int,int> &a,const pair<int,int> &b){return (a.second < b.second);}
bool sortd(const pair<int,int> &a,const pair<int,int> &b){return (a.second > b.second);}
// bits converter decimal to binary and binary to decimal.
string decToBinary(int n){string s="";int i = 0;while (n > 0) {s =to_string(n % 2)+s;n = n / 2;i++;}return s;}
ll binaryToDecimal(string n){string num = n;ll dec_value = 0;int base = 1;int len = num.length();for(int i = len - 1; i >= 0; i--){if (num[i] == '1')dec_value += base;base = base * 2;}return dec_value;}
ll lcm(ll a, ll b){return (a*b)/(__gcd(a,b));}
ll sum_Number(ll n)
{
    if(n<=9)
    {
        return n;
    }
    else
    {
        return n%10+sum_Number(n/10);
    }
}
ll maximum_Subarray(std::vector<ll> v)
{
    ll max=0, total=0;
    forf(i,0,v.size()){
        total+=v[i];
        if(total>max) max=total;
        if(total<0) total=0;
    }
    return max;
}
int main() {
          int t; cin >> t;
      while(t--)
      {
          int n; cin >> n;
          vector<int>v(n);
          for(int i=0;i<n;i++)
          {
              cin >> v[i];
          }
          long long int flag=0,m=1e9+7;
          for(int i=0;i<n/2;i++)
          {
              int temp=(v[n-1-i]-v[i]);
              if(temp<=m && temp>=0)
              {
                  m=temp;
              }
              else
              {
                  flag=1;
                  break;
              }
          }
          if(flag==1)
          {
              //cout << v << endl;
              cout << -1 << endl;
          }
          else
          {
              //cout << v << endl;
              cout << v[n-1]-v[0] << endl;
          }
      }
                 }
// __gcd , 0 ko handle nahi kar pata hai.
// for sorting a vector pair it is given below.
// vpll v(n);
// cin >> v;
// sort(vsort(v),sorta);