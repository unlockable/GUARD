#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
ll x, b, c;
struct dish {
    long long x, y;
};
struct clan {
    long long p, q, r;
};
struct pos {
    long long x; bool is_dish;
};
vector<dish> dishes;
vector<clan> clans;
vector<pos> positions;
bool is_good(long long m) {
    long long i = 0, j = 0, k = 0;
    while (i < b + c && j < b) {
        if (positions[i].is_dish) {
            m -= dishes[j].y;
            j++;
            i++;
        } else {
            if (m >= clans[k].q) {
                m += clans[k].r;
            }
            k++;
            i++;
        }
                if (m <= 0) return false;
    }
    return m > 0;
}
int main() {
    // your code goes here
        int t;
    cin >> t;
    while (t--) {
        cin >> x >> b;
        positions.clear();
        dishes.resize(b);
        for (int i = 0; i < b; i++) cin >> dishes[i].x >> dishes[i].y;
        cin >> c;
        clans.resize(c);
        for (int i = 0; i < c; i++) cin >> clans[i].p >> clans[i].q >> clans[i].r;
                for (int i = 0; i < b; i++) positions.push_back({ dishes[i].x, true });
        for (int i = 0; i < c; i++) positions.push_back({ clans[i].p, false });
        sort(positions.begin(), positions.end(), [](const pos& i, const pos& j) -> bool {
            return i.x < j.x;
        });
                long long l = 0; // l is bad
        long long r = 2e18; // r is good
               // for (int i = 0; i < b + c; i++) cout << positions[i].x << " " << positions[i].is_dish << "\n";
        while (r > l + 1) {
            long long m = (l + r) / 2;
            if (is_good(m)) {
                r = m;
            } else {
                l = m;
            }
        }
        cout << r << "\n";
    }
    return 0;
}