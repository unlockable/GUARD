#include <iostream>
using namespace std;
int main() {
    int t;
    cin>>t;
    while(t--)
    {
        int n;
        cin>>n;
        int zeros=0,ones=0;
        char a[n];
        for(int i=0;i<n;i++)
        {
            cin>>a[i];
            if(a[i]=='0')
            zeros++;
            else
            ones++;
        }
        if(zeros==0 || ones==0)
        cout<<"1"<<endl;
        else if(zeros==ones)
        cout<<zeros*2<<endl;
        else if(zeros>ones)
        cout<<((ones*2)+1)<<endl;
        else
        cout<<((zeros*2)+1)<<endl;
    }
    }