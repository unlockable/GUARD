#include <bits/stdc++.h>
using namespace std;
int main() {
    int t;
    cin>>t;
    while(t--)
    {
        int n;
        cin>>n;
       if(n%2!=0)
       cout<<-1<<endl;
       else
       {
           for(int i=0;i<n;i++)
           {
               if(i<n/2)
               cout<<"0";
               else
               cout<<"1";
           }
           cout<<endl;
       }
    }
    return 0;
}