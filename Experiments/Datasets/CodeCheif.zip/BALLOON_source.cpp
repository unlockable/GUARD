#include <iostream>
using namespace std;
int main() {
    // your code goes here
    int t;
    cin>>t;
    while(t--){
        int n;
        cin>>n;
        int a[n];
        int count=0;
        int sum=0;
        for(int i=0;i<n;i++){
            cin>>a[i];
        }
        int C = 0;
        for(int i = 0; i<n; i++){
            if(a[i]>= 1 && a[i] <= 7){
                C = i; // Assign the maximum i to counter where all present number from 1 to 7 has been occured
            }
        }
        cout<<C+1<<endl;
    }
            return 0;
}