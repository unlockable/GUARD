#include<bits/stdc++.h>
using namespace std;
#define MAXIT 10000
#define ll long long
#define int long long
#define endl "\n"
#define ld long double
#define INF 1000000007
#define MOD 998244353
#define y second
#define x first
#define all(x) x.begin(),x.end()
ll max(ll a,ll b){return ((a>=b)?a:b);}
int maxself(int &var1,int var2){var1=max(var1,var2);return var1;}
ll min(ll a,ll b){return ((a<=b)?a:b);}
int minself(int &var1,int var2){var1=min(var1,var2);return var1;}
const int N=100;
int vec[N+10],n,dp[N+10][20000];
int gcd(int a,int b){return (b==0)?a:gcd(b,a%b);}
int f(int idx,int cur)
{
   if(idx==0)return (cur==1);
   int &ans=dp[idx][cur];
   if(ans!=-1)return ans;
   return ans=f(idx-1,cur)+f(idx-1,gcd(cur,vec[idx]));
}
ll solve(int tt,int t=0)
{
   memset(dp,-1,sizeof(dp));
   cin>>n;
   for(int i=1;i<=n;i++)
      cin>>vec[i];
   cout<<f(n,0)<<endl;
      return 0;
}
signed main()
{
   ios_base::sync_with_stdio(0);cin.tie(0);cout.tie(0);
   #ifdef LOCAL
      freopen("input.txt","r",stdin);
      freopen("output.txt","w",stdout);
   #endif
   ll t=1;
   cin>>t;
   while(t--){solve(t);}
   return 0;
}