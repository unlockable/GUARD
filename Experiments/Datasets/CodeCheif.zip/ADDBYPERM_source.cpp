#include <bits/stdc++.h>
using namespace std;
#define int long long
/*
Let the permutation be P, and values at indices be A.
Say we have a cycle C of length N (C gives the indices forming the cycle)
Cycle is - C[0] -> C[1] -> C[2] -> C[3] -> .... C[N - 1] -> C[0]
What will be the values after K moves?
Value at C[0] due to C[0] ---> (nCr(K, 0) + nCr(K, N) + ...) * A[C[0]]
Value at C[1] due to C[0] ---> (nCr(K, 1) + nCr(K, N + 1) + ...) * A[C[0]]
...
Value at C[N - 1] due to C[0] --> (nCr(K, N - 1) + nCr(K, 2*N - 1) + ...) * A[C[0]]
Value at C[0] due to C[N - 1] ---> (nCr(K, 1) + nCr(K, N + 1) + ...) * A[C[N - 1]]
C[0] due to C[1] --> (nCr(K, N - 1) + nCr(K, 2*N - 1) + ...) * A[C[1]]
Value at C[i] due to C[j] ---> sum(nCr(K, t*N + (i - j + N) % N)) * A[C[j]]
Let X[i] = sum(nCr(K, t*N + i)), 0 <= i < N
Let Y[i] = A[C[i]]
Final value at C[0] -> X[0]*Y[0] + X[1]*Y[N - 1] + X[2]*Y[N - 2] + ... X[N - 1]*Y[1]
Final value at C[1] -> X[0]*Y[1] + X[1]*Y[0] + X[2]*Y[N - 1] + .... X[N - 1]*Y[2]
and so on.
We can write Y[0] as Y[N] in C[0]. In C[1] --> Rewrite first two as Y[N + 1] and Y[N].
Final value at C[0] -> X[0]*Y[N] + X[1]*Y[N - 1] + X[2]*Y[N - 2] + ... X[N - 1]*Y[1].
Final value at C[1] -> X[0]*Y[N + 1] + X[1]*Y[N] + X[2]*Y[N - 1] + ... X[N - 1]*Y[2].
Assume P[i] = X[0] + X[1](x) + X[2](x^2) + .... X[N - 1](x^(n - 1))
Assume Q[i] = Y[0] + Y[1](x) + Y[2](x^2) + .... Y[N - 1](x^(n - 1)) + Y[0](x^n) + ... + Y[N - 1](x^(2n - 1))
Final value at C[0] --> Coefficient of x^n
Final value at C[1] --> Coefficient of x^(n + 1)
Final value at C[2] --> Coefficient of x^(n + 2)
and so on.
EZ!
How to compute X[i] ---> O(K) per cycle. There can be only sqrt(N) unique cycle lengths, so precompute these and store.
*/
const int MAXN = 200100;
const int MOD = 998244353;
int fact[MAXN], inv[MAXN];
int n, k;
vector <int> a, p;
vector <int> X[MAXN];
vector <int> ans;
int binpow(int a, int b) {
    int res = 1;
    while (b > 0) {
        if (b & 1) res = res * a % MOD;
        a = a * a % MOD;
        b >>= 1;
    }   
    return res % MOD;
}
// ---------------------------------------------------------------
// NTT - Copied from KACTL
#define rep(i, a, b) for(int i = a; i < (b); ++i)
#define all(x) begin(x), end(x)
#define sz(x) (int)(x).size()
typedef long long ll;
typedef pair<int, int> pii;
typedef vector<int> vi;
const ll mod = (119 << 23) + 1, root = 62; // = 998244353
// For p < 2^30 there is also e . g . 5 << 25, 7 << 26, 479 << 21
// and 483 << 21 (same root) . The last two are > 10^9.
typedef vector<ll> vl;
void ntt(vl &a) {
    int n = sz(a), L = 31 - __builtin_clz(n);
    static vl rt(2, 1);
    for (static int k = 2, s = 2; k < n; k *= 2, s++) {
    rt.resize(n);
    ll z[] = {1, binpow(root, mod >> s)};
    rep(i,k,2*k) rt[i] = rt[i / 2] * z[i & 1] % mod;
    }
    vi rev(n);
    rep(i,0,n) rev[i] = (rev[i / 2] | (i & 1) << L) / 2;
    rep(i,0,n) if (i < rev[i]) swap(a[i], a[rev[i]]);
    for (int k = 1; k < n; k *= 2)
    for (int i = 0; i < n; i += 2 * k) rep(j,0,k) {
    ll z = rt[j + k] * a[i + j + k] % mod, &ai = a[i + j];
    a[i + j + k] = ai - z + (z > ai ? mod : 0);
    ai += (ai + z >= mod ? z - mod : z);
    }
}
vl conv(const vl &a, const vl &b) {
    if (a.empty() || b.empty()) return {};
    int s = sz(a) + sz(b) - 1, B = 32 - __builtin_clz(s), n = 1
    << B;
    int inv = binpow(n, mod - 2);
    vl L(a), R(b), out(n);
    L.resize(n), R.resize(n);
    ntt(L), ntt(R);
    rep(i,0,n) out[-i & (n - 1)] = (ll)L[i] * R[i] % mod * inv %
    mod;
    ntt(out);
    return {out.begin(), out.begin() + s};
}
// End of NTT
// ---------------------------------------------------------------
int comb(int n, int r) {
    return fact[n] * inv[r] % MOD * inv[n - r] % MOD;
}
void calculate_coefficients(int k, int n) {
    X[n].resize(n, 0);
    for(int i = 0; i <= k; i++) {
        X[n][i % n] = (X[n][i % n] + comb(k, i)) % MOD;
    }
}
vector<int> multiply(vector<int> &a, vector<int> &b) {
    int n = a.size();
    int m = b.size();
    vector <int> c(n + m - 1, 0);
    for(int i = 0; i < n; i++) {
        for(int j = 0; j < m; j++) {
            c[i + j] = (c[i + j] + (a[i] * b[j] % MOD)) % MOD;
        }
    }
    return c;
}
void compute_cycle(vector <int> &c) {
    int cycle_length = c.size();
    if(cycle_length == 1) {
        ans[c[0]] = binpow(2, k) * a[c[0]] % MOD;
        return;
    }
    vector <int> Y;
    for(int i = 0; i < cycle_length; i++) {
        Y.push_back(a[c[i]]);
    }
    for(int i = 0; i < cycle_length; i++) {
        Y.push_back(Y[i]);
    }
    // vector<int> Z = multiply(X[cycle_length], Y);
    vector <int> Z = conv(X[cycle_length], Y);
    for(int i = cycle_length; i < 2*cycle_length; i++) {
        ans[c[i - cycle_length]] = Z[i];
    }
}
void solve() {
    set <int> cycle_lengths;
    vector <int> vis(n, false);
    vector<vector<int>> cycles;
    for(int i = 0; i < n; i++) {
        if(vis[i]) continue;
        vector <int> temp;
        int curr = 1;
        vis[i] = true;
        temp.push_back(i);
        int j = p[i];
        while(j != i) {
            vis[j] = true;
            temp.push_back(j);
            j = p[j];
            curr++;
        }
        cycle_lengths.insert(curr);
        reverse(temp.begin(), temp.end());
        cycles.push_back(temp);
    }   
    for(auto len : cycle_lengths) {
        calculate_coefficients(k, len);
    }
    for(auto cycle : cycles) {
        compute_cycle(cycle);
    }
    for(int i = 0; i < n; i++) {
        cout << ans[i] << " ";
    }
}
void solve_brute() {
    vector <int> ans = a;
    for(int i = 0; i < k; i++) {
        vector <int> new_ans = ans;
        for(int j = 0; j < n; j++) {
            new_ans[j] = (new_ans[j] + ans[p[j]]) % MOD;
        }
        ans = new_ans;
    }
    for(int i = 0; i < n; i++) {
        cout << ans[i] << " ";
    }
}
int32_t main() {
    ios::sync_with_stdio(false);
    cin.tie(0);
        fact[0] = inv[0] = 1;
    for(int i = 1; i < MAXN; i++) {
        fact[i] = fact[i - 1] * i % MOD;
        inv[i] = binpow(fact[i], MOD - 2);
    }
    cin >> n >> k;
    a.resize(n);
    p.resize(n);
    ans.resize(n);
    for(int i = 0; i < n; i++) {
        cin >> a[i];
    }
    for(int i = 0; i < n; i++) {
        cin >> p[i];
        --p[i];
    }
    // solve_brute();
    solve();
            return 0;
}