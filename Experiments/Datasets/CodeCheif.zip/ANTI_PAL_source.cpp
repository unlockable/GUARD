#include <iostream>
#include<bits/stdc++.h>
#define int long long
using namespace std;
void solve(){
    int n;
    cin>>n;
    string s;
    cin>>s;
    if(n % 2){
        cout<<"NO"<<endl;
        return;
    }
    int f[26] = {0};
    int flag = 0;
    for(int i = 0; i < s.size(); i++){
        f[s[i]-'a']++;
    }
    for(int i = 0; i < 26; i++){
        if(f[i] > n/2){
            cout<<"NO"<<endl;
            return;
        }
    }
    cout<<"YES"<<endl;
    string res = "";
    for(int i = 0; i < 26; i++){
        for(int j = 0; j < f[i]; j++)
            res = res + (char)('a' + i);
    }
    string s1 = res.substr(0, n/2);
    string s2 = res.substr(n/2, n/2);
    reverse(s1.begin(), s1.end());
    cout<<s1+s2<<endl;
    }
int32_t main() {
        int t;
    cin>>t;
    while(t--){
        solve();
    }
    return 0;
}