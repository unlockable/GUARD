#include <bits/stdc++.h>
using namespace std;
#define ll long long int
void solve()
{
    int n;
    cin >> n;
    vector<ll> v(n),atleast(n),atmost(n),freq(n,0);
    ll extra = 0;
        for(int i=0;i < n;i++)
    {
        cin >> v[i];
        freq[v[i]]++;
        extra += (n - v[i]);
    }
    sort(v.begin(),v.end());
        for(int i=0;i < n;i++)
    {
        atleast[i] = v.end() - upper_bound(v.begin(),v.end(),i);
        atmost[i] = atleast[i] + extra - (freq[i] * (n-i));
        cout << atleast[i] << " " << atmost[i] << endl;
    }
}
int main() {
    // your code goes here
    int t;
    cin >> t;
    while(t--)
    {
        solve();
    }
    return 0;
//solve
}//SOLVE
//lkjhgfdsaqwertyuioplkmnbvcxzdfghj