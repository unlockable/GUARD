#include<iostream>;
#include<iostream>
#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
struct segtree {
    struct node {
        int tag = -1;
        void upd(int l, int r, int v) {
            tag = v;
        }
    };
    node merge(const node &x, const node &y) {
        node ret;
        return ret;
    }
    void pushdown(int l, int r, int rt) {
        int m = (l + r) / 2;
        if(a[rt].tag != -1) {
            a[rt << 1].upd(l, m, a[rt].tag);
            a[rt << 1 | 1].upd(m+1, r, a[rt].tag);
            a[rt].tag = -1;
        }
    }
    void build(int l, int r, int rt) {
        if(l == r) {
            return;
        }
        int m = (l + r) / 2;
        build(l, m, rt << 1);
        build(m + 1, r, rt << 1 | 1);
        a[rt] = merge(a[rt << 1], a[rt << 1 | 1]);
    }
    template <typename T>
    void build(int l, int r, int rt, const vector<T> &v) {
        if(l == r) {
            a[rt].tag = v[l];
            return;
        }
        int m = (l + r) / 2;
        build(l, m, rt << 1, v);
        build(m + 1, r, rt << 1 | 1, v);
        a[rt] = merge(a[rt << 1], a[rt << 1 | 1]);
    }
    segtree(int n):n(n), a(n << 2) {
        build(0, n - 1, 1);
    }
    template <typename T>
    segtree(const vector<T> &v):n(v.size()), a(v.size() << 2) {
        build(0, n - 1, 1, v);
    }
    int n;
    vector<node> a;
    template <typename... V>
    void update(int L, int R, int l, int r, int rt, const V&... v) {
        if(L <= l && r <= R) {
            a[rt].upd(l, r, v...);
            return;
        }
        pushdown(l, r, rt);
        int m = (l + r) / 2;
        if(L <= m) update(L, R, l, m, rt << 1, v...);
        if(m < R) update(L, R, m+1, r, rt << 1 | 1, v...);
    }
    template <typename... V>
    void upd(int L, int R, const V&... v) {
        update(L, R, 0, n - 1, 1, v...);
    }
    node query(int p, int l, int r, int rt) {
        if(l == r) return a[rt];
        node ret;
        pushdown(l, r, rt);
        int m = (l + r) / 2;
        if(p <= m) return query(p, l, m, rt << 1);
        return query(p, m+1, r, rt << 1 | 1);
    }
    node qry(int p) {
        return query(p, 0, n - 1, 1);
    }
};
int main() {
    ios::sync_with_stdio(0), cin.tie(0), cout.tie(0);
    int t;
    cin >> t;
    while(t--) {
        int n, m, k, q;
        cin >> n >> m >> k >> q;
        vector<vector<int>> block(m);
        for(int i = 0; i < k; ++i) {
            int x, y;
            cin >> x >> y;
            --x, --y;
            block[y].push_back(x);
        }
        vector<vector<int>> w(m);
        for(int i = 0; i < m; ++i) {
            sort(block[i].begin(), block[i].end());
                       for(int j = 0; j < block[i].size(); ++j) {
                if(j == 0 || block[i][j] > block[i][j - 1] + 1) {
                    if(block[i][j] > 0) w[i].push_back(block[i][j]);
                }
                if(j + 1 == block[i].size() || block[i][j + 1] > block[i][j] + 1) {
                    if(block[i][j] + 1 < n) w[i].push_back(block[i][j] + 1);
                }
            }
        }
        vector<int> a(n);
        for(int j : w[0]) a[j] += 1;
        for(int i = 1; i < n; ++i) a[i] += a[i - 1];
        segtree st(a);
        vector<vector<pair<int,int>>> qry(m);
        for(int i = 0; i < q; ++i) {
            int x, y;
            cin >> x >> y;
            --x, --y;
            qry[y].push_back({x, i});
        }
        vector<int> ans(q);
        for(int i = 0; i < m; ++i) {
            // a[i - 1] -> a[i]
            if(i > 0) {
                int pre = 0;
                for(int j : w[i]) {
                    if(pre < j) {
                        int x = st.qry(pre).tag;
                        if(pre > 0) x = min(x, st.qry(pre - 1).tag + 1);
                        st.upd(pre, j - 1, x);
                    }
                    pre = j;
                }
                if(pre < n) {
                    int x = st.qry(pre).tag;
                    if(pre > 0) x = min(x, st.qry(pre - 1).tag + 1);
                    st.upd(pre, n - 1, x);
                }
            }
            for(auto [j, id] : qry[i]) {
                ans[id] = st.qry(j).tag;
            } //aa
        }
        for(int i = 0; i < q; ++i) cout << ans[i] << ' '; cout << '\n';
    }
}