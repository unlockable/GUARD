#include <bits/stdc++.h>
using namespace std;
#define ll long long
ll wins(ll n)
{
    if(n == 0)
    {
        return 0;
    }
    if(n & 1)
    {
        return !wins(n-1);
    }
    if(n % 4 != 0)
    {
        return !wins(n/2);
    }
    return 1;
}
int main() {
    // your code goes here
    int t;
    cin >> t;
    while(t--)
    {
        ll n;
        cin >> n;
                if(wins(n))
        {
            cout << "Alice\n";
        }
        else
        {
            cout << "Bob\n";
        }
    }
    return 0;
}