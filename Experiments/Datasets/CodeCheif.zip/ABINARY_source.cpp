#include<bits/stdc++.h>
using namespace std;
bool solve(string s){
    int sum=0;
    for(auto x:s){
        sum+=(x=='0'?-1:1);
        if(sum<0){
            return false;
        }
    }
    return sum==0;
}
int main(){
    int t;
    cin>>t;
    while(t--){
        string s;
        cin>>s;
        bool b=solve(s);
        if(b){
            cout<<"yes\n";
        }
        else{
            cout<<"no"<<endl;
        }
    }
    return 0;
}