#include <bits/stdc++.h>
using namespace std;
mt19937 rng(chrono::steady_clock::now().time_since_epoch().count());
template<const int &MOD>
struct Modular {
    int val;
    Modular(long long v = 0) {
        if (v < 0) v = v % MOD + MOD;
        if (v >= MOD) v %= MOD;
        val = int(v);
    }
    Modular<MOD> inv() const {
        int a = val, b = MOD, x = 0, y = 1;
        while (a != 0) { int k = b / a; b -= k * a; x -= k * y; swap(a, b); swap(x, y); }
        return Modular<MOD>(x);
    }
    friend Modular<MOD>& operator += (      Modular<MOD>& n, const Modular<MOD>& m) { n.val += m.val; if (n.val >= MOD) n.val -= MOD; return n; }
    friend Modular<MOD>  operator +  (const Modular<MOD>& n, const Modular<MOD>& m) { Modular<MOD> r = n; return r += m; }
    friend Modular<MOD>& operator -= (      Modular<MOD>& n, const Modular<MOD>& m) { n.val -= m.val; if (n.val < 0)  n.val += MOD; return n; }
    friend Modular<MOD>  operator -  (const Modular<MOD>& n, const Modular<MOD>& m) { Modular<MOD> r = n; return r -= m; }
    friend Modular<MOD>  operator -  (const Modular<MOD>& n)                      { return Modular<MOD>(-n.val); }
    friend Modular<MOD>& operator *= (      Modular<MOD>& n, const Modular<MOD>& m) { n.val = 1ll * n.val * m.val % MOD; return n; }
    friend Modular<MOD>  operator *  (const Modular<MOD>& n, const Modular<MOD>& m) { Modular<MOD> r = n; return r *= m; }
    friend Modular<MOD>& operator /= (      Modular<MOD>& n, const Modular<MOD>& m) { return n *= m.inv(); }
    friend Modular<MOD>  operator /  (const Modular<MOD>& n, const Modular<MOD>& m) { Modular<MOD> r = n; return r /= m; }
    Modular<MOD>& operator ++ (   ) { return *this += 1; }
    Modular<MOD>& operator -- (   ) { return *this -= 1; }
    Modular<MOD>  operator ++ (int) { Modular<MOD> r = *this; *this += 1; return r; }
    Modular<MOD>  operator -- (int) { Modular<MOD> r = *this; *this -= 1; return r; }
    friend bool operator == (const Modular<MOD>& n, const Modular<MOD>& m) { return n.val == m.val; }
    friend bool operator != (const Modular<MOD>& n, const Modular<MOD>& m) { return n.val != m.val; }
    explicit    operator       int() const { return val; }
    explicit    operator      bool() const { return val; }
    explicit    operator long long() const { return val; }
    friend istream& operator >> (istream& i,       Modular<MOD>& m) { long long k; i >> k; m = Modular<MOD> (k); return i; }
    friend ostream& operator << (ostream& o, const Modular<MOD>& m) { return o << m.val; }
    friend string   to_string(const Modular<MOD>& m) { return to_string(m.val); }
};
const int mod = 1000000007;
// const int mod = 998244353;
using Mint = Modular<mod>;
const int MAX = 1e9 + 1;
vector<Mint> ans, inc;
void solve() {
    long long n;
    cin >> n;
    long long D = sqrt(1 + 8 * n);
    long long k = (-1 + D) / 2;
    long long total = k * (k + 1) / 2;
    cout << ans[k] + inc[k] * (n - total) << '\n';
}
int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(0);
    int t = 1;
    // gen_primes();
    // gen_factorials((int)2e6 + 5);
    long long cur = 0, b = 1;
    ans.push_back(0);
    inc.push_back(0);
    while (cur < MAX) {
        inc.push_back(inc[b - 1] + b * (b + 1) / 2);
        ans.push_back(ans[b - 1] + inc[b - 1] * b);
        cur += b++;
    }
    // cout << fixed << setprecision(6);
    cin >> t;
    for (int te = 0; t--;){
        // cout << "Case #" << ++te << ": ";
        solve();
//klu
    }
}
//cpp