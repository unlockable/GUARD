#include<bits/stdc++.h>
#define L(i, j, k) for(int i = (j); i <= (k); ++i)
#define R(i, j, k) for(int i = (j); i >= (k); --i)
#define ll long long
#define sz(a) ((int) (a).size())
#define vi vector < int >
#define me(a, x) memset(a, x, sizeof(a))
#define ull unsigned long long
#define ld __float128
using namespace std;
const int N = 207;
int n;
int w[N];
int least[N];
ll ns;
bool Prime[N];
int p[N], tot;
vi e[N], go[N]; 
int col[N], val[N], dis[N];
bool vis[N], inq[N];
ll qwq=0;
ll solve(vi S) {
    ++qwq;
    if(!sz(S)) {
        return 1;
    }
    int w = S[0];
    queue < int > q;
    for(auto &u : S) vis[u] = true;
    q.push(w), vis[w] = false;
    int cnt = 0;
    while(!q.empty()) {
        int u = q.front();
        q.pop(), ++cnt;
        for(auto &v : e[u]) 
            if(vis[v]) 
                q.push(v), vis[v] = false;
    }
    if(cnt != sz(S)) {
        vi a, b;
        for(auto &u : S) 
            if(vis[u]) a.emplace_back(u), vis[u] = false;
            else b.emplace_back(u);
        return solve(a) * solve(b);
    }
    vi val(sz(S));
    L(i, 0, sz(S) - 1) val[i] = dis[S[i]];  
    vi T = S;
    T.erase(T.begin());
    ll ns = 0;
    L(o, 0, 1) {
        if(dis[w] + o > 2) continue;
        dis[w] += o;
        if(dis[w] == 1) {
            for(auto &v : go[w])
                dis[v] = 1;
        } else if(dis[w] == 2) {
            for(auto &u : S) vis[u] = true;
            for(int v = w * 2; v <= n; v += w)
                if(vis[v]) 
                    T.erase(lower_bound(T.begin(), T.end(), v));
            for(auto &u : S) vis[u] = false;
        }
        ns += solve(T);
    }
    L(i, 0, sz(S) - 1) dis[S[i]] = val[i];  
    for(auto &u : S) vis[u] = false;
    return ns;
}
int main() {
    ios :: sync_with_stdio(false);
    cin.tie(0); cout.tie(0); 
    cin >> n;
    L(i, 2, n) if(!Prime[i]) for(int j = i * 2; j <= n; j += i) Prime[j] = true;
    L(i, 2, n) Prime[i] ^= 1;
    L(i, 2, n) if(Prime[i]) p[++tot] = i; 
    L(i, 1, n) w[i] = 1;
//  L(i, 1, n) cin >> w[i];
    L(i, 1, tot) 
        L(j, 1, n / p[i])
            e[p[i] * j].emplace_back(j), e[j].emplace_back(p[i] * j), 
            go[j].emplace_back(p[i] * j);
    vi S;
    L(i, 1, n) S.emplace_back(i), vis[i] = true;
    cout << solve(S) << '\n';
//  cout<<"qwq="<<1. * qwq<<endl;
    return 0;
}