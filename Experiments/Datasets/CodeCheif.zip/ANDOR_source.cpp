#include <iostream>
using namespace std;
int main() {
    int t;
    cin>>t;
    while(t--){
        long long int x;
        cin>>x;
                if((x&0)+(x|0)==x)
            cout<<0<<" "<<x<<endl;
        else   
            cout<<-1<<endl;
    }
    return 0;
}