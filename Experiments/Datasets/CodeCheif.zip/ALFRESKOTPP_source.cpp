#include <bits/stdc++.h>
using namespace std;
int main()
{
    int n;
    int prime[10001] = {0}, count = 0;
    for (int i = 2; i < 10001; i++)
        for (int j = i; j * i < 10000; j++)
        {
            prime[j * i]++;
        }
    prime[1]=1;
    cin >> n;
    int arr[10000];
    for (int i = 0; i < n; i++)
    {
        cin >> arr[i];
    }
    for (int i = 0; i < n; i++)
        for (int j = i + 1, k = 0; j <n  & k < 2; j++, k++)
        {
            if (prime[arr[i]] == 0 & prime[arr[j]]==0)
            {
                if (arr[j] - arr[i]==2)
                {
                    count++;
                                    }
            }
        }
    cout << count;
    return 0;
}