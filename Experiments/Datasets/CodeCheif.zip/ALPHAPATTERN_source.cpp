#include <iostream>
using namespace std;
int main() {
    int t;
    cin>>t;
    while(t--){
        int n;
        cin>>n;
        int i=1;
        while(i<=n){
            int j=1;
            while(j<=i){
                char ch='A'+j-1;
                cout<<ch<<" ";
                j++;
            }
            cout<<endl;
            i++;
        }
    }
    return 0;
}