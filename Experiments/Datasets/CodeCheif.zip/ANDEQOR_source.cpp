#include <bits/stdc++.h>
using namespace std; 
#define rep(i, s, e) for (int i = (s) ; i < (e); ++i)
const int N = 20 ; 
int t,n ; 
string s ; 
long long calc(char target){
  vector<long long> dp(n) ; 
  for (int i = 0 ; i < n ; i++){
    dp[i] = s[i] == target; 
  }
  for (int i = 0 ; i < N ; i++){
    for (int j = n-1; ~j ; j--){
      if (j&(1<<i)) dp[j] += 2 * dp[j^(1<<i)] ; 
    }
  }
  long long res = 0 ;
  for (int i = 0 ; i < n ; i++){
          res += dp[i] * (target == s[i]) ; 
  }
  return res ; 
}
int main(){
  ios_base::sync_with_stdio(0); 
  cin.tie(0), cout.tie(0) ;
  cin >> t;  
  while (t--){
    cin >> n ; 
    cin >> s ; 
    cout << calc('0') + calc('1') << endl;
  }
}