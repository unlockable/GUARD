#include<bits/stdc++.h>
using namespace std;
int main()
{
    int t;
    cin>>t;
    while(t--)
    {
        int n,x;
        cin>>n;
        cout<<n/2<<endl;
        // set<int>v;
        // for(int i=1;i<n;i++)
        // {
        //     for(int j=i+1;j<n;j++)
        //     {
        //         x= __gcd(i,j);
        //         v.insert(x);
        //     }
        // }
        // auto it=--v.end();
        // cout<<*it<<endl;
    }
    }