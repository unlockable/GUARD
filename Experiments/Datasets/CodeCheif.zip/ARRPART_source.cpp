#include <bits/stdc++.h>
#define int ll
using namespace std;
#define ll long long
#define y1 zck_is_king
#define pii pair<ll, ll>
#define ull unsigned ll
#define f first
#define s second
#define ALL(x) x.begin(),x.end()
#define SZ(x) (int)x.size()
#define SQ(x) (x)*(x)
#define MN(a,b) a = min(a,(__typeof__(a))(b))
#define MX(a,b) a = max(a,(__typeof__(a))(b))
#define pb push_back
#define REP(i,n) for (int i = 0; i<n; ++i)
#define RREP(i,n) for (int i = n-1; i>=0; --i)
#define REP1(i,n) for (int i = 1; i<=n; ++i)
#define SORT_UNIQUE(c) (sort(c.begin(),c.end()), c.resize(distance(c.begin(),unique(c.begin(),c.end()))))
#ifdef BALBIT
#define IOS()
#define bug(...) fprintf(stderr,"#%d (%s) = ",__LINE__,#__VA_ARGS__),_do(__VA_ARGS__);
template<typename T> void _do(T &&x){cerr<<x<<endl;}
template<typename T, typename ...S> void _do(T &&x, S &&...y){cerr<<x<<", ";_do(y...);}
#else
#define IOS() ios_base::sync_with_stdio(0);cin.tie(0);
#define endl '\n'
#define bug(...)
#endif
const int iinf = 1e9+10;
const ll inf = 1ll<<60;
void GG(){cout<<"0\n"; exit(0);}
const int mod = 998244353 ;
ll mpow(ll a, ll n, ll mo = mod){ // a^n % mod
    ll re=1;
    while (n>0){
        if (n&1) re = re*a %mo;
        a = a*a %mo;
        n>>=1;
    }
    return re;
}
ll inv (ll b, ll mo = mod){
    if (b==1) return b;
    return (mo-mo/b) * inv(mo%b) % mo;
}
void NTT(vector<ll> &a, ll mo, bool rev=0){
    // mo has to be 2^k * c + 1
    int n = SZ(a);
    while ((n&(-n))!=n) {
        a.pb(0); n++;
    }
    for (int i = 1, j = 0; i<n; i++){
        int bit = n>>1;
        while (j>=bit) j-=bit, bit>>=1; j+=bit;
        if (i<j) swap(a[i], a[j]);
    }
    for (int B = 2; B<=n; B*=2){
        ll w0 = mpow(3,(mo-1)/(B),mo);
        for (int i = 0; i<n; i+=B){
            ll w = 1;
            for (int j = 0; j<B/2; j++){
                ll u = a[i+j], v = w*a[i+j+B/2]%mo;
                a[i+j] = u+v, a[i+j+B/2] = u-v;
                if (a[i+j]>=mo) a[i+j]-=mo; if (a[i+j+B/2]<0) a[i+j+B/2]+=mo;
                w = w*w0%mo;
            }
        }
    }
    if (rev) {
        reverse(next(a.begin()),a.end());
        ll invn = inv(n,mo);
        REP(i,n) a[i] = a[i]*invn%mo;
    }
}
vector<ll> mul (vector<ll> a, vector<ll> b, ll mo = mod){
    int n = 1; while (n < SZ(a) + SZ(b)) n*=2;
    vector<ll> x(n), y(n);
    REP(i, SZ(a)) x[i] = a[i]; REP(j, SZ(b)) y[j] = b[j];
    NTT(x,mo); NTT(y,mo);
    REP(i, n) x[i] = x[i] * y[i] % mo;
    NTT(x,mo,1);
    while (x.size()>1 && x.back()==0) x.pop_back(); return x;
}
const int maxn = 1e6+66;
ll iv[maxn];
signed main(){
    IOS();
    iv[1] = 1;
    for (int i = 2; i<maxn; ++i) {
        iv[i] = (mod-mod/i) * iv[mod%i] % mod;
    }
    bug(iv[124] * 124 % mod);
    int T; cin>>T;
    while (T--) {
        int n,x; cin>>n>>x;
        map<int,int> yo;
        int prv = -1;
        int bg = -1;
        REP(i,n) {
            int y; cin>>y;
            MX(bg, y);
            if (y >= x) {
                if (prv != -1) {
                    yo[(i-prv)]++;
                }
                prv = i;
            }
        }
        if (bg < x) {
            REP(i,n) cout<<"0 ";
            cout<<endl;
            continue;
        }
        vector<ll> now = {1};
        vector<pii> po;
        for (pii p : yo) po.pb(p); reverse(ALL(po));
        for (pii p : po) {
            vector<ll> ta(p.s+1);
            ll C = 1;
            ll pw = 1;
            RREP(i, p.s+1) {
                ta[i] = C * pw % mod;
                pw = pw * p.f % mod;
                C = C * (i) % mod * iv[p.s+1-i] % mod;
                bug(p.s, i, C);
            }
            reverse(ALL(ta));
            now = mul(now, ta);
        }
        REP(i, n) {
            if (i < SZ(now)) cout<<now[i];
            else cout<<0;
            cout<<' ';
        }
        cout<<endl;
    }
}