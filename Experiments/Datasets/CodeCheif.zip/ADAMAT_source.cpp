#include<iostream>
using namespace std ;
int main(){
   int t;
   cin>>t;
   while (t--)
   {
      int n;int ans=0,flag=0;
      cin>>n;
      int arr[n+1][n+1];
      for (int i = 1; i <= n; i++)
      {
         for (int j = 1; j <= n; j++)
         {
            cin>>arr[i][j];
         }  
      }
      for(int l=n;l>=1;--l){
         for(int i=1;i<=l;++i){
            if(arr[i][l]>arr[l][i] && flag==0){
               ++ans;
               flag=1;
               break;
            }
            else if(arr[i][l]<arr[l][i] && flag==1){
               ++ans;
               flag=0;
               break;
            }
         }
      }
      cout<<ans<<endl;
   }
   return 0;
}