// I may fail a thousand times
// But there is no giving up
// IOI - here I come
#include <bits/stdc++.h>
#define int long long
using namespace std;
const int N=1e5+5;
vector<int> g[N];
vector<pair<int,int>> queries[N];
int ans[N];
map<int,int> dfs(int v){
    int n=(int)g[v].size();
    map<int,int> cur;
    if(!n)cur[1]=1;
    else if(n==1)cur=dfs(g[v][0]);
    else{
        for(int u:g[v]){
            map<int,int> tmp=dfs(u);
            for(auto it:tmp){
                if(n*it.first<=1e6){
                    cur[n*it.first]+=it.second;
                }
            }
        }
    }
    for(auto it:queries[v]){
        int w=it.first;
        int k=it.second;
        int cnt=0;
        for(auto jt:cur){
            if(w%jt.first==0){
                cnt+=w/jt.first*jt.second;
            }
        }
        ans[k]=w-cnt;
    }
    return cur;
}
signed main(){
    ios_base::sync_with_stdio(0);cin.tie(0);
    int n;cin>>n;
    for(int i=1;i<n;i++){
        int p;cin>>p;
        g[p].push_back(i+1);
    }
    int q;cin>>q;
    for(int i=1;i<=q;i++){
        int v,w;cin>>v>>w;
        queries[v].push_back({w,i});
    }
    dfs(1);
    for(int i=1;i<=q;i++)cout<<ans[i]<<'\n';
    return 0;
}