#include <iostream>
#include <cmath>
using namespace std;
int func(int n){
    int p=0;
    while(pow(2,p)<=n){
        p++;
    }
    int ans=n-pow(2,p-1);
    return ans;
}
int main() {
    int t;cin>>t;
    while(t-->0){
        int n;cin>>n;
        int c=0;
        while(n>0){
            n=func(n);
            c++;
        }
        cout<<c<<endl;
    }
    return 0;
}