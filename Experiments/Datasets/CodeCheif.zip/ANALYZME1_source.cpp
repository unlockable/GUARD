#include<iostream>
#include<string>
using namespace std;
int main()
{
    int n,m;
    cin>>n>>m;
    char  s[n+1][m+1];
    for(int i=0;i<n;i++)
     cin>>s[i];
    int ans=0;
    for(int i=0;i<n;i++)
    {
        for(int j=0;j<m;j++)
        {
            if(s[i][j]=='s')
            {
                if(j+3<m)
                {
                    if(s[i][j]=='s' && s[i][j+1]=='a' && s[i][j+2]=='b' && s[i][j+3]=='a')
                        ans++;
                    if(i+3<n)
                    {
                        if(s[i][j]=='s' && s[i+1][j+1]=='a' && s[i+2][j+2]=='b' && s[i+3][j+3]=='a')
                             ans++;
                    }
                }
                if(i+3<n)
                {
                    if(s[i][j]=='s' && s[i+1][j]=='a' && s[i+2][j]=='b' && s[i+3][j]=='a')
                        ans++;
                }
                if((i-3)>=0 && (j+3)<m)
                {
                    if(s[i][j]=='s' && s[i-1][j+1]=='a' && s[i-2][j+2]=='b' && s[i-3][j+3]=='a')
                             ans++;
                }
            }
        }
    }
    cout<<ans;
    return 0;
}