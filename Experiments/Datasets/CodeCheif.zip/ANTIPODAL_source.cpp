#include<bits/stdc++.h>
#define double long long
#define ll long long
using namespace std;
const int N = 3e5 + 9;
const double eps= 0;
int sign(double x) { return (x > eps) - (x < -eps); }
struct PT {
    double x, y;
    PT() { x = 0, y = 0; }
    PT(double x, double y) : x(x), y(y) {}
    PT(const PT &p) : x(p.x), y(p.y)    {}
    PT operator + (const PT &a) const { return PT(x + a.x, y + a.y); }
    PT operator - (const PT &a) const { return PT(x - a.x, y - a.y); }
    PT operator * (const double a) const { return PT(x * a, y * a); }
    double operator * (const PT a) const { return (x * a.y - y * a.x); }
    double operator | (const PT a) const { return (x * a.x + y * a.y); }    
        friend PT operator * (const double &a, const PT &b) { return PT(a * b.x, a * b.y); }
    PT operator / (const double a) const { return PT(x / a, y / a); }
    bool operator == (PT a) const { return sign(a.x - x) == 0 && sign(a.y - y) == 0; }
    bool operator != (PT a) const { return !(*this == a); }
    bool operator < (PT a) const { return sign(a.x - x) == 0 ? y < a.y : x < a.x; }
    bool operator > (PT a) const { return sign(a.x - x) == 0 ? y > a.y : x > a.x; }
    double norm() { return sqrt(x * x + y * y); }
    double norm2() { return x * x + y * y; }
    PT perp() { return PT(-y, x); }
    double arg() { return atan2(y, x); }
    PT truncate(double r) { // returns a vector with norm r and having same direction
        double k = norm();
        if (!sign(k)) return *this;
        r /= k;
        return PT(x * r, y * r);
    }
};
inline double dot(PT a, PT b) { return a.x * b.x + a.y * b.y; }
inline double dist2(PT a, PT b) { return dot(a - b, a - b); }
inline double dist(PT a, PT b) { return sqrt(dot(a - b, a - b)); }
inline double cross(PT a, PT b) { return a.x * b.y - a.y * b.x; }
inline double cross2(PT a, PT b, PT c) { return cross(b - a, c - a); }
inline int orientation(PT a, PT b, PT c) { return sign(cross(b - a, c - a)); }
PT base;
bool half(PT p) { return p.y > 0 || (p.y == 0 && p.x < 0);}
void polar_sort(vector<PT> &v) {
    sort(v.begin(), v.end(), [](PT a,PT b) {
        return make_tuple(half(a-base),0,(a-base)|(a-base))<make_tuple(half(b-base),(a-base)*(b-base),(b-base)|(b-base));
    });
}
int nxt(int k,int n)
{
    return (k+1)%n;
}
void print(PT a)
{
    cout<<a.x<<" "<<a.y<<endl;
}
int main()
{
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    int tc;
    cin>>tc;
    while(tc--)
    {
        int n;
        cin>>n;
        std::vector<PT> v(n);
        for( int i=0;i<n;i++ )
            cin>>v[i].x>>v[i].y;
        long long ans= 0;
        for( int i=0;i<n;i++ )
        {
            base= v[i];
            std::vector<PT> vv;
            for( int j=0;j<n;j++ )
                if(j!=i)
                    vv.push_back(v[j]);
            int nn= n-1;
            polar_sort(vv);
            // if(!i)
            //     for(auto x: vv)
            //         cout<<x.x<<" "<<x.y<<endl;
            int k= 0;
            for( int j=0;j<nn;j++ )
            {
                if(k==j)
                    k= nxt(j,nn);
                // if(i==0 and j==1)
                //     cout<<k<<endl;
                while(cross(vv[j]-base,vv[k]-base)==0 and k!=j)
                    k= nxt(k,nn);
                if(k==j)
                    k= nxt(k,nn);
                while( k!=j and cross(vv[j]-base,vv[k]-base)>0 and dot(vv[j]-base,vv[k]-base)>0)
                    k= nxt(k,nn);
                if(k==j)
                    k= nxt(k,nn);   
                                long long notun= 0;
                while(k!=j and cross(vv[j]-base,vv[k]-base)>0 and dot(vv[j]-base,vv[k]-base)==0)
                {
                    // cout<<i<<endl;
                    // print(base);
                    // print(vv[j]);
                    // print(vv[k]);
                    // cout<<endl;
                    k= nxt(k,nn), notun++;
                }
                ans+= notun;
                int jj= j+1;
                while(jj<n and cross(vv[j]-base,vv[jj]-base)==0)
                    ans+= notun, jj++;
                j= jj-1;
            }
        }
        cout<<ans<<"\n";
    }
}
                                                                    