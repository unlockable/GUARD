#include <bits/stdc++.h>
using namespace std;
int main() {
    // your code goes here
    int t;
    cin>>t;
    while(t--){
        int n;
        cin>>n;
        int p=n;
        int even=0;
        while(n--){
            int z;
            cin>>z;
            if(z%2==0)
            even++;
        }
        if(even==p)
        cout<<0<<endl;
        else
        cout<<even<<endl;
    }
    return 0;
}