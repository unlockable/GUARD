#include <iostream>
using namespace std;
int main() {
    int t;
    cin>>t;
        for(int i=0; i<t; i++){
        int x;
        cin>>x;
        cout<<x-10<<endl;
    }
            return 0;
}                                         