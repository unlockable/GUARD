#include <bits/stdc++.h>
using namespace std;
int main() {
    // your code goes here
    int kk;
    cin>>kk;
    while(kk--)
    {
        long long a,b,c,d;
        cin>>a>>b>>c>>d;
        if( c%a==0 && d%b==0 && (c/a==d/b||c/a==(d/b)-1||c/a==(d/b)+1))
        {
            cout<<"YES"<<endl;
        }
        else
        {
            cout<<"NO"<<endl;
        }
            }
    return 0;
}