#include <bits/stdc++.h>
using namespace std;
#define f(a,b,n) for(int a=b; a<n; a++)
#define ll long long
#define lli long long int 
#define speed                         \
    ios_base::sync_with_stdio(false); \
    cin.tie(NULL);                    \
    cout.tie(NULL);
void solve(){
    int n; cin>>n;
    map<int, int> m;
    vector<int> v;
    f(i,0,n){
        int temp; cin>>temp;
        m[temp] = i+1;
        v.push_back(temp);
    }
    // sort(v.begin(), v.end());
        int ans = INT_MAX;
    // int i=0;
    for(auto it : m){
        int num = it.first;
        int ind = it.second;
        if(ind==num){
            // i++;
            continue;
        }
                if(ans==INT_MAX)
            ans = abs(ind-num);
        else
            ans = gcd(ans, abs(ind-num));
        // swap(m[num], m[ind]);
        // cout<<num<<"  "<<ind<<"  "<<ans<<endl;
        // i++;
    }
    cout<<ans<<endl;
}
int main(){
    speed;
    int cases;
    cin>>cases;
    while(cases--){
        solve();
    }
    return 0;
}