#include<bits/stdc++.h>
using namespace std::chrono;
using namespace std;
#define int long long
#define fr(n) for (int i = 0; i < n; i++)
#define rep(i,n) for (int i = 0; i < n; i++)
#define fr1(n) for (int i = 1; i <= n; i++)
#define rep1(i,n) for (int i=1; i<=n; i++)
#define all(v) v.begin(), v.end()
#define getunique(v) {sort(all(v)); v.erase(unique(all(v)), v.end());}
#define mod 1000000007
#define fast_io ios_base::sync_with_stdio(false); cin.tie(NULL)
#define nax 100005
#define pb push_back
#define vi vector<int>
#define sz size()
#define ff first
#define ss second
#define setbits(x) __builtin_popcountll(x)
#define vi vector<int>
typedef long long ll;
typedef unsigned long long ull;
typedef long double lld;
#ifndef ONLINE_JUDGE
#define debug(x)cerr << #x << " ";_print(x);cerr << endl;
#else
#define debug(x)
#endif
#define PI 3.141592653589793238462
void _print(int t) {cerr << t;}
void _print(string t) {cerr << t;}
void _print(char t) {cerr << t;}
void _print(lld t) {cerr << t;}
void _print(double t) {cerr << t;}
void _print(ull t) {cerr << t;}
template<class T,class V> void _print(pair <T,V> p);
template<class T>void _print(vector <T>v);
template<class T>void _print(set <T>v);
template<class T,class V>void _print(map <T,V>v);
template<class T>void _print(multiset <T>v);
template<class T,class V>void _print(pair <T,V>p) {cerr<<"{ ";_print(p.ff);cerr<<" , ";_print(p.ss);cerr<<" } ";}
template<class T>void _print(vector<T>v){cerr<<"[ ";for(T i:v){_print(i);cerr<<" ";}cerr<<"]";}
template<class T>void _print(set<T>v){cerr<<"[ ";for(T i:v){_print(i); cerr<<" ";}cerr<<"]";}
template<class T>void _print(multiset<T>v){cerr<<"[ ";for(T i:v){_print(i);cerr<<" ";}cerr<<"]";}
template<class T,class V>void _print(map<T,V>v){cerr<<"[ ";for(auto i:v){_print(i);cerr<<" ";} cerr<<"]";}
int binpow(int a,int b,int m=923372036854775807){a%=m;int res=1;while(b>0){if(b&1)res=res*a%m;a=a*a%m;b>>=1;}return res;}
int value(char c) {
    int ans = 0;
    if (c >= 'A' && c <= 'Z') ans += c - 'A';
    if (c >= 'a' && c <= 'z') {
        ans += 26;
        ans += c - 'a';
    }
    if (c >= '0' && c <= '9') {
        ans += 26;
        ans += 26;
        ans += c - '0';
    }
    if (c == '+') {
        ans += 26 * 2;
        ans += 10;
    }
    if (c == '/') {
        ans += 26 * 2;
        ans += 10;
        ans += 1;
    }
    return ans;
}
void solve(){
    int n;
    cin >> n;
    string s;
    cin >> s;
    int ans = 0;
    for (int i = 0; i < n; i++) {
        ans = (ans + (binpow(64, n - 1 - i, 9) * value(s[i]))) % 9;
    }
    cout << ans<< "\n";
}
signed main(){
    fast_io;
    #ifndef ONLINE_JUDGE
        freopen("input.txt","r", stdin);
        freopen("error.txt","w", stderr);
    #endif
    auto start = high_resolution_clock::now();
    int loop=1;
    cin >> loop;
    cout<<fixed;
    cout<<setprecision(10);
    for (int i = 1; i <= loop; i++) {
        //cout<< "Case #"<<i<<": ";
        solve();
    }
    auto stop = high_resolution_clock::now();
    auto duration = duration_cast<milliseconds>(stop - start);
    //cout << "\nTime: " << duration.count() << "ms\n";
   return 0;
}