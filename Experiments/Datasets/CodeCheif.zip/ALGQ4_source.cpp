// Om Namah Shivaya
#include <bits/stdc++.h>
#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>
using namespace std;
using namespace __gnu_pbds;
template<typename T> using Tree = tree<T, null_type, less<T>, rb_tree_tag, tree_order_statistics_node_update>;
typedef long long int ll;
typedef long double ld;
typedef pair<int, int> pii;
typedef pair<ll, ll> pll;
#define fastio ios_base::sync_with_stdio(false); cin.tie(NULL)
#define pb push_back
#define endl '\n'
#define sz(a) a.size()
#define setbits(x) __builtin_popcountll(x)
#define ff first
#define ss second
#define conts continue
#define ceil2(x, y) ((x + y - 1) / (y))
#define all(a) a.begin(), a.end()
#define rall(a) a.rbegin(), a.rend()
#define yes cout << "Yes" << endl
#define no cout << "No" << endl
#define rep(i, n) for(int i = 0; i < n; ++i)
#define rep1(i, n) for(int i = 1; i <= n; ++i)
#define rev(i, s, e) for(int i = s; i >= e; --i)
#define trav(i, a) for(auto &i : a)
bool iseven(ll a) {
    if (!(a & 1)) return true;
    else return false;
}
template<typename T>
void amin(T &a, T b) {
    a = min(a, b);
}
template<typename T>
void amax(T &a, T b) {
    a = max(a, b);
}
#define debug(x) cout << #x << " = "; print(x); cout << endl
void print(int i) {
    cout << i;
}
void print(ll i) {
    cout << i;
}
void print(string i) {
    cout << i;
}
void print(char i) {
    cout << i;
}
void print(double i) {
    cout << i;
}
void print(ld i) {
    cout << i;
}
template<typename T, typename V>
void print(pair<T, V> v) {
    cout << "{";
    print(v.ff);
    cout << ",";
    print(v.ss);
    cout << "}";
}
template<typename T>
void print(vector<T> v) {
    cout << "[ ";
    for (auto i : v) {
        print(i);
        cout << " ";
    }
    cout << "]";
}
template<typename T>
void print(set<T> v) {
    cout << "[ ";
    for (auto i : v) {
        print(i);
        cout << " ";
    }
    cout << "]";
}
template<typename T>
void print(multiset<T> v) {
    cout << "[ ";
    for (auto i : v) {
        print(i);
        cout << " ";
    }
    cout << "]";
}
template<typename T>
void print(Tree<T> v) {
    cout << "[ ";
    for (auto i : v) {
        print(i);
        cout << " ";
    }
    cout << "]";
}
template<typename T, typename V>
void print(map<T, V> v) {
    cout << "{ ";
    for (auto p : v) {
        print(p);
        cout << " ";
    }
    cout << "}";
}
const int MOD = 1e9 + 7;
const int N = 1e6 + 5;
const int inf1 = int(1e9) + 5;
const ll inf2 = ll(1e18) + 5;
const int K = 55;
vector<ll> spf(N);
void precalc() {
    rep(i, N) spf[i] = i;
    for (ll i = 2; i < N; ++i) {
        if (spf[i] != i) conts;
        for (ll j = i * i; j < N; j += i) {
            amin(spf[j], i);
        }
    }
}
vector<ll> idval(K);
struct DSU {
    vector<int> par, rankk, siz;
    vector<ll> pairs;
    vector<array<ll, 3>> cnt;
    vector<vector<ll>> valcnt;
    ll sum;
    DSU() {
    }
    DSU(int n) {
        init(n);
    }
    void init(int n) {
        par = vector<int>(n + 1);
        rankk = vector<int>(n + 1);
        siz = vector<int>(n + 1);
        pairs = vector<ll>(n + 1);
        cnt = vector<array<ll, 3>>(n + 1);
        valcnt = vector<vector<ll>>(n + 1, vector<ll>(K));
        sum = 0;
        rep(i, n + 1) create(i);
    }
    void create(int u) {
        par[u] = u;
        rankk[u] = 0;
        siz[u] = 1;
        pairs[u] = 0;
        cnt[u].fill(0);
    }
    int find(int u) {
        if (u == par[u]) return u;
        else return par[u] = find(par[u]);
    }
    bool same(int u, int v) {
        return find(u) == find(v);
    }
    void merge(int u, int v) {
        u = find(u), v = find(v);
        if (u == v) return;
        if (rankk[u] == rankk[v]) rankk[u]++;
        if (rankk[u] < rankk[v]) swap(u, v);
        par[v] = u;
        siz[u] += siz[v];
        rep(j, 3) {
            ll x = cnt[u][j] * cnt[v][2 - j];
            sum += x;
        }
        rep(j, K) {
            ll x = idval[j];
            if (x != -1) {
                if (spf[x] == x and x >= 2) {
                    sum -= valcnt[u][j] * valcnt[v][j];
                }
            }
        }
        rep(j, 3) {
            cnt[u][j] += cnt[v][j];
        }
        rep(j, K) {
            valcnt[u][j] += valcnt[v][j];
        }
    }
};
void solve(int test_case)
{
    // stress tested to identify the bug
    // ac solution used to stress test:
    // https://www.codechef.com/viewsolution/86370224
    // mistake made: the graph given in the input is not necessarily connected
    ll n, m; cin >> n >> m;
    vector<pll> edges(m + 5);
    rep1(i, m) {
        ll u, v; cin >> u >> v;
        if (u > v) swap(u, v);
        edges[i] = {u, v};
    }
    vector<ll> a(n + 5);
    rep1(i, n) cin >> a[i];
    ll q; cin >> q;
    vector<array<ll, 3>> queries(q + 5);
    map<pll, ll> mp2;
    rep1(i, m) {
        auto [u, v] = edges[i];
        if (mp2[ {u, v}]) {
            exit(101);
        }
        mp2[ {u, v}]++;
    }
    rep1(i, q) {
        ll t; cin >> t;
        if (t == 1) {
            ll u, v; cin >> u >> v;
            if (u > v) swap(u, v);
            queries[i] = {t, u, v};
            mp2[ {u, v}]--;
        }
        else {
            queries[i] = {t, -1, -1};
        }
    }
    fill(all(idval), -1);
    ll ptr = 1;
    map<ll, ll> mp;
    rep1(i, n) {
        ll x = a[i];
        if (mp.count(x)) conts;
        mp[x] = ptr;
        idval[ptr] = x;
        ptr++;
    }
    DSU dsu(n + 5);
    rep1(i, n) {
        ll x = a[i];
        ll prevv = -1;
        ll primes = 0;
        bool flag = true;
        while (x > 1) {
            ll p = spf[x];
            x /= p;
            if (p != prevv) primes++;
            else flag = false;
            prevv = p;
        }
        if (flag) {
            if (primes <= 2) {
                dsu.cnt[i][primes]++;
                dsu.valcnt[i][mp[a[i]]]++;
            }
        }
    }
    rep1(i, m) {
        auto [u, v] = edges[i];
        if (mp2[ {u, v}]) {
            dsu.merge(u, v);
        }
    }
    vector<ll> ans(q + 5, -1);
    rev(i, q, 1) {
        auto [t, u, v] = queries[i];
        if (t == 1) {
            dsu.merge(u, v);
        }
        else {
            ans[i] = dsu.sum;
        }
    }
    rep1(i, n) dsu.merge(1, i);
    ll tot = dsu.sum;
    rep1(i, q) {
        if (ans[i] != -1) {
            cout << tot - ans[i] << endl;
        }
    }
}
int main()
{
    precalc();
    fastio;
    int t = 1;
    cin >> t;
    rep1(i, t) {
        solve(i);
    }
    return 0;
}