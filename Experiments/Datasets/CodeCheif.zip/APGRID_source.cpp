#include <iostream>
#include<bits/stdc++.h>
#include<math.h>
#include<cmath>
#include<stdio.h>
#define ll long long
using namespace std;
int main() {
int t;
cin>>t;
    while(t--){
        ll h,l;
        int u[10000];
        int n,p;
        cin>>n>>p;
        if(n<=p){
        int a=1,d=n+1,x=1;
        for(int i=1;i<=n;i++){
            cout<<a<<" ";
            for(int j=1;j<p;j++){
                cout<<a+(x*i)<<" ";
                x++;
            }
            x=1;
            a=a+d;
            cout<<'\n';
        }
        }
        else{
            int a=1,d=p+1,x=1;
        for(int i=1;i<=n;i++){
            cout<<i<<" ";
            for(int j=1;j<p;j++){
                cout<<i+(d*x)<<" ";
                x++;
            }
            x=1;
            d++;
            h=0;
            cout<<'\n';
                    }
    }
}
return 0;
}