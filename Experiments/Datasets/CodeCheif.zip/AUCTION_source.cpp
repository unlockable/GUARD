#include <iostream>
using namespace std;
int main() {
    // your code goes here
        int t,x,y,z;
    cin>>t;
    while(t-->0){
        cin>>x>>y>>z;
        z>y&&z>x?cout<<"Charlie"<<endl:y>x&&y>z?cout<<"Bob"<<endl:cout<<"Alice"<<endl;
    }
    return 0;
}