#include <iostream>
using namespace std;
int main() {
    int t,n;
    cin>>t;
    while(t--)
    {
        cin>>n;
        int ar[n];
        for(int i=0;i<n;i++)
        {
            cin>>ar[i];
        }
        int x=ar[0]^ar[1];
        for(int i=2;i<n;i++)
        {
            x=x^ar[i];
                    }
        if(x==0)
        cout<<"YES"<<endl;
        else
        cout<<"NO"<<endl;
    }
        // your code goes here
    return 0;
}