#include<bits/stdc++.h>
using namespace std;
typedef long long int uli;
int rint(char nxt){
  char ch=getchar();
  int v=0;
  int sgn=1;
  if(ch=='-')sgn=-1;  
  else{
    assert('0'<=ch&&ch<='9');
    v=ch-'0';
  }
  while(true){
    ch=getchar();
    if('0'<=ch && ch<='9')v=v*10+ch-'0';
    else{
      assert(ch==nxt);
      break;
    }
  }
  return v*sgn;
}
int main(){
//  freopen("1.in","r",stdin);
//  freopen("1.out","w",stdout);
  int t=rint('\n');
  assert(1<=t&&t<=32);
  while(t--){
    int r=rint(' ');
    int c=rint('\n');
    assert(1<=r&&r<=8);
    assert(1<=c&&c<=8);
    assert((r+c)%2==0);
    vector<pair<int,int> >ans={{r,c}};
    int mid=(r+c)/2;
    ans.push_back({mid,mid});
    ans.push_back({1,1});
    for(r=2;r<=4;r++){
      ans.push_back({r,r});
      ans.push_back({1,r+r-1});
      ans.push_back({r+r-1,1});
      ans.push_back({r,r});
    }
    for(r=5;r<=8;r++){
      int x=2*(r-4);
      ans.push_back({r,r});
      ans.push_back({x,8});
      ans.push_back({8,x});
      ans.push_back({r,r});
    }
     printf("%d\n",int(ans.size()));
    for(auto p:ans){
      printf("%d %d\n",p.first,p.second);
    }
  }
  assert(getchar()==EOF);
  return 0;
}