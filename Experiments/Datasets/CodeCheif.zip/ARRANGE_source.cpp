 #include <bits/stdc++.h>
#define ll long long int
using namespace std;
ll rev_bin(ll n, ll k)
{
    ll num=n,ans=0ll,x=pow(2,k-1);
    while(num)
    {
        ans+=((num%2)*x);
        x>>=1ll;
        num/=2ll;
    }
    return ans;
}
int main() 
{
    ll t,n,i,j,k;
    cin >> t;
    while(t--)
    {
        string s;
        cin >> n >> s;
        vector<ll>vis(pow(2,n),0ll);
        for(i=0;i<pow(2,n);i++)
        {
            j=rev_bin(i,n);
            if(!vis[i] || !vis[j])
            {
                swap(s[i],s[j]);
                vis[i]=vis[j]=1ll;
            }
        }
        cout << s << "\n";
    }
    return 0;
}