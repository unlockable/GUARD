#include <bits/stdc++.h>
using namespace std;
#define ll long long
void solve()
{
    ll n,k;
    string s;
        cin >> n >> k >> s;
        vector<ll> v(n,1e18);
        ll cnt0 = 0,cnt1 = 0;
        for(int i=0;i < n;i++)
    {
        if(s[i] == '0')
        {
            cnt0++;
        }
        else
        {
            cnt1++;
        }
    }
    if(cnt0 == 0)
    {
        for(int i=0;i < n;i++)
        {
            s[i] = '0';
        }
        cout << s << endl;
        return;
    }
    if(cnt0 == n)
    {
        cout << s << endl;
        return;
    }
    string st = s;
        for(int i=0;i < n;i++)
    {
        if(s[i] == '1'){
            st[i] = '0';
        }
        else
        {
            if(i > 0 && s[i-1] == '1')
            {
                st[i] = '1';
            }
            else if(i < n-1 && s[i+1] == '1')
            {
                st[i] = '1';
            }
        }
    }
    s = st;
    k--;
    ll front = -1e18;
        for(int i=0;i < n;i++)
    {
        if(s[i] == '1')
        {
            v[i] = 0;
            front = i;
        }
        else
        {
            v[i] = i-front-1;
        }
    }
    ll back = 1e18;
        for(ll i=n-1;i >= 0;i--)
    {
        if(s[i] == '1')
        {
            back = i;
        }
        else
        {
            v[i] = min(v[i],back - i - 1);
        }
    }
    for(int i=0;i < n;i++)
    {
        ll dist = k - v[i];
                if(dist < 0) continue;
                if(dist % 2 != 0)
        {
            if(s[i] == '0')
            {
                s[i] = '1';
            }
            else
            {
                s[i] = '0'; 
            }
        }
    }
    cout << s << endl;
}
int main() {
    // your code goes here
    int t;
    cin >> t;
    while(t--)
    {
        solve();
    }
    return 0;
}